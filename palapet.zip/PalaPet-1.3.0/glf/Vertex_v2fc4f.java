//Decompiled by Procyon!

package glf;

import glm.vec._4.*;
import glm.vec._2.*;

public class Vertex_v2fc4f
{
    public static final int SIZE = 24;
    public Vec4 position;
    public Vec2 texCoord;
    
    public Vertex_v2fc4f() {
    }
    
    public Vertex_v2fc4f(final Vec4 position, final Vec2 texCoord) {
        this.position = position;
        this.texCoord = texCoord;
    }
}
