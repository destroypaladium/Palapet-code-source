//Decompiled by Procyon!

package glf;

import glm.vec._3.*;
import dev.*;
import java.nio.*;

public class Vertex_v3fv4u8
{
    public static final int SIZE = 16;
    public Vec3 position;
    public Vec4u8 color;
    
    public Vertex_v3fv4u8(final Vec3 position, final Vec4u8 color) {
        this.position = position;
        this.color = color;
    }
    
    public void toBb(final ByteBuffer bb, final int index) {
        bb.putFloat(index * 16 + 0, this.position.x).putFloat(index * 16 + 4, this.position.y).putFloat(index * 16 + 8, this.position.z).put(index * 16 + 12 + 0, this.color.x).put(index * 16 + 12 + 1, this.color.y).put(index * 16 + 12 + 2, this.color.z).put(index * 16 + 12 + 3, this.color.w);
    }
}
