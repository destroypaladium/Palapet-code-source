//Decompiled by Procyon!

package glf;

import glm.vec._4.*;

public class Vertex_v4fc4f
{
    public Vec4 position;
    public Vec4 color;
    public static final int SIZE = 32;
    
    public Vertex_v4fc4f() {
    }
    
    public Vertex_v4fc4f(final Vec4 position, final Vec4 color) {
        this.position = position;
        this.color = color;
    }
    
    public float[] toFa_() {
        return new float[] { this.position.x, this.position.y, this.position.z, this.position.w, this.color.x, this.color.y, this.color.z, this.color.w };
    }
}
