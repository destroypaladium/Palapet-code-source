//Decompiled by Procyon!

package glf;

public class Vertex_v4fv4fv4f
{
    public static final int SIZE = 48;
}
