//Decompiled by Procyon!

package glf;

import glm.vec._3.*;

public class Vertex_v3fn3f
{
    public Vec3 position;
    public Vec3 normal;
    public static final int SIZE = 24;
    public static final int OFFSET_POSITION = 0;
    public static final int OFFSET_NORMAL = 12;
    
    public Vertex_v3fn3f(final Vec3 position, final Vec3 normal) {
        this.position = position;
        this.normal = normal;
    }
}
