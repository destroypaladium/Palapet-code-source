//Decompiled by Procyon!

package glf;

import glm.vec._2.*;
import dev.*;
import java.nio.*;

public class Vertex_v2fc4ub
{
    public static final int SIZE = 12;
    public Vec2 position;
    public Vec4u8 color;
    
    public Vertex_v2fc4ub(final Vec2 position, final Vec4u8 color) {
        this.position = position;
        this.color = color;
    }
    
    public void toBb(final ByteBuffer bb, final int index) {
        bb.putFloat(index * 12 + 0, this.position.x).putFloat(index * 12 + 4, this.position.y).put(index * 12 + 8 + 0, this.color.x).put(index * 12 + 8 + 1, this.color.y).put(index * 12 + 8 + 2, this.color.z).put(index * 12 + 8 + 3, this.color.w);
    }
}
