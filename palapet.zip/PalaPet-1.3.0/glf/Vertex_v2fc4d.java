//Decompiled by Procyon!

package glf;

import glm.vec._2.*;
import glm.vec._4.d.*;
import java.nio.*;

public class Vertex_v2fc4d
{
    public static final int SIZE = 40;
    public Vec2 position;
    public Vec4d color;
    
    public Vertex_v2fc4d(final Vec2 position, final Vec4d color) {
        this.position = position;
        this.color = color;
    }
    
    public ByteBuffer toBB(final ByteBuffer bb, final int index) {
        return bb.putFloat(index * 40 + 0, this.position.x).putFloat(index * 40 + 4, this.position.y).putDouble(index * 40 + 8 + 0, this.color.x).putDouble(index * 40 + 8 + 8, this.color.y).putDouble(index * 40 + 8 + 16, this.color.z).putDouble(index * 40 + 8 + 24, this.color.w);
    }
}
