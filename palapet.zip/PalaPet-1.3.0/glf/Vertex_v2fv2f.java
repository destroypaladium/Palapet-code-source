//Decompiled by Procyon!

package glf;

import glm.vec._2.*;
import java.nio.*;

public class Vertex_v2fv2f
{
    public static final int SIZE = 16;
    public Vec2 position;
    public Vec2 texCoord;
    
    public Vertex_v2fv2f(final Vec2 position, final Vec2 texCoord) {
        this.position = position;
        this.texCoord = texCoord;
    }
    
    public void toBb(final ByteBuffer bb, final int index) {
        bb.putFloat(index * 16 + 0, this.position.x).putFloat(index * 16 + 4, this.position.y).putFloat(index * 16 + 8, this.texCoord.x).putFloat(index * 16 + 12, this.texCoord.y);
    }
}
