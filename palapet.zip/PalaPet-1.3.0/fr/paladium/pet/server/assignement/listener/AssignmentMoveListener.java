//Decompiled by Procyon!

package fr.paladium.pet.server.assignement.listener;

import fr.paladium.pet.server.assignement.*;
import fr.paladium.pet.common.event.*;
import fr.paladium.palaforgeutils.lib.location.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.server.config.assignment.fields.*;
import net.minecraft.entity.player.*;
import cpw.mods.fml.common.eventhandler.*;

public class AssignmentMoveListener
{
    private final AssignmentManager manager;
    
    public AssignmentMoveListener() {
        this.manager = AssignmentManager.getInstance();
    }
    
    @SubscribeEvent
    public void onMove(final PlayerMoveEvent event) {
        final EntityPlayerMP player = event.getPlayer();
        final DoubleLocation[] locations = { event.getLastLocation(), event.getCurrentLocation() };
        this.manager.performAssignments(player, PetPlayer.get((EntityPlayer)player), (Object)locations, new AssignmentType[] { AssignmentType.WALK });
    }
}
