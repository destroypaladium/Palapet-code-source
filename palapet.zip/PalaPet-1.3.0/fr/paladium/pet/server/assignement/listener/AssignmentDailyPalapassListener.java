//Decompiled by Procyon!

package fr.paladium.pet.server.assignement.listener;

import fr.paladium.pet.server.assignement.*;
import fr.paladium.palapass.common.event.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.server.config.assignment.fields.*;
import cpw.mods.fml.common.eventhandler.*;

public class AssignmentDailyPalapassListener
{
    private final AssignmentManager manager;
    
    public AssignmentDailyPalapassListener() {
        this.manager = AssignmentManager.getInstance();
    }
    
    @SubscribeEvent
    public void onCompleteDailyJob(final PlayerFinishPassQuestEvent event) {
        final EntityPlayerMP player = (EntityPlayerMP)event.getPlayer();
        this.manager.performAssignments(player, PetPlayer.get((EntityPlayer)player), (Object)null, new AssignmentType[] { AssignmentType.DAILY_PALAPASS });
    }
}
