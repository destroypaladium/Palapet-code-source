//Decompiled by Procyon!

package fr.paladium.pet.server.assignement.listener;

import fr.paladium.pet.server.config.assignment.fields.*;
import fr.paladium.pet.server.assignement.*;
import cpw.mods.fml.common.gameevent.*;
import fr.paladium.palaforgeutils.lib.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.server.config.assignment.*;
import cpw.mods.fml.common.eventhandler.*;
import net.minecraft.entity.player.*;

public class AssignmentTickListener
{
    public static final int TICKS_PER_SECOND = 20;
    private static final AssignmentType[] EVERY_SECOND_ASSIGNMENT_TYPES;
    private int tick;
    private AssignmentManager manager;
    
    public AssignmentTickListener() {
        this.tick = 0;
        this.manager = AssignmentManager.getInstance();
    }
    
    @SubscribeEvent
    public void onTick(final TickEvent.ServerTickEvent event) {
        if (!this.canHandle(event)) {
            return;
        }
        final AssignmentConfig config = this.manager.getConfig();
        if (config == null) {
            return;
        }
        PlayerUtils.getOnlinePlayers().forEach(player -> this.manager.performAssignments((EntityPlayerMP)player, PetPlayer.get(player), (Object)null, AssignmentTickListener.EVERY_SECOND_ASSIGNMENT_TYPES));
    }
    
    private boolean canHandle(final TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return false;
        }
        if (this.tick++ < 20) {
            return false;
        }
        this.tick = 0;
        return true;
    }
    
    static {
        EVERY_SECOND_ASSIGNMENT_TYPES = new AssignmentType[] { AssignmentType.WATER, AssignmentType.WALK, AssignmentType.ANGELIC_WATER, AssignmentType.LIGHT, AssignmentType.DARK, AssignmentType.SLEEP, AssignmentType.CONNECTION };
    }
}
