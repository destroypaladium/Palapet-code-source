//Decompiled by Procyon!

package fr.paladium.pet.server.assignement.task;

import fr.paladium.palaforgeutils.lib.task.*;
import net.minecraft.server.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import java.util.*;

@Schedule(every = "1s")
public class AssignmentResetTask extends ATask
{
    public AssignmentResetTask() {
        super("AssignmentResetTask");
    }
    
    public void run() {
        final Calendar calendar = Calendar.getInstance();
        if (!this.isMidnight(calendar)) {
            return;
        }
        final long now = System.currentTimeMillis();
        final List<EntityPlayerMP> players = (List<EntityPlayerMP>)MinecraftServer.func_71276_C().func_71203_ab().field_72404_b;
        for (final EntityPlayerMP player : players) {
            final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
            if (pet != null) {
                if (!pet.has()) {
                    continue;
                }
                pet.pickupAssignments(player, now);
            }
        }
    }
    
    private boolean isMidnight(final Calendar calendar) {
        return calendar.get(11) == 0 && calendar.get(13) == 0 && calendar.get(12) == 0;
    }
}
