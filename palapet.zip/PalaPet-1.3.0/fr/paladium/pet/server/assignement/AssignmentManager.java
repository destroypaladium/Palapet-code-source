//Decompiled by Procyon!

package fr.paladium.pet.server.assignement;

import fr.paladium.pet.server.config.assignment.fields.*;
import fr.paladium.pet.server.assignement.handler.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.server.config.assignment.*;
import java.util.*;
import fr.paladium.pet.common.network.data.additional.assignment.*;

public class AssignmentManager
{
    private static AssignmentManager instance;
    private final HashMap<AssignmentType, AAssignmentHandler> handlers;
    private AssignmentConfig config;
    
    public AssignmentManager() {
        AssignmentManager.instance = this;
        this.handlers = new HashMap<AssignmentType, AAssignmentHandler>();
    }
    
    public static AssignmentManager getInstance() {
        if (AssignmentManager.instance == null) {
            AssignmentManager.instance = new AssignmentManager();
        }
        return AssignmentManager.instance;
    }
    
    public void registerHandler(final Class<? extends AAssignmentHandler> clazz) {
        try {
            final AAssignmentHandler handler = (AAssignmentHandler)clazz.newInstance();
            if (this.handlers.containsKey(handler.getType())) {
                throw new RuntimeException("Handler already registered for type " + handler.getType().name());
            }
            this.handlers.put(handler.getType(), handler);
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public AssignmentConfig getConfig() {
        if (this.config != null) {
            return this.config;
        }
        return this.config = AssignmentConfig.get();
    }
    
    public void performAssignments(final EntityPlayerMP player, final PetPlayer pet, final Object target, final AssignmentType... types) {
        if (pet == null || !pet.has()) {
            return;
        }
        final AssignmentConfig config = this.getConfig();
        if (config == null) {
            return;
        }
        final Optional<Assignment> result;
        boolean found;
        int length;
        int i = 0;
        AssignmentType type;
        Assignment assignment;
        pet.getAssignmentData().getAssignments().values().forEach(data -> {
            result = config.findAssignmentById(data.getAssignmentId());
            if (!(!result.isPresent())) {
                found = false;
                length = types.length;
                while (i < length) {
                    type = types[i];
                    if (type == result.get().getType()) {
                        found = true;
                        break;
                    }
                    else {
                        ++i;
                    }
                }
                if (!(!found)) {
                    assignment = result.get();
                    this.handleAssignment(player, pet, assignment, data, target);
                }
            }
        });
    }
    
    public void handleAssignment(final EntityPlayerMP player, final PetPlayer pet, final Assignment assignment, final AssignmentData data, final Object target) {
        if (data.isCompleted()) {
            return;
        }
        final AAssignmentHandler handler = this.handlers.get(assignment.getType());
        if (handler == null) {
            return;
        }
        handler.handleAssignment(player, pet, assignment, data, target);
    }
}
