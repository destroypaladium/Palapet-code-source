//Decompiled by Procyon!

package fr.paladium.pet.server.assignement.handler.impl;

import fr.paladium.pet.server.assignement.handler.*;
import fr.paladium.pet.server.config.assignment.fields.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.common.network.data.additional.assignment.*;
import net.minecraft.util.*;
import fr.paladium.pet.server.config.assignment.*;

public class LightAssignmentHandler extends AAssignmentHandler
{
    public LightAssignmentHandler() {
        super(AssignmentType.LIGHT);
    }
    
    public double getAmount(final EntityPlayerMP player, final PetPlayer pet, final Assignment assignment, final AssignmentData data, final Object object) {
        final int blockX = MathHelper.func_76128_c(player.field_70165_t);
        final int blockY = MathHelper.func_76128_c(player.field_70163_u);
        final int blockZ = MathHelper.func_76128_c(player.field_70161_v);
        final float lightLevel = player.field_70170_p.func_72801_o(blockX, blockY + 1, blockZ);
        if (lightLevel >= AssignmentConfig.get().getMinLightAssignmentLightLevel()) {
            return 1.0;
        }
        return 0.0;
    }
}
