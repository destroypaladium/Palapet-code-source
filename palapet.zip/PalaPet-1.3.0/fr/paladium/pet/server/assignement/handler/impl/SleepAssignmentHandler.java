//Decompiled by Procyon!

package fr.paladium.pet.server.assignement.handler.impl;

import fr.paladium.pet.server.assignement.handler.*;
import fr.paladium.palaforgeutils.lib.java.map.player.*;
import fr.paladium.palaforgeutils.lib.location.*;
import fr.paladium.pet.server.config.assignment.fields.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.server.config.assignment.*;
import fr.paladium.pet.common.network.data.additional.assignment.*;
import net.minecraft.entity.*;

public class SleepAssignmentHandler extends AAssignmentHandler
{
    private SessionPlayerMap<DoubleLocation> lastLocations;
    
    public SleepAssignmentHandler() {
        super(AssignmentType.SLEEP);
        this.lastLocations = new SessionPlayerMap<DoubleLocation>() {
            public DoubleLocation getDefaultValue() {
                return null;
            }
        };
    }
    
    public double getAmount(final EntityPlayerMP player, final PetPlayer pet, final Assignment assignment, final AssignmentData data, final Object object) {
        if (!this.lastLocations.containsKey((Entity)player)) {
            this.lastLocations.put((Entity)player, (Object)new DoubleLocation((Entity)player));
            return 0.0;
        }
        final DoubleLocation currentLocation = new DoubleLocation((Entity)player);
        final DoubleLocation lastLocation = (DoubleLocation)this.lastLocations.get((Entity)player);
        this.lastLocations.put((Entity)player, (Object)currentLocation);
        if (lastLocation.getBlockX() == currentLocation.getBlockX() && lastLocation.getBlockY() == currentLocation.getBlockY() && lastLocation.getBlockZ() == currentLocation.getBlockZ()) {
            return 1.0;
        }
        return 0.0;
    }
}
