//Decompiled by Procyon!

package fr.paladium.pet.server.assignement.handler.impl;

import fr.paladium.pet.server.assignement.handler.*;
import fr.paladium.pet.server.config.assignment.fields.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.server.config.assignment.*;
import fr.paladium.pet.common.network.data.additional.assignment.*;
import net.minecraft.item.*;

public class ItemAssignmentHandler extends AAssignmentHandler
{
    public ItemAssignmentHandler() {
        super(AssignmentType.ITEM);
    }
    
    public double getAmount(final EntityPlayerMP player, final PetPlayer pet, final Assignment assignment, final AssignmentData data, final Object object) {
        if (!(object instanceof ItemStack) || assignment.getStack() == null) {
            return 0.0;
        }
        final ItemStack stack = (ItemStack)object;
        if (stack.func_77973_b() != assignment.getStack().func_77973_b() || stack.func_77960_j() != assignment.getStack().func_77960_j()) {
            return 0.0;
        }
        if (stack.field_77994_a <= 0) {
            return 0.0;
        }
        return stack.field_77994_a;
    }
}
