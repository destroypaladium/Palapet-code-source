//Decompiled by Procyon!

package fr.paladium.pet.server.assignement.handler.impl;

import fr.paladium.pet.server.assignement.handler.*;
import fr.paladium.pet.server.config.assignment.fields.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.server.config.assignment.*;
import fr.paladium.pet.common.network.data.additional.assignment.*;

public class DailyJobAssignmentHandler extends AAssignmentHandler
{
    public DailyJobAssignmentHandler() {
        super(AssignmentType.DAILY_JOB);
    }
    
    public double getAmount(final EntityPlayerMP player, final PetPlayer pet, final Assignment assignment, final AssignmentData data, final Object t) {
        return 1.0;
    }
}
