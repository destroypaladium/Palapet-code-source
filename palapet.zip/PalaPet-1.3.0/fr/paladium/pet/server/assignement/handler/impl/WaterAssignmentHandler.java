//Decompiled by Procyon!

package fr.paladium.pet.server.assignement.handler.impl;

import fr.paladium.pet.server.assignement.handler.*;
import net.minecraft.block.*;
import fr.paladium.pet.server.config.assignment.fields.*;
import net.minecraft.init.*;
import java.util.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.server.config.assignment.*;
import fr.paladium.pet.common.network.data.additional.assignment.*;
import net.minecraft.util.*;
import net.minecraft.world.*;

public class WaterAssignmentHandler extends AAssignmentHandler
{
    private final List<Block> blocks;
    
    public WaterAssignmentHandler() {
        super(AssignmentType.WATER);
        this.blocks = Arrays.asList(Blocks.field_150355_j, (Block)Blocks.field_150358_i);
    }
    
    public double getAmount(final EntityPlayerMP player, final PetPlayer pet, final Assignment assignment, final AssignmentData data, final Object o) {
        final World world = player.func_130014_f_();
        final int blockX = MathHelper.func_76128_c(player.field_70165_t);
        final int blockY = MathHelper.func_76128_c(player.field_70163_u);
        final int blockZ = MathHelper.func_76128_c(player.field_70161_v);
        final Block lowerBlock = world.func_147439_a(blockX, blockY, blockZ);
        final Block upperBlock = world.func_147439_a(blockX, blockY + 1, blockZ);
        if (this.blocks.contains(lowerBlock) && this.blocks.contains(upperBlock)) {
            return 1.0;
        }
        return 0.0;
    }
}
