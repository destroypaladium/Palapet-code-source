//Decompiled by Procyon!

package fr.paladium.pet.server.assignement.handler.impl;

import fr.paladium.pet.server.assignement.handler.*;
import fr.paladium.pet.server.config.assignment.fields.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.server.config.assignment.*;
import fr.paladium.pet.common.network.data.additional.assignment.*;
import fr.paladium.palaforgeutils.lib.location.*;

public class WalkAssignmentHandler extends AAssignmentHandler
{
    private static final double MINIMUM_DISTANCE = 1.0;
    private static final double MAXIMUM_DISTANCE = 3.0;
    
    public WalkAssignmentHandler() {
        super(AssignmentType.WALK);
    }
    
    public double getAmount(final EntityPlayerMP player, final PetPlayer pet, final Assignment assignment, final AssignmentData data, final Object object) {
        if (!(object instanceof DoubleLocation[])) {
            return 0.0;
        }
        final DoubleLocation[] locations = (DoubleLocation[])object;
        if (locations.length != 2) {
            return 0.0;
        }
        final DoubleLocation lastLocation = locations[0];
        final DoubleLocation currentLocation = locations[1];
        if (lastLocation == null || currentLocation == null) {
            return 0.0;
        }
        final double distance = lastLocation.distance(currentLocation);
        if (distance <= 3.0) {
            return distance;
        }
        return 0.0;
    }
}
