//Decompiled by Procyon!

package fr.paladium.pet.server.assignement.handler;

import fr.paladium.pet.server.config.assignment.fields.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.common.network.data.additional.assignment.*;
import fr.paladium.pet.server.config.assignment.*;

public abstract class AAssignmentHandler
{
    public static final double NO_PROGRESS = 0.0;
    public static final double DEFAULT_AMOUNT = 1.0;
    private final AssignmentType type;
    
    public AAssignmentHandler(final AssignmentType type) {
        this.type = type;
    }
    
    public abstract double getAmount(final EntityPlayerMP p0, final PetPlayer p1, final Assignment p2, final AssignmentData p3, final Object p4);
    
    public void handleAssignment(final EntityPlayerMP player, final PetPlayer pet, final Assignment assignment, final AssignmentData data) {
        this.handleAssignment(player, pet, assignment, data, null);
    }
    
    public void handleAssignment(final EntityPlayerMP player, final PetPlayer pet, final Assignment assignment, final AssignmentData data, final Object t) {
        final double amount = this.getAmount(player, pet, assignment, data, t);
        if (amount <= 0.0) {
            return;
        }
        final AssignmentConfig config = AssignmentConfig.get();
        data.incrementProgress(player, pet, config, amount);
    }
    
    public AssignmentType getType() {
        return this.type;
    }
}
