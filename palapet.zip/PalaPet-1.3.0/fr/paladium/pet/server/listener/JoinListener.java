//Decompiled by Procyon!

package fr.paladium.pet.server.listener;

import cpw.mods.fml.common.gameevent.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.palaforgeutils.lib.time.*;
import cpw.mods.fml.common.eventhandler.*;

public class JoinListener
{
    @SubscribeEvent
    public void onJoin(final PlayerEvent.PlayerLoggedInEvent event) {
        final EntityPlayerMP player = (EntityPlayerMP)event.player;
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        if (pet == null) {
            return;
        }
        pet.tryResetAssignment(player, TimeUtils.now());
    }
}
