//Decompiled by Procyon!

package fr.paladium.pet.server.listener;

import fr.paladium.palaforgeutils.lib.java.map.player.*;
import fr.paladium.palaforgeutils.lib.location.*;
import cpw.mods.fml.common.gameevent.*;
import net.minecraft.entity.*;
import fr.paladium.pet.common.event.*;
import net.minecraftforge.common.*;
import net.minecraft.entity.player.*;
import cpw.mods.fml.common.eventhandler.*;

public class TickListener
{
    private final SessionPlayerMap<DoubleLocation> locationMap;
    
    public TickListener() {
        this.locationMap = new SessionPlayerMap<DoubleLocation>() {
            public DoubleLocation getDefaultValue() {
                return null;
            }
        };
    }
    
    @SubscribeEvent
    public void onPlayerTick(final TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient()) {
            return;
        }
        final EntityPlayerMP player = (EntityPlayerMP)event.player;
        DoubleLocation lastLocation = (DoubleLocation)this.locationMap.get((Entity)player);
        if (lastLocation == null) {
            lastLocation = new DoubleLocation((Entity)player);
            this.locationMap.put((Entity)player, (Object)lastLocation);
        }
        final DoubleLocation currentLocation = new DoubleLocation((Entity)player);
        if (lastLocation.getX() != currentLocation.getX() || lastLocation.getY() != currentLocation.getY() || lastLocation.getZ() != currentLocation.getZ() || lastLocation.getYaw() != currentLocation.getYaw() || lastLocation.getPitch() != currentLocation.getPitch()) {
            final PlayerMoveEvent moveEvent = new PlayerMoveEvent(player, lastLocation, currentLocation);
            if (MinecraftForge.EVENT_BUS.post((Event)moveEvent)) {
                lastLocation.teleportServer((EntityPlayer)player);
                return;
            }
            this.locationMap.put((Entity)player, (Object)currentLocation);
        }
    }
}
