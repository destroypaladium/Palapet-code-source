//Decompiled by Procyon!

package fr.paladium.pet.server.listener;

import fr.paladium.pet.common.event.level.*;
import net.minecraft.network.play.server.*;
import net.minecraft.network.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.entity.player.*;
import java.util.concurrent.*;
import fr.paladium.helios.module.title.utils.*;
import fr.paladium.helios.module.title.*;
import cpw.mods.fml.common.eventhandler.*;
import fr.paladium.pet.common.event.assignment.*;
import fr.paladium.pet.server.config.assignment.fields.*;
import fr.paladium.pet.common.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.common.network.packet.pet.*;
import cpw.mods.fml.common.network.simpleimpl.*;

public class NotificationListener
{
    @SubscribeEvent
    public void onLevelUp(final PetLevelUpEvent event) {
        final EntityPlayerMP player = (EntityPlayerMP)event.getPlayer();
        final S29PacketSoundEffect packet = new S29PacketSoundEffect("palajobs:palajobs.levelup", player.field_70165_t, player.field_70163_u, player.field_70161_v, 1.0f, 1.0f);
        player.field_71135_a.func_147359_a((Packet)packet);
        final MinecraftTitle title = new MinecraftTitle(PetTranslateEnum.NOTIFICATION_TITLE.text(), PetTranslateEnum.NOTIFICATION_LEVEL_UP.text((EntityPlayer)player, new Object[] { event.getNewLevel() }), 1000L, TimeUnit.SECONDS.toMillis(3L), 1000L);
        ModuleTitle.getInstance().sendTitle(title, player);
        final int oldSlots = event.getCurrentSlots();
        final int newSlots = event.getNewSlots();
        if (oldSlots < newSlots) {
            PetTranslateEnum.NOTIFICATION_SLOT_UNLOCKED.notification(player, new Object[] { newSlots });
        }
    }
    
    @SubscribeEvent
    public void onAssignmentFinish(final AssignmentFinishEvent event) {
        final EntityPlayerMP player = (EntityPlayerMP)event.getPlayer();
        PetTranslateEnum.NOTIFICATION_ASSIGNMENT_FINISH.notification(player, new Object[] { event.getAssignment().getName((EntityPlayer)player) });
        if (event.getAssignment().getType().equals((Object)AssignmentType.ITEM)) {
            PetCommonProxy.getInstance().getNetwork().sendTo((IMessage)new BBOpenUIPacket(player, PetPlayer.get((EntityPlayer)player)), player);
        }
    }
}
