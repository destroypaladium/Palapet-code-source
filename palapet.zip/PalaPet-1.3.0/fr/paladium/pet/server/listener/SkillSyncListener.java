//Decompiled by Procyon!

package fr.paladium.pet.server.listener;

import cpw.mods.fml.common.gameevent.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.packet.pet.*;
import fr.paladium.pet.common.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import cpw.mods.fml.common.eventhandler.*;
import fr.paladium.pet.common.event.global.*;

public class SkillSyncListener
{
    @SubscribeEvent
    public void onJoin(final PlayerEvent.PlayerLoggedInEvent event) {
        final EntityPlayerMP player = (EntityPlayerMP)event.player;
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        if (pet == null || !pet.has()) {
            return;
        }
        final BBUpdateClientSkillValuesPacket packet = new BBUpdateClientSkillValuesPacket(pet);
        PetCommonProxy.getInstance().getNetwork().sendTo((IMessage)packet, player);
    }
    
    @SubscribeEvent
    public void onPetUpdate(final PetStatChangeEvent event) {
        final EntityPlayerMP player = (EntityPlayerMP)event.getPlayer();
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        if (pet == null) {
            return;
        }
        final UpdateStatType type = event.getType();
        if (!type.needUpdate()) {
            return;
        }
        final BBUpdateClientSkillValuesPacket packet = new BBUpdateClientSkillValuesPacket(pet);
        PetCommonProxy.getInstance().getNetwork().sendTo((IMessage)packet, player);
    }
}
