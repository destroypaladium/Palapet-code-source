//Decompiled by Procyon!

package fr.paladium.pet.server.listener;

import fr.paladium.pet.common.event.happiness.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.command.*;
import cpw.mods.fml.common.eventhandler.*;

public class HappinessListener
{
    @SubscribeEvent
    public void onEarnHappiness(final PetEarnHappinessEvent event) {
        PetTranslateEnum.MESSAGE_EARN_HAPPINESS.message((ICommandSender)event.getPlayer(), new Object[] { event.getAmount() });
    }
}
