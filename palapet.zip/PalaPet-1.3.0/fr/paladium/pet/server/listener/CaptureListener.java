//Decompiled by Procyon!

package fr.paladium.pet.server.listener;

import fr.paladium.pet.common.event.capture.*;
import fr.paladium.pet.server.config.global.*;
import fr.paladium.palajobs.core.network.data.*;
import net.minecraft.entity.*;
import fr.paladium.palajobs.core.jobs.*;
import fr.paladium.palajobs.core.pojo.objectives.*;
import net.minecraft.entity.player.*;
import cpw.mods.fml.common.eventhandler.*;

public class CaptureListener
{
    @SubscribeEvent
    public void onPetCapture(final PetCaptureEvent event) {
        final double value = GlobalConfig.get().getExperiencePerPetCapture();
        final EntityPlayerMP player = (EntityPlayerMP)event.getPlayer();
        final JobsPlayer jobsPlayer = JobsPlayer.get((Entity)player);
        if (jobsPlayer == null) {
            return;
        }
        jobsPlayer.addXp(JobType.HUNTER, ObjectiveType.FISH, value, (EntityPlayer)player);
    }
}
