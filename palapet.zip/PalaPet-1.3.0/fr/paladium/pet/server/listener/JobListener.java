//Decompiled by Procyon!

package fr.paladium.pet.server.listener;

import fr.paladium.palajobs.core.events.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.event.experience.*;
import cpw.mods.fml.common.eventhandler.*;

public class JobListener
{
    @SubscribeEvent
    public void onLevelUp(final OnPlayerLevelUp event) {
        final EntityPlayerMP player = (EntityPlayerMP)event.player;
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        if (pet == null || !pet.has()) {
            return;
        }
        final PetExperienceSource source = PetExperienceSource.getByJobName(event.jobName);
        if (source == null) {
            return;
        }
        pet.earnExperience((EntityPlayer)player, source, pet.getExperienceByJobLevelUp(event.levelAfter));
    }
}
