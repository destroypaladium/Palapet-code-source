//Decompiled by Procyon!

package fr.paladium.pet.server.listener;

import cpw.mods.fml.common.gameevent.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import cpw.mods.fml.common.eventhandler.*;

public class ConnectionListener
{
    @SubscribeEvent
    public void onPlayerLoggedIn(final PlayerEvent.PlayerLoggedInEvent event) {
        final EntityPlayerMP player = (EntityPlayerMP)event.player;
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        if (pet == null || !pet.has()) {
            return;
        }
        pet.onPlayerLoggedIn(player);
    }
}
