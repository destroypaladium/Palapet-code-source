//Decompiled by Procyon!

package fr.paladium.pet.server.config.global;

import fr.paladium.palaconfiguration.server.system.*;
import fr.paladium.palaconfiguration.server.system.annotations.*;
import fr.paladium.pet.server.*;
import java.util.*;

@ConfigFile(path = "pet/global_config.json", blocking = true)
public class GlobalConfig implements IConfig
{
    private long connectionIntervalMillis;
    private double experiencePerConnection;
    private double experiencePerPetCapture;
    private int happinessLoss;
    private int maxPetNameLength;
    private HashSet<String> whitelistedDamageEntities;
    private List<HappinessValue> happinessValues;
    
    public static GlobalConfig get() {
        return PetServerProxy.getInstance().getGlobalConfig();
    }
    
    public boolean isValid() {
        return true;
    }
    
    public void onLoaded() {
        this.happinessValues.sort(Comparator.comparingInt(HappinessValue::getMinLevel));
    }
    
    public void onReloaded() {
    }
    
    public void onFailed() {
    }
    
    public HappinessValue getHappinessValue(final int level) {
        for (final HappinessValue value : this.happinessValues) {
            if (level >= value.getMinLevel() && level <= value.getMaxLevel()) {
                return value;
            }
        }
        return null;
    }
    
    public int getMaxHappiness(final int level) {
        final HappinessValue value = this.getHappinessValue(level);
        if (value == null) {
            return 0;
        }
        return value.getMaxHappiness();
    }
    
    public double getHappinessMultiplier(final int happiness) {
        if (happiness <= 0) {
            return 0.0;
        }
        return happiness / 100.0;
    }
    
    public long getConnectionIntervalMillis() {
        return this.connectionIntervalMillis;
    }
    
    public double getExperiencePerConnection() {
        return this.experiencePerConnection;
    }
    
    public double getExperiencePerPetCapture() {
        return this.experiencePerPetCapture;
    }
    
    public int getHappinessLoss() {
        return this.happinessLoss;
    }
    
    public int getMaxPetNameLength() {
        return this.maxPetNameLength;
    }
    
    public HashSet<String> getWhitelistedDamageEntities() {
        return this.whitelistedDamageEntities;
    }
    
    public List<HappinessValue> getHappinessValues() {
        return this.happinessValues;
    }
}
