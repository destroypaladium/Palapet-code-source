//Decompiled by Procyon!

package fr.paladium.pet.server.config.global;

public class HappinessValue
{
    private int minLevel;
    private int maxLevel;
    private int maxHappiness;
    
    public int getMinLevel() {
        return this.minLevel;
    }
    
    public int getMaxLevel() {
        return this.maxLevel;
    }
    
    public int getMaxHappiness() {
        return this.maxHappiness;
    }
    
    public void setMinLevel(final int minLevel) {
        this.minLevel = minLevel;
    }
    
    public void setMaxLevel(final int maxLevel) {
        this.maxLevel = maxLevel;
    }
    
    public void setMaxHappiness(final int maxHappiness) {
        this.maxHappiness = maxHappiness;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof HappinessValue)) {
            return false;
        }
        final HappinessValue other = (HappinessValue)o;
        return other.canEqual(this) && this.getMinLevel() == other.getMinLevel() && this.getMaxLevel() == other.getMaxLevel() && this.getMaxHappiness() == other.getMaxHappiness();
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof HappinessValue;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        result = result * 59 + this.getMinLevel();
        result = result * 59 + this.getMaxLevel();
        result = result * 59 + this.getMaxHappiness();
        return result;
    }
    
    @Override
    public String toString() {
        return "HappinessValue(minLevel=" + this.getMinLevel() + ", maxLevel=" + this.getMaxLevel() + ", maxHappiness=" + this.getMaxHappiness() + ")";
    }
    
    public HappinessValue() {
    }
    
    public HappinessValue(final int minLevel, final int maxLevel, final int maxHappiness) {
        this.minLevel = minLevel;
        this.maxLevel = maxLevel;
        this.maxHappiness = maxHappiness;
    }
}
