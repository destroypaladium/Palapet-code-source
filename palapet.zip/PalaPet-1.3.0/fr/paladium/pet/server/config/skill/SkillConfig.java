//Decompiled by Procyon!

package fr.paladium.pet.server.config.skill;

import fr.paladium.palaconfiguration.server.system.*;
import fr.paladium.palaconfiguration.server.system.annotations.*;
import fr.paladium.pet.server.*;
import fr.paladium.pet.server.skill.*;
import fr.paladium.pet.server.commands.skill.*;
import java.util.function.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.server.skill.skill.*;
import fr.paladium.pet.common.network.data.additional.skill.*;
import java.util.*;
import net.minecraft.world.*;
import net.minecraft.block.*;
import net.minecraft.item.*;

@ConfigFile(path = "pet/skill_config.json", blocking = true)
public class SkillConfig implements IConfig
{
    public static final String ACTIVE_SKILL_PACKAGE = "fr.paladium.pet.skill.listener.active";
    public static final String PASSIVE_SKILL_PACKAGE = "fr.paladium.pet.skill.listener.passive";
    private int maxActiveSkills;
    private long changeSkillCooldown;
    private List<Skill> activeSkills;
    private List<Skill> passiveSkills;
    private HashMap<String, String> luckyMinerMap;
    
    public static SkillConfig get() {
        return PetServerProxy.getInstance().getSkillConfig();
    }
    
    public boolean isValid() {
        return true;
    }
    
    public void onLoaded() {
        final SkillManager manager = SkillManager.getInstance();
        manager.updateSkills();
        this.updateSubCommand();
    }
    
    public void onReloaded() {
        this.onLoaded();
    }
    
    public void onFailed() {
    }
    
    private void updateSubCommand() {
        final SkillSubCommand sub = SkillSubCommand.getInstance();
        if (sub == null) {
            return;
        }
        final String[] args = this.getAllSkills().stream().map((Function<? super Object, ?>)Skill::getId).toArray(String[]::new);
        sub.updateSkills(args);
    }
    
    public List<Skill> getAllSkills() {
        final List<Skill> skills = new ArrayList<Skill>(this.activeSkills);
        skills.addAll(this.passiveSkills);
        return skills;
    }
    
    public HashMap<SkillType, Integer> getSkillCount(final PetPlayer pet) {
        final HashMap<Integer, SkillData> map = (HashMap<Integer, SkillData>)pet.getSkillData().getSkills();
        final HashMap<SkillType, Integer> result = new HashMap<SkillType, Integer>();
        for (final SkillData data : map.values()) {
            final Optional<Skill> skill = this.findSkillById(data.getSkillId());
            if (!skill.isPresent()) {
                continue;
            }
            final SkillType type = skill.get().getType();
            result.put(type, result.getOrDefault(type, 0) + 1);
        }
        return result;
    }
    
    public ItemStack getMinerOutput(final World world, final int x, final int y, final int z, final Block block) {
        try {
            final String unlocalizedName = block.func_149739_a();
            final String metadata = String.valueOf(world.func_72805_g(x, y, z));
            final String key = unlocalizedName + ":" + metadata;
            if (!this.luckyMinerMap.containsKey(key)) {
                return null;
            }
            final String[] split = this.luckyMinerMap.get(key).split(":");
            final Block b = Block.func_149684_b(split[0]);
            final int meta = Integer.parseInt(split[1]);
            final ItemStack stack = new ItemStack(b, meta);
            return stack;
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public Skill getPassive(final String id) {
        return this.passiveSkills.stream().filter(s -> s.getId().equals(id)).findFirst().orElse(null);
    }
    
    public Skill getActive(final String id) {
        return this.activeSkills.stream().filter(s -> s.getId().equals(id)).findFirst().orElse(null);
    }
    
    public Optional<Skill> findSkillById(final String id) {
        final Optional<Skill> skill = this.activeSkills.stream().filter(s -> s.getId().equals(id)).findFirst();
        if (skill.isPresent()) {
            return skill;
        }
        return this.passiveSkills.stream().filter(s -> s.getId().equals(id)).findFirst();
    }
    
    public int getMaxActiveSkills() {
        return this.maxActiveSkills;
    }
    
    public long getChangeSkillCooldown() {
        return this.changeSkillCooldown;
    }
    
    public List<Skill> getActiveSkills() {
        return this.activeSkills;
    }
    
    public List<Skill> getPassiveSkills() {
        return this.passiveSkills;
    }
    
    public HashMap<String, String> getLuckyMinerMap() {
        return this.luckyMinerMap;
    }
    
    public void setMaxActiveSkills(final int maxActiveSkills) {
        this.maxActiveSkills = maxActiveSkills;
    }
    
    public void setChangeSkillCooldown(final long changeSkillCooldown) {
        this.changeSkillCooldown = changeSkillCooldown;
    }
    
    public void setActiveSkills(final List<Skill> activeSkills) {
        this.activeSkills = activeSkills;
    }
    
    public void setPassiveSkills(final List<Skill> passiveSkills) {
        this.passiveSkills = passiveSkills;
    }
    
    public void setLuckyMinerMap(final HashMap<String, String> luckyMinerMap) {
        this.luckyMinerMap = luckyMinerMap;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof SkillConfig)) {
            return false;
        }
        final SkillConfig other = (SkillConfig)o;
        if (!other.canEqual(this)) {
            return false;
        }
        if (this.getMaxActiveSkills() != other.getMaxActiveSkills()) {
            return false;
        }
        if (this.getChangeSkillCooldown() != other.getChangeSkillCooldown()) {
            return false;
        }
        final Object this$activeSkills = this.getActiveSkills();
        final Object other$activeSkills = other.getActiveSkills();
        Label_0092: {
            if (this$activeSkills == null) {
                if (other$activeSkills == null) {
                    break Label_0092;
                }
            }
            else if (this$activeSkills.equals(other$activeSkills)) {
                break Label_0092;
            }
            return false;
        }
        final Object this$passiveSkills = this.getPassiveSkills();
        final Object other$passiveSkills = other.getPassiveSkills();
        Label_0129: {
            if (this$passiveSkills == null) {
                if (other$passiveSkills == null) {
                    break Label_0129;
                }
            }
            else if (this$passiveSkills.equals(other$passiveSkills)) {
                break Label_0129;
            }
            return false;
        }
        final Object this$luckyMinerMap = this.getLuckyMinerMap();
        final Object other$luckyMinerMap = other.getLuckyMinerMap();
        if (this$luckyMinerMap == null) {
            if (other$luckyMinerMap == null) {
                return true;
            }
        }
        else if (this$luckyMinerMap.equals(other$luckyMinerMap)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof SkillConfig;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        result = result * 59 + this.getMaxActiveSkills();
        final long $changeSkillCooldown = this.getChangeSkillCooldown();
        result = result * 59 + (int)($changeSkillCooldown >>> 32 ^ $changeSkillCooldown);
        final Object $activeSkills = this.getActiveSkills();
        result = result * 59 + (($activeSkills == null) ? 43 : $activeSkills.hashCode());
        final Object $passiveSkills = this.getPassiveSkills();
        result = result * 59 + (($passiveSkills == null) ? 43 : $passiveSkills.hashCode());
        final Object $luckyMinerMap = this.getLuckyMinerMap();
        result = result * 59 + (($luckyMinerMap == null) ? 43 : $luckyMinerMap.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "SkillConfig(maxActiveSkills=" + this.getMaxActiveSkills() + ", changeSkillCooldown=" + this.getChangeSkillCooldown() + ", activeSkills=" + this.getActiveSkills() + ", passiveSkills=" + this.getPassiveSkills() + ", luckyMinerMap=" + this.getLuckyMinerMap() + ")";
    }
}
