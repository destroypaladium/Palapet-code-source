//Decompiled by Procyon!

package fr.paladium.pet.server.config.assignment.fields;

public enum AssignmentType
{
    WATER, 
    ANGELIC_WATER, 
    LIGHT, 
    DARK, 
    ITEM, 
    WALK, 
    SLEEP, 
    CONNECTION, 
    DAILY_JOB, 
    DAILY_PALAPASS;
    
    public boolean isTimedType() {
        return this == AssignmentType.LIGHT || this == AssignmentType.DARK || this == AssignmentType.SLEEP || this == AssignmentType.CONNECTION || this == AssignmentType.WATER || this == AssignmentType.ANGELIC_WATER;
    }
}
