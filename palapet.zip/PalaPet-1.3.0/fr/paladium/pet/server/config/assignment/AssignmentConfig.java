//Decompiled by Procyon!

package fr.paladium.pet.server.config.assignment;

import fr.paladium.palaconfiguration.server.system.*;
import fr.paladium.palaconfiguration.server.system.annotations.*;
import fr.paladium.pet.server.*;
import fr.paladium.pet.server.commands.assignment.*;
import java.util.function.*;
import fr.paladium.pet.server.config.assignment.fields.*;
import java.util.stream.*;
import java.util.*;

@ConfigFile(path = "pet/assignment_config.json", blocking = true)
public class AssignmentConfig implements IConfig
{
    private float minLightAssignmentLightLevel;
    private float maxDarkAssignmentLightLevel;
    private int maxAssignmentsPerDay;
    private List<Assignment> assignments;
    
    public AssignmentConfig() {
        this.assignments = new ArrayList<Assignment>();
    }
    
    public static AssignmentConfig get() {
        return PetServerProxy.getInstance().getAssignmentConfig();
    }
    
    public boolean isValid() {
        return super.isValid();
    }
    
    public void onLoaded() {
        this.updateSubCommand();
        this.reverseWeight();
    }
    
    public void onReloaded() {
        this.onLoaded();
    }
    
    public void onFailed() {
    }
    
    private void updateSubCommand() {
        final AssignmentSubCommand sub = AssignmentSubCommand.getInstance();
        if (sub == null) {
            return;
        }
        final String[] args = this.assignments.stream().map((Function<? super Object, ?>)Assignment::getId).toArray(String[]::new);
        sub.updateAssignments(args);
    }
    
    private void reverseWeight() {
        final List<LevelRange> ranges = new ArrayList<LevelRange>();
        for (final Assignment assignment : this.assignments) {
            assignment.setWeight(1.0f / assignment.getWeight());
            if (ranges.contains(assignment.getLevelRange())) {
                continue;
            }
            ranges.add(assignment.getLevelRange());
        }
        for (final LevelRange range : ranges) {
            float sum = 0.0f;
            for (final Assignment assignment2 : this.assignments) {
                if (!assignment2.getLevelRange().equals(range)) {
                    continue;
                }
                sum += assignment2.getWeight();
            }
            for (final Assignment assignment2 : this.assignments) {
                if (!assignment2.getLevelRange().equals(range)) {
                    continue;
                }
                assignment2.setWeight(assignment2.getWeight() / sum);
            }
        }
    }
    
    public List<Assignment> findAssignments(final int level) {
        return this.assignments.stream().filter(assignment -> assignment.getLevelRange().isInRange(level)).collect((Collector<? super Object, ?, List<Assignment>>)Collectors.toList());
    }
    
    public Assignment getRandomAssignment(final Random random, final int level) {
        final double rand = random.nextDouble();
        double cumulativeProbability = 0.0;
        final List<Assignment> rangeAssignments = this.findAssignments(level);
        if (rangeAssignments == null || rangeAssignments.isEmpty()) {
            return this.getRandomAssignment(random);
        }
        for (final Assignment assignment : rangeAssignments) {
            cumulativeProbability += assignment.getWeight();
            if (rand <= cumulativeProbability) {
                return assignment;
            }
        }
        return null;
    }
    
    public Assignment getRandomAssignment(final Random random) {
        return this.assignments.get(random.nextInt(this.assignments.size()));
    }
    
    public Optional<Assignment> findAssignmentById(final String id) {
        return this.assignments.stream().filter(assignment -> assignment.getId().equals(id)).findFirst();
    }
    
    public float getMinLightAssignmentLightLevel() {
        return this.minLightAssignmentLightLevel;
    }
    
    public float getMaxDarkAssignmentLightLevel() {
        return this.maxDarkAssignmentLightLevel;
    }
    
    public int getMaxAssignmentsPerDay() {
        return this.maxAssignmentsPerDay;
    }
    
    public List<Assignment> getAssignments() {
        return this.assignments;
    }
    
    public void setMinLightAssignmentLightLevel(final float minLightAssignmentLightLevel) {
        this.minLightAssignmentLightLevel = minLightAssignmentLightLevel;
    }
    
    public void setMaxDarkAssignmentLightLevel(final float maxDarkAssignmentLightLevel) {
        this.maxDarkAssignmentLightLevel = maxDarkAssignmentLightLevel;
    }
    
    public void setMaxAssignmentsPerDay(final int maxAssignmentsPerDay) {
        this.maxAssignmentsPerDay = maxAssignmentsPerDay;
    }
    
    public void setAssignments(final List<Assignment> assignments) {
        this.assignments = assignments;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof AssignmentConfig)) {
            return false;
        }
        final AssignmentConfig other = (AssignmentConfig)o;
        if (!other.canEqual(this)) {
            return false;
        }
        if (Float.compare(this.getMinLightAssignmentLightLevel(), other.getMinLightAssignmentLightLevel()) != 0) {
            return false;
        }
        if (Float.compare(this.getMaxDarkAssignmentLightLevel(), other.getMaxDarkAssignmentLightLevel()) != 0) {
            return false;
        }
        if (this.getMaxAssignmentsPerDay() != other.getMaxAssignmentsPerDay()) {
            return false;
        }
        final Object this$assignments = this.getAssignments();
        final Object other$assignments = other.getAssignments();
        if (this$assignments == null) {
            if (other$assignments == null) {
                return true;
            }
        }
        else if (this$assignments.equals(other$assignments)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof AssignmentConfig;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        result = result * 59 + Float.floatToIntBits(this.getMinLightAssignmentLightLevel());
        result = result * 59 + Float.floatToIntBits(this.getMaxDarkAssignmentLightLevel());
        result = result * 59 + this.getMaxAssignmentsPerDay();
        final Object $assignments = this.getAssignments();
        result = result * 59 + (($assignments == null) ? 43 : $assignments.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "AssignmentConfig(minLightAssignmentLightLevel=" + this.getMinLightAssignmentLightLevel() + ", maxDarkAssignmentLightLevel=" + this.getMaxDarkAssignmentLightLevel() + ", maxAssignmentsPerDay=" + this.getMaxAssignmentsPerDay() + ", assignments=" + this.getAssignments() + ")";
    }
}
