//Decompiled by Procyon!

package fr.paladium.pet.server.config.assignment.fields;

public class LevelRange
{
    private int min;
    private int max;
    
    public boolean isInRange(final int value) {
        return value >= this.min && value <= this.max;
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (!(obj instanceof LevelRange)) {
            return false;
        }
        final LevelRange range = (LevelRange)obj;
        return range.min == this.min && range.max == this.max;
    }
    
    public int getMin() {
        return this.min;
    }
    
    public int getMax() {
        return this.max;
    }
    
    public LevelRange() {
    }
    
    public LevelRange(final int min, final int max) {
        this.min = min;
        this.max = max;
    }
}
