//Decompiled by Procyon!

package fr.paladium.pet.server.config.assignment;

import fr.paladium.pet.server.config.assignment.fields.*;
import net.minecraft.item.*;
import net.minecraft.entity.player.*;
import fr.paladium.translate.common.texttotranslate.*;

public class Assignment
{
    private String id;
    private AssignmentType type;
    private String logo;
    private LevelRange levelRange;
    private float weight;
    private float probability;
    private int givenPoints;
    private float givenExp;
    private double amount;
    private ItemStack stack;
    
    public String getName(final EntityPlayer player) {
        return TTT.format(player, this.getTTTName(player), new Object[0]);
    }
    
    public String getDescription(final EntityPlayer player) {
        return TTT.format(player, this.getTTTDescription(player), new Object[0]);
    }
    
    private String getTTTDescription(final EntityPlayer player) {
        return "skill.assignment." + this.id.toLowerCase() + ".description";
    }
    
    private String getTTTName(final EntityPlayer player) {
        return "skill.assignment." + this.id.toLowerCase() + ".name";
    }
    
    public String getId() {
        return this.id;
    }
    
    public AssignmentType getType() {
        return this.type;
    }
    
    public String getLogo() {
        return this.logo;
    }
    
    public LevelRange getLevelRange() {
        return this.levelRange;
    }
    
    public float getWeight() {
        return this.weight;
    }
    
    public float getProbability() {
        return this.probability;
    }
    
    public int getGivenPoints() {
        return this.givenPoints;
    }
    
    public float getGivenExp() {
        return this.givenExp;
    }
    
    public double getAmount() {
        return this.amount;
    }
    
    public ItemStack getStack() {
        return this.stack;
    }
    
    public void setId(final String id) {
        this.id = id;
    }
    
    public void setType(final AssignmentType type) {
        this.type = type;
    }
    
    public void setLogo(final String logo) {
        this.logo = logo;
    }
    
    public void setLevelRange(final LevelRange levelRange) {
        this.levelRange = levelRange;
    }
    
    public void setWeight(final float weight) {
        this.weight = weight;
    }
    
    public void setProbability(final float probability) {
        this.probability = probability;
    }
    
    public void setGivenPoints(final int givenPoints) {
        this.givenPoints = givenPoints;
    }
    
    public void setGivenExp(final float givenExp) {
        this.givenExp = givenExp;
    }
    
    public void setAmount(final double amount) {
        this.amount = amount;
    }
    
    public void setStack(final ItemStack stack) {
        this.stack = stack;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof Assignment)) {
            return false;
        }
        final Assignment other = (Assignment)o;
        if (!other.canEqual(this)) {
            return false;
        }
        if (Float.compare(this.getWeight(), other.getWeight()) != 0) {
            return false;
        }
        if (Float.compare(this.getProbability(), other.getProbability()) != 0) {
            return false;
        }
        if (this.getGivenPoints() != other.getGivenPoints()) {
            return false;
        }
        if (Float.compare(this.getGivenExp(), other.getGivenExp()) != 0) {
            return false;
        }
        if (Double.compare(this.getAmount(), other.getAmount()) != 0) {
            return false;
        }
        final Object this$id = this.getId();
        final Object other$id = other.getId();
        Label_0142: {
            if (this$id == null) {
                if (other$id == null) {
                    break Label_0142;
                }
            }
            else if (this$id.equals(other$id)) {
                break Label_0142;
            }
            return false;
        }
        final Object this$type = this.getType();
        final Object other$type = other.getType();
        Label_0179: {
            if (this$type == null) {
                if (other$type == null) {
                    break Label_0179;
                }
            }
            else if (this$type.equals(other$type)) {
                break Label_0179;
            }
            return false;
        }
        final Object this$logo = this.getLogo();
        final Object other$logo = other.getLogo();
        Label_0216: {
            if (this$logo == null) {
                if (other$logo == null) {
                    break Label_0216;
                }
            }
            else if (this$logo.equals(other$logo)) {
                break Label_0216;
            }
            return false;
        }
        final Object this$levelRange = this.getLevelRange();
        final Object other$levelRange = other.getLevelRange();
        Label_0253: {
            if (this$levelRange == null) {
                if (other$levelRange == null) {
                    break Label_0253;
                }
            }
            else if (this$levelRange.equals(other$levelRange)) {
                break Label_0253;
            }
            return false;
        }
        final Object this$stack = this.getStack();
        final Object other$stack = other.getStack();
        if (this$stack == null) {
            if (other$stack == null) {
                return true;
            }
        }
        else if (this$stack.equals(other$stack)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof Assignment;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        result = result * 59 + Float.floatToIntBits(this.getWeight());
        result = result * 59 + Float.floatToIntBits(this.getProbability());
        result = result * 59 + this.getGivenPoints();
        result = result * 59 + Float.floatToIntBits(this.getGivenExp());
        final long $amount = Double.doubleToLongBits(this.getAmount());
        result = result * 59 + (int)($amount >>> 32 ^ $amount);
        final Object $id = this.getId();
        result = result * 59 + (($id == null) ? 43 : $id.hashCode());
        final Object $type = this.getType();
        result = result * 59 + (($type == null) ? 43 : $type.hashCode());
        final Object $logo = this.getLogo();
        result = result * 59 + (($logo == null) ? 43 : $logo.hashCode());
        final Object $levelRange = this.getLevelRange();
        result = result * 59 + (($levelRange == null) ? 43 : $levelRange.hashCode());
        final Object $stack = this.getStack();
        result = result * 59 + (($stack == null) ? 43 : $stack.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "Assignment(id=" + this.getId() + ", type=" + this.getType() + ", logo=" + this.getLogo() + ", levelRange=" + this.getLevelRange() + ", weight=" + this.getWeight() + ", probability=" + this.getProbability() + ", givenPoints=" + this.getGivenPoints() + ", givenExp=" + this.getGivenExp() + ", amount=" + this.getAmount() + ", stack=" + this.getStack() + ")";
    }
    
    public Assignment() {
    }
    
    public Assignment(final String id, final AssignmentType type, final String logo, final LevelRange levelRange, final float weight, final float probability, final int givenPoints, final float givenExp, final double amount, final ItemStack stack) {
        this.id = id;
        this.type = type;
        this.logo = logo;
        this.levelRange = levelRange;
        this.weight = weight;
        this.probability = probability;
        this.givenPoints = givenPoints;
        this.givenExp = givenExp;
        this.amount = amount;
        this.stack = stack;
    }
}
