//Decompiled by Procyon!

package fr.paladium.pet.server.commands.happiness;

import fr.paladium.palaforgeutils.lib.subcommand.*;
import fr.paladium.palaforgeutils.lib.subcommand.base.impl.*;
import fr.paladium.palaforgeutils.lib.subcommand.base.*;
import net.minecraft.command.*;
import fr.paladium.palaforgeutils.lib.subcommand.data.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.constant.*;
import fr.paladium.pet.common.network.packet.pet.*;
import fr.paladium.pet.common.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import java.util.*;

public class HappinessSubCommand extends ASubCommand
{
    public static final String NAME = "happiness";
    public static final String PERMISSION = "paladium.pet.happiness";
    
    public HappinessSubCommand() {
        final ASubCommand playerSub = (ASubCommand)PlayerSubCommand.create("(player)").build((ASubCommand)this);
        final ASubCommand setSub = (ASubCommand)StringSubCommand.create("set").build(playerSub);
        final ASubCommand numberSub = (ASubCommand)NumberSubCommand.create("(value)", "d\u00e9finir le bonheur du familier").build(setSub, this.set());
    }
    
    private ISubCallback set() {
        return (sender, data) -> {
            final Optional<EntityPlayerMP> result = (Optional<EntityPlayerMP>)data.getTargetedPlayer();
            if (!result.isPresent()) {
                return false;
            }
            final EntityPlayerMP target = result.get();
            final PetPlayer pet = PetPlayer.get((EntityPlayer)target);
            final int value = data.getInteger();
            if (pet == null || !pet.has()) {
                PetTranslateEnum.MESSAGE_TARGET_NO_PET.message(sender, new Object[] { target.func_70005_c_() });
                return true;
            }
            final int happiness = pet.setHappiness((EntityPlayer)target, value);
            PetTranslateEnum.MESSAGE_HAPPINESS_SET.message(sender, new Object[] { target.func_70005_c_(), happiness });
            PetTranslateEnum.MESSAGE_HAPPINESS_SET_TARGET.message((ICommandSender)target, new Object[] { sender.func_70005_c_(), happiness });
            final BBUpdateClientSkillValuesPacket packet = new BBUpdateClientSkillValuesPacket(pet);
            PetCommonProxy.getInstance().getNetwork().sendTo((IMessage)packet, target);
            return true;
        };
    }
}
