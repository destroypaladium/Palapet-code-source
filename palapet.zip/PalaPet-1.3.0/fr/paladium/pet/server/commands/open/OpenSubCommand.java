//Decompiled by Procyon!

package fr.paladium.pet.server.commands.open;

import fr.paladium.palaforgeutils.lib.subcommand.*;
import net.minecraft.command.*;
import fr.paladium.palaforgeutils.lib.subcommand.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.server.commands.*;

public class OpenSubCommand extends ASubCommand
{
    public static final String NAME = "open";
    public static final String DESCRIPTION = "Ouvrir l'interface";
    
    protected boolean performCurrentNode(final ICommandSender sender, final CommandData data) {
        return PetSubCommand.openHomeUI((EntityPlayerMP)sender);
    }
}
