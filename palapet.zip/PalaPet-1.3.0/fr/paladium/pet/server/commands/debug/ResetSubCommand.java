//Decompiled by Procyon!

package fr.paladium.pet.server.commands.debug;

import fr.paladium.palaforgeutils.lib.subcommand.*;
import net.minecraft.command.*;
import fr.paladium.palaforgeutils.lib.subcommand.data.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.palaforgeutils.lib.chat.*;

public class ResetSubCommand extends ASubCommand
{
    public static final String NAME = "reset";
    public static final String DESCRIPTION = "Reset soi-m\u00eame";
    public static final String PERMISSION = "palapet.command.reset";
    
    protected boolean performCurrentNode(final ICommandSender sender, final CommandData data) {
        final EntityPlayerMP player = (EntityPlayerMP)sender;
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        if (pet == null) {
            return true;
        }
        pet.reset();
        ChatUtils.sendColoredMessage(sender, new String[] { "�eVous avez reset votre pet !" });
        return true;
    }
}
