//Decompiled by Procyon!

package fr.paladium.pet.server.commands.debug;

import fr.paladium.palaforgeutils.lib.subcommand.*;
import net.minecraft.command.*;
import fr.paladium.palaforgeutils.lib.subcommand.data.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.palaforgeutils.lib.chat.*;
import fr.paladium.pet.common.*;
import com.google.gson.*;

public class UnlockSubCommand extends ASubCommand
{
    public static final String NAME = "unlock";
    public static final String DESCRIPTION = "Unlock soi-m\u00eame";
    public static final String PERMISSION = "palapet.command.unlock";
    private static final Gson GSON;
    
    protected boolean performCurrentNode(final ICommandSender sender, final CommandData data) {
        final EntityPlayerMP player = (EntityPlayerMP)sender;
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        if (pet == null) {
            return true;
        }
        if (pet.has()) {
            ChatUtils.sendColoredMessage(sender, new String[] { "�cVous avez d\u00e9j\u00e0 un pet !" });
            return true;
        }
        final String skin = PetCommonProxy.getInstance().findRandomDefaultPet();
        ChatUtils.sendColoredMessage(sender, new String[] { "�eVous avez d\u00e9bloqu\u00e9 le pet �6" + skin + "�e !" });
        pet.unlock(player, skin);
        return true;
    }
    
    static {
        GSON = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create();
    }
}
