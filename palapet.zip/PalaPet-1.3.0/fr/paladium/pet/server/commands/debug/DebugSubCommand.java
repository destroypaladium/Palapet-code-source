//Decompiled by Procyon!

package fr.paladium.pet.server.commands.debug;

import fr.paladium.palaforgeutils.lib.subcommand.*;
import fr.paladium.palaforgeutils.lib.subcommand.base.impl.*;
import net.minecraft.command.*;
import fr.paladium.palaforgeutils.lib.subcommand.data.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.palaforgeutils.lib.chat.*;
import fr.paladium.pet.common.provider.*;
import java.util.*;
import fr.paladium.pet.common.network.data.additional.skill.*;
import fr.paladium.pet.common.network.data.additional.assignment.*;

public class DebugSubCommand extends ASubCommand
{
    public static final String NAME = "debug";
    public static final String DESCRIPTION = "Debug un joueur";
    public static final String PERMISSION = "palapet.command.debug";
    
    public DebugSubCommand() {
        PlayerSubCommand.create("(player)", "Debug un joueur").build((ASubCommand)this, (sender, data) -> {
            final Optional<EntityPlayerMP> result = (Optional<EntityPlayerMP>)data.getTargetedPlayer();
            if (!result.isPresent()) {
                return false;
            }
            final EntityPlayerMP player = result.get();
            final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
            ChatUtils.sendColoredMessage(sender, new String[] { "�8�m---------------------------------" });
            ChatUtils.sendColoredMessage(sender, new String[] { "�eDebug de �6" + player.getDisplayName() + "�e:" });
            ChatUtils.sendColoredMessage(sender, new String[] { "�e- Pet: �6" + pet.has() });
            ChatUtils.sendColoredMessage(sender, new String[] { "�e- Level: �6" + pet.getLevel() });
            ChatUtils.sendColoredMessage(sender, new String[] { "�e- Experience: �6" + pet.getExperience() });
            ChatUtils.sendColoredMessage(sender, new String[] { "�e- Happiness: �6" + pet.getHappiness() + "�e/�6" + pet.getMaxHappiness() });
            ChatUtils.sendColoredMessage(sender, new String[] { "�e- Slots: �6" + pet.getSlots(pet.getLevel()) });
            ChatUtils.sendColoredMessage(sender, new String[] { "�e- Assignments: �6" });
            pet.getAssignmentData().getAssignments().forEach((key, value) -> ChatUtils.sendColoredMessage(sender, new String[] { "�e  - " + key + ": �6" + value.getProgress() + "�e finished: �6" + value.isCompleted() }));
            ChatUtils.sendColoredMessage(sender, new String[] { "�e- Skills: �6" });
            pet.getSkillData().getSkills().forEach((key, value) -> ChatUtils.sendColoredMessage(sender, new String[] { "�e  - " + key + ": �6" + value.getSkillId() }));
            ChatUtils.sendColoredMessage(sender, new String[] { "�e- Skins: �6" });
            PetSkinShopProvider.getInstance().getSkins((EntityPlayer)player, pet).forEach(skin -> ChatUtils.sendColoredMessage(sender, new String[] { "�e  - " + skin }));
            ChatUtils.sendColoredMessage(sender, new String[] { "�8�m---------------------------------" });
            return true;
        });
    }
}
