//Decompiled by Procyon!

package fr.paladium.pet.server.commands;

import fr.paladium.palaforgeutils.lib.subcommand.*;
import fr.paladium.palaforgeutils.lib.subcommand.builder.*;
import fr.paladium.pet.server.commands.assignment.*;
import fr.paladium.palaforgeutils.lib.command.*;
import fr.paladium.pet.server.commands.debug.*;
import fr.paladium.pet.server.commands.skill.*;
import fr.paladium.pet.server.commands.happiness.*;
import fr.paladium.pet.server.commands.give.*;
import fr.paladium.pet.server.commands.open.*;
import fr.paladium.pet.server.commands.bypass.*;
import fr.paladium.pet.server.commands.level.*;
import fr.paladium.pet.server.commands.experience.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.command.*;
import fr.paladium.pet.common.*;
import fr.paladium.pet.common.network.packet.pet.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import fr.paladium.palaforgeutils.lib.subcommand.data.*;

public class PetSubCommand extends ASubCommand
{
    public static final String NAME = "pet";
    public static final String DESCRIPTION = "G\u00e9rer son familier";
    
    public PetSubCommand() {
        SubCommandBuilder.create("assignment").permission("palapet.command.assignment").string().build((ASubCommand)this, (ASubCommand)new AssignmentSubCommand());
        SubCommandBuilder.create("debug", "Debug un joueur").permission("palapet.command.debug").string().build((ASubCommand)this, (ASubCommand)new DebugSubCommand());
        SubCommandBuilder.create("reset", "Reset soi-m\u00eame").permission("palapet.command.reset").sender(new SenderType[] { SenderType.PLAYER }).build((ASubCommand)this, (ASubCommand)new ResetSubCommand());
        SubCommandBuilder.create("unlock", "Unlock soi-m\u00eame").permission("palapet.command.unlock").sender(new SenderType[] { SenderType.PLAYER }).build((ASubCommand)this, (ASubCommand)new UnlockSubCommand());
        SubCommandBuilder.create("skill").permission("palapet.command.skill").string().build((ASubCommand)this, (ASubCommand)new SkillSubCommand());
        SubCommandBuilder.create("happiness").permission("paladium.pet.happiness").string().build((ASubCommand)this, (ASubCommand)new HappinessSubCommand());
        SubCommandBuilder.create("give", "Give un skin \u00e0 un joueur").permission("palapet.command.give").string().build((ASubCommand)this, (ASubCommand)new GiveSubCommand());
        SubCommandBuilder.create("reset-admin", "Reset les skins d'un admin").permission("palapet.command.reset.admin").string().build((ASubCommand)this, (ASubCommand)new ResetAdminSkinSubCommand());
        SubCommandBuilder.create("open", "Ouvrir l'interface").sender(new SenderType[] { SenderType.PLAYER }).string().build((ASubCommand)this, (ASubCommand)new OpenSubCommand());
        SubCommandBuilder.create("bypass", "Bypass un joueur").permission("paladium.pet.bypass").string().build((ASubCommand)this, (ASubCommand)new BypassSubCommand());
        SubCommandBuilder.create("level").permission("paladium.pet.level").string().build((ASubCommand)this, (ASubCommand)new LevelSubCommand());
        SubCommandBuilder.create("experience").permission("paladium.pet.experience").string().build((ASubCommand)this, (ASubCommand)new ExperienceSubCommand());
    }
    
    public static boolean openHomeUI(final EntityPlayerMP sender) {
        final EntityPlayerMP player = sender;
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        if (pet == null || !pet.has()) {
            PetTranslateEnum.MESSAGE_NO_FAMILIAR.message((ICommandSender)player);
            return true;
        }
        PetCommonProxy.getInstance().getNetwork().sendTo((IMessage)new BBOpenUIPacket(player, pet), player);
        return true;
    }
    
    protected boolean performCurrentNode(final ICommandSender sender, final CommandData data) {
        return openHomeUI((EntityPlayerMP)sender);
    }
}
