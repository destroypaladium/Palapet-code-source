//Decompiled by Procyon!

package fr.paladium.pet.server.commands.skill;

import fr.paladium.palaforgeutils.lib.subcommand.*;
import fr.paladium.palaforgeutils.lib.subcommand.base.impl.*;
import fr.paladium.palaforgeutils.lib.command.*;
import fr.paladium.palaforgeutils.lib.subcommand.base.*;
import fr.paladium.palaforgeutils.lib.subcommand.utils.*;
import net.minecraft.command.*;
import fr.paladium.palaforgeutils.lib.subcommand.data.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.constant.*;
import fr.paladium.pet.server.config.skill.*;
import fr.paladium.pet.common.network.data.additional.skill.*;
import java.util.*;
import fr.paladium.pet.server.skill.skill.*;
import fr.paladium.palaforgeutils.lib.chat.*;
import fr.paladium.palaconfiguration.server.utils.*;

public class SkillSubCommand extends ASubCommand
{
    public static final String NAME = "skill";
    public static final String PERMISSION = "palapet.command.skill";
    public static final String SKILL_ARG_NAME = "(skill)";
    private static SkillSubCommand instance;
    private String[] skillNames;
    
    public SkillSubCommand() {
        SkillSubCommand.instance = this;
        this.skillNames = new String[0];
        final ASubCommand equipSub = (ASubCommand)StringSubCommand.create("equip").build((ASubCommand)this);
        final ASubCommand skillSub = (ASubCommand)FreeSubCommand.create("(skill)", "", this.skillNames).build(equipSub);
        final ASubCommand slotSub = (ASubCommand)NumberSubCommand.create("(slot)", "D\u00e9finir un skill (slot)").build(skillSub, this.equip());
        slotSub.getBuilder().sender(new SenderType[] { SenderType.PLAYER });
        final ASubCommand useSub = (ASubCommand)StringSubCommand.create("use").build((ASubCommand)this);
        final ASubCommand numberSub = (ASubCommand)NumberSubCommand.create("(slot)", "Utiliser un skill (slot)").build(useSub, this.use());
        numberSub.getBuilder().sender(new SenderType[] { SenderType.PLAYER });
        final ASubCommand useNameSub = (ASubCommand)StringSubCommand.create("use-name").build((ASubCommand)this);
        final ASubCommand freeSub = (ASubCommand)FreeSubCommand.create("(skill)", "", this.skillNames).build(useNameSub, this.useName());
        freeSub.getBuilder().sender(new SenderType[] { SenderType.PLAYER });
        StringSubCommand.create("list", "Liste des missions").build((ASubCommand)this, this.list());
        final ASubCommand infoSub = (ASubCommand)StringSubCommand.create("info").build((ASubCommand)this);
        FreeSubCommand.create("(skill)", "informations d'un skill", this.skillNames).build(infoSub, this.name());
    }
    
    private ISubCallback name() {
        return (sender, data) -> {
            final SkillConfig config = SkillConfig.get();
            final String id = data.getFreeArg();
            final Optional<Skill> result = config.findSkillById(id);
            if (!result.isPresent()) {
                PetTranslateEnum.MESSAGE_SKILL_NO_FOUND.message(sender, new Object[] { id });
                return true;
            }
            final Skill skill = result.get();
            ChatUtils.sendColoredMessage(sender, new String[] { "�8�m---------------------------------" });
            ConfigurationModUtils.sendJsonObject(sender, (Object)skill);
            ChatUtils.sendColoredMessage(sender, new String[] { "�8�m---------------------------------" });
            return true;
        };
    }
    
    private ISubCallback list() {
        return (sender, data) -> {
            ChatUtils.sendColoredMessage(sender, new String[] { "�8�m---------------------------------" });
            final SkillConfig config = SkillConfig.get();
            ChatUtils.sendColoredMessage(sender, new String[] { "�6Liste des skills" });
            for (final String skillName : this.skillNames) {
                final Optional<Skill> result = config.findSkillById(skillName);
                String prefix = "";
                if (result.isPresent()) {
                    final Skill skill = result.get();
                    prefix = ((skill.getType() == SkillType.ACTIVE) ? "�7(�aACTIF�7)" : "�7(�cPASSIF�7)");
                }
                ChatUtils.sendColoredMessage(sender, new String[] { "�e- " + prefix + " �e" + skillName });
            }
            ChatUtils.sendColoredMessage(sender, new String[] { "�8�m---------------------------------" });
            return true;
        };
    }
    
    private ISubCallback useName() {
        return (sender, data) -> {
            final EntityPlayerMP player = (EntityPlayerMP)sender;
            final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
            final String skillId = data.getFreeArg();
            final SkillConfig config = SkillConfig.get();
            final Optional<Skill> result = config.findSkillById(skillId);
            if (!result.isPresent()) {
                PetTranslateEnum.MESSAGE_NO_ACTIVE_SKILL_AT_SLOT.message((ICommandSender)player);
                return true;
            }
            final Skill skill = result.get();
            if (skill.getType() != SkillType.ACTIVE) {
                PetTranslateEnum.MESSAGE_NO_ACTIVE_SKILL_AT_SLOT.message((ICommandSender)player);
                return true;
            }
            final SkillData fakeData = new SkillData(skillId, 0L, 0L);
            skill.handle(player, pet, fakeData);
            return true;
        };
    }
    
    private ISubCallback use() {
        return (sender, data) -> {
            final EntityPlayerMP player = (EntityPlayerMP)sender;
            final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
            final int slot = data.getInteger();
            final SkillData skillData = pet.getSkill(slot);
            if (skillData == null) {
                PetTranslateEnum.MESSAGE_NO_ACTIVE_SKILL_AT_SLOT.message((ICommandSender)player);
                return true;
            }
            final SkillConfig config = SkillConfig.get();
            final Optional<Skill> result = config.findSkillById(skillData.getSkillId());
            if (!result.isPresent()) {
                PetTranslateEnum.MESSAGE_NO_ACTIVE_SKILL_AT_SLOT.message((ICommandSender)player);
                return true;
            }
            final Skill skill = result.get();
            if (skill.getType() != SkillType.ACTIVE) {
                PetTranslateEnum.MESSAGE_NO_ACTIVE_SKILL_AT_SLOT.message((ICommandSender)player);
                return true;
            }
            skill.handle(player, pet, skillData);
            pet.setLastSkillUsage(System.currentTimeMillis());
            pet.sync();
            return true;
        };
    }
    
    private ISubCallback equip() {
        return (sender, data) -> {
            final EntityPlayerMP player = (EntityPlayerMP)sender;
            final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
            final String skillId = data.getFreeArg();
            final int slot = data.getInteger();
            final SkillData skillData = pet.getSkill(slot);
            if (skillData == null || skillId == null) {
                PetTranslateEnum.MESSAGE_NO_SLOT.message((ICommandSender)player);
                return true;
            }
            final SkillConfig config = SkillConfig.get();
            final Optional<Skill> result = config.findSkillById(skillId);
            if (!result.isPresent()) {
                PetTranslateEnum.MESSAGE_NO_SKILL.message((ICommandSender)player);
                return true;
            }
            final Skill skill = result.get();
            skillData.changeSlotBypass(skill);
            PetTranslateEnum.MESSAGE_CHANGE_SKILL.message((ICommandSender)player, new Object[] { slot, skill.getName((EntityPlayer)player) });
            return true;
        };
    }
    
    public void updateSkills(final String[] skills) {
        this.skillNames = skills;
        for (final ASubCommand sub : SubCommandUtils.extractSubCommands((ASubCommand)this)) {
            if (sub.func_71517_b().equalsIgnoreCase("(skill)")) {
                sub.getBuilder().freeArgument(skills);
            }
        }
    }
    
    public static SkillSubCommand getInstance() {
        return SkillSubCommand.instance;
    }
}
