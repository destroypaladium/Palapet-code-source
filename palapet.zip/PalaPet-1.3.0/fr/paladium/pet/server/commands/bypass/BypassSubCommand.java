//Decompiled by Procyon!

package fr.paladium.pet.server.commands.bypass;

import fr.paladium.palaforgeutils.lib.subcommand.*;
import fr.paladium.palaforgeutils.lib.subcommand.base.impl.*;
import net.minecraft.command.*;
import fr.paladium.palaforgeutils.lib.subcommand.data.*;
import fr.paladium.pet.server.skill.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.constant.*;
import java.util.*;

public class BypassSubCommand extends ASubCommand
{
    public static final String NAME = "bypass";
    public static final String PERMISSION = "paladium.pet.bypass";
    public static final String DESCRIPTION = "Bypass un joueur";
    public static BypassSubCommand INSTANCE;
    
    public BypassSubCommand() {
        BypassSubCommand.INSTANCE = this;
        final ASubCommand playerSub = (ASubCommand)PlayerSubCommand.create("(player)", "Bypass un joueur").build((ASubCommand)this, (sender, data) -> {
            final Optional<EntityPlayerMP> result = (Optional<EntityPlayerMP>)data.getTargetedPlayer();
            if (!result.isPresent()) {
                return false;
            }
            final HashSet<UUID> bypassSet = SkillManager.getInstance().getBypassSet();
            final EntityPlayerMP target = result.get();
            final UUID uniqueId = target.func_110124_au();
            if (bypassSet.contains(uniqueId)) {
                bypassSet.remove(uniqueId);
                PetTranslateEnum.MESSAGE_BYPASS_REMOVE.message(sender, new Object[] { target.func_70005_c_() });
            }
            else {
                bypassSet.add(uniqueId);
                PetTranslateEnum.MESSAGE_BYPASS_ADD.message(sender, new Object[] { target.func_70005_c_() });
            }
            return true;
        });
    }
}
