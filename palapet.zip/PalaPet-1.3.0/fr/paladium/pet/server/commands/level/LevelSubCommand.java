//Decompiled by Procyon!

package fr.paladium.pet.server.commands.level;

import fr.paladium.palaforgeutils.lib.subcommand.*;
import fr.paladium.palaforgeutils.lib.subcommand.base.impl.*;
import fr.paladium.palaforgeutils.lib.subcommand.base.*;
import net.minecraft.command.*;
import fr.paladium.palaforgeutils.lib.subcommand.data.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.constant.*;
import java.util.*;

public class LevelSubCommand extends ASubCommand
{
    public static final String NAME = "level";
    public static final String PERMISSION = "paladium.pet.level";
    
    public LevelSubCommand() {
        final ASubCommand playerSub = (ASubCommand)PlayerSubCommand.create("(player)").build((ASubCommand)this);
        final ASubCommand setSub = (ASubCommand)StringSubCommand.create("set").build(playerSub);
        final ASubCommand numberSub = (ASubCommand)NumberSubCommand.create("(value)", "d\u00e9finir le level du familier", (Number)1, (Number)100).build(setSub, this.set());
    }
    
    private ISubCallback set() {
        return (sender, data) -> {
            final Optional<EntityPlayerMP> result = (Optional<EntityPlayerMP>)data.getTargetedPlayer();
            if (!result.isPresent()) {
                return false;
            }
            final EntityPlayerMP target = result.get();
            final PetPlayer pet = PetPlayer.get((EntityPlayer)target);
            final int value = data.getInteger();
            if (pet == null || !pet.has()) {
                PetTranslateEnum.MESSAGE_TARGET_NO_PET.message(sender, new Object[] { target.func_70005_c_() });
                return true;
            }
            pet.setLevel((EntityPlayer)target, value);
            PetTranslateEnum.MESSAGE_LEVEL_SET.message(sender, new Object[] { target.func_70005_c_(), value });
            PetTranslateEnum.MESSAGE_LEVEL_SET_TARGET.message((ICommandSender)target, new Object[] { sender.func_70005_c_(), value });
            return true;
        };
    }
}
