//Decompiled by Procyon!

package fr.paladium.pet.server.commands.assignment;

import fr.paladium.palaforgeutils.lib.subcommand.*;
import fr.paladium.palaforgeutils.lib.subcommand.base.impl.*;
import fr.paladium.palaforgeutils.lib.subcommand.base.*;
import fr.paladium.palaforgeutils.lib.subcommand.utils.*;
import net.minecraft.command.*;
import fr.paladium.palaforgeutils.lib.subcommand.data.*;
import fr.paladium.palaforgeutils.lib.chat.*;
import fr.paladium.pet.common.constant.*;
import fr.paladium.pet.server.config.assignment.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.common.utils.*;
import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.pet.common.network.data.additional.assignment.*;
import fr.paladium.pet.common.*;
import fr.paladium.pet.common.network.packet.pet.*;
import java.util.*;
import cpw.mods.fml.common.network.simpleimpl.*;

public class AssignmentSubCommand extends ASubCommand
{
    public static final String NAME = "assignment";
    public static final String PERMISSION = "palapet.command.assignment";
    public static final String NAME_ARG_NAME = "(name)";
    private static AssignmentSubCommand instance;
    private String[] assignmentNames;
    
    public AssignmentSubCommand() {
        this.assignmentNames = new String[0];
        AssignmentSubCommand.instance = this;
        StringSubCommand.create("list", "Liste des missions").build((ASubCommand)this, this.list());
        final ASubCommand infoSub = (ASubCommand)StringSubCommand.create("info").build((ASubCommand)this);
        FreeSubCommand.create("(name)", "informations d'une mission", this.assignmentNames).build(infoSub, this.name());
        final ASubCommand reloadSub = (ASubCommand)StringSubCommand.create("reset").build((ASubCommand)this);
        PlayerSubCommand.create("(player)", "reset les missions d'un joueur").build(reloadSub, this.reset());
        StringSubCommand.create("debug", "Ouvre l'interface de debug").build((ASubCommand)this, this.debug());
    }
    
    private ISubCallback debug() {
        return (sender, data) -> {
            final EntityPlayerMP player = (EntityPlayerMP)sender;
            final List<AssignmentClientData> assignments = new ArrayList<AssignmentClientData>();
            final AssignmentConfig config = AssignmentConfig.get();
            for (final Assignment assignment : config.getAssignments()) {
                assignments.add(AssignmentClientData.from((EntityPlayer)player, assignment, new AssignmentData(assignment.getId())));
            }
            PetCommonProxy.getInstance().getNetwork().sendTo((IMessage)new SCOpenDebugUIPacket((List)assignments), player);
            return true;
        };
    }
    
    private ISubCallback reset() {
        return (sender, data) -> {
            final Optional<EntityPlayerMP> result = (Optional<EntityPlayerMP>)data.getTargetedPlayer();
            if (!result.isPresent()) {
                return false;
            }
            final EntityPlayerMP player = result.get();
            final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
            if (pet == null) {
                return false;
            }
            pet.pickupAssignments(player, System.currentTimeMillis());
            PetUtils.sendPrefixedMessage(sender, new String[] { "�aLes missions de �e" + player.func_70005_c_() + "�a ont \u00e9t\u00e9 reset." });
            PetUtils.sendPrefixedMessage((ICommandSender)player, new String[] { "�aVos missions ont \u00e9t\u00e9 reset." });
            return true;
        };
    }
    
    private ISubCallback name() {
        return (sender, data) -> {
            final AssignmentConfig config = AssignmentConfig.get();
            final String id = data.getFreeArg();
            final Optional<Assignment> result = config.findAssignmentById(id);
            if (!result.isPresent()) {
                PetTranslateEnum.MESSAGE_MISSION_NOT_FOUND.message(sender, new Object[] { id });
                return true;
            }
            final Assignment assignment = result.get();
            ChatUtils.sendColoredMessage(sender, new String[] { "�8�m---------------------------------" });
            ChatUtils.sendColoredMessage(sender, new String[] { "�6Informations de la mission �d" + assignment.getId() });
            ChatUtils.sendColoredMessage(sender, new String[] { "�e- �dType: �e" + assignment.getType().name() });
            ChatUtils.sendColoredMessage(sender, new String[] { "�e- �dNiveau: �e" + assignment.getLevelRange().getMin() + " - " + assignment.getLevelRange().getMax() });
            ChatUtils.sendColoredMessage(sender, new String[] { "�e- �dDescription: �e" + assignment.getDescription(null) });
            ChatUtils.sendColoredMessage(sender, new String[] { "�e- �dWeight: �e" + assignment.getWeight() });
            ChatUtils.sendColoredMessage(sender, new String[] { "�e- �dPoints: �e" + assignment.getGivenPoints() });
            ChatUtils.sendColoredMessage(sender, new String[] { "�e- �dExperience: �e" + assignment.getGivenExp() });
            ChatUtils.sendColoredMessage(sender, new String[] { "�e- �dAmount (objectif): �e" + assignment.getAmount() });
            ChatUtils.sendColoredMessage(sender, new String[] { "�8�m---------------------------------" });
            return true;
        };
    }
    
    private ISubCallback list() {
        return (sender, data) -> {
            ChatUtils.sendColoredMessage(sender, new String[] { "�8�m---------------------------------" });
            ChatUtils.sendColoredMessage(sender, new String[] { "�6Liste des missions" });
            for (final String assignmentName : this.assignmentNames) {
                ChatUtils.sendColoredMessage(sender, new String[] { "�e- �d" + assignmentName });
            }
            ChatUtils.sendColoredMessage(sender, new String[] { "�8�m---------------------------------" });
            return true;
        };
    }
    
    public void updateAssignments(final String[] assignments) {
        this.assignmentNames = assignments;
        for (final ASubCommand sub : SubCommandUtils.extractSubCommands((ASubCommand)this)) {
            if (sub.func_71517_b().equalsIgnoreCase("(name)")) {
                sub.getBuilder().freeArgument(assignments);
                break;
            }
        }
    }
    
    public static AssignmentSubCommand getInstance() {
        return AssignmentSubCommand.instance;
    }
}
