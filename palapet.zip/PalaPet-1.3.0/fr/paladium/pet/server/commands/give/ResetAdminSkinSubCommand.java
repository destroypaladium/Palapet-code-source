//Decompiled by Procyon!

package fr.paladium.pet.server.commands.give;

import fr.paladium.palaforgeutils.lib.subcommand.*;
import fr.paladium.palaforgeutils.lib.subcommand.base.impl.*;
import net.minecraft.command.*;
import fr.paladium.palaforgeutils.lib.subcommand.data.*;
import fr.paladium.palaforgeutils.lib.bukkit.*;
import net.minecraft.entity.*;
import fr.paladium.palaforgeutils.lib.chat.*;
import fr.paladium.pet.common.provider.*;
import net.minecraft.entity.player.*;
import java.util.*;

public class ResetAdminSkinSubCommand extends ASubCommand
{
    public static final String NAME = "reset-admin";
    public static final String DESCRIPTION = "Reset les skins d'un admin";
    public static final String PERMISSION = "palapet.command.reset.admin";
    
    public ResetAdminSkinSubCommand() {
        final ASubCommand playerSub = (ASubCommand)PlayerSubCommand.create("(player)", "Reset les skins d'un admin").build((ASubCommand)this, (sender, data) -> {
            final Optional<EntityPlayerMP> result = (Optional<EntityPlayerMP>)data.getTargetedPlayer();
            if (!result.isPresent()) {
                return false;
            }
            final EntityPlayerMP player = result.get();
            if (!BukkitUtils.hasPermission((Entity)player, "palapet.command.reset.admin")) {
                ChatUtils.sendColoredMessage(sender, new String[] { "�cLe joueur " + player.func_70005_c_() + " n'est pas un admin" });
                return true;
            }
            final PetSkinShopProvider provider = PetSkinShopProvider.getInstance();
            provider.clearSkins((EntityPlayer)player);
            ChatUtils.sendColoredMessage(sender, new String[] { "�aLes skins de " + player.func_70005_c_() + " ont \u00e9t\u00e9 r\u00e9initialis\u00e9s" });
            return true;
        });
    }
}
