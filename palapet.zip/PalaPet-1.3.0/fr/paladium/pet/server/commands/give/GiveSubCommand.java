//Decompiled by Procyon!

package fr.paladium.pet.server.commands.give;

import fr.paladium.palaforgeutils.lib.subcommand.*;
import fr.paladium.pet.common.*;
import fr.paladium.pet.common.pet.*;
import java.util.function.*;
import fr.paladium.palaforgeutils.lib.subcommand.base.impl.*;
import net.minecraft.command.*;
import fr.paladium.palaforgeutils.lib.subcommand.data.*;
import fr.paladium.pet.common.provider.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.palaforgeutils.lib.chat.*;
import java.util.*;

public class GiveSubCommand extends ASubCommand
{
    public static final String NAME = "give";
    public static final String DESCRIPTION = "Give un skin \u00e0 un joueur";
    public static final String PERMISSION = "palapet.command.give";
    
    public GiveSubCommand() {
        final String[] skins = (String[])PetCommonProxy.getInstance().getPets().stream().map(PetAdditionalData::getName).toArray(String[]::new);
        final ASubCommand playerSub = (ASubCommand)PlayerSubCommand.create("(player)").build((ASubCommand)this);
        final ASubCommand skinSub = (ASubCommand)FreeSubCommand.create("(skinId)", "Give un skin \u00e0 un joueur", skins).build(playerSub, (sender, data) -> {
            final Optional<EntityPlayerMP> result = (Optional<EntityPlayerMP>)data.getTargetedPlayer();
            if (!result.isPresent()) {
                return false;
            }
            final PetSkinShopProvider provider = PetSkinShopProvider.getInstance();
            final PetAdditionalData skin = PetCommonProxy.getInstance().findPet(data.getFreeArg());
            if (skin == null) {
                return false;
            }
            final EntityPlayerMP player = result.get();
            final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
            final String skinName = provider.getTranslatedSkinName(skin.getName());
            if (pet.hasSkin((EntityPlayer)player, skin.getName())) {
                ChatUtils.sendColoredMessage(sender, new String[] { "�cLe joueur �c" + player.func_70005_c_() + " �eposs\u00e8de d\u00e9j\u00e0 le skin �6" + skinName });
                return true;
            }
            provider.addSkin((EntityPlayer)player, skin.getName());
            ChatUtils.sendColoredMessage(sender, new String[] { "�eVous avez bien donn\u00e9 le skin �c" + skinName + " �e\u00e0 �a" + player.func_70005_c_() });
            return true;
        });
    }
}
