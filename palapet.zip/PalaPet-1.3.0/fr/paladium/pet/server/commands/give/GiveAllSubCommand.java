//Decompiled by Procyon!

package fr.paladium.pet.server.commands.give;

import fr.paladium.palaforgeutils.lib.subcommand.*;
import fr.paladium.palaforgeutils.lib.subcommand.base.impl.*;
import net.minecraft.command.*;
import fr.paladium.palaforgeutils.lib.subcommand.data.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.provider.*;
import fr.paladium.pet.common.*;
import fr.paladium.pet.common.pet.*;
import fr.paladium.palaforgeutils.lib.chat.*;
import java.util.*;

public class GiveAllSubCommand extends ASubCommand
{
    public static final String NAME = "give-all";
    public static final String DESCRIPTION = "Give tous les skins \u00e0 un joueur";
    public static final String PERMISSION = "palapet.command.give";
    
    public GiveAllSubCommand() {
        final ASubCommand playerSub = (ASubCommand)PlayerSubCommand.create("(player)", "Give tous les skins \u00e0 un joueur").build((ASubCommand)this, (sender, data) -> {
            final Optional<EntityPlayerMP> result = (Optional<EntityPlayerMP>)data.getTargetedPlayer();
            if (!result.isPresent()) {
                return false;
            }
            final EntityPlayerMP player = result.get();
            final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
            final PetSkinShopProvider provider = PetSkinShopProvider.getInstance();
            for (final PetAdditionalData skin : PetCommonProxy.getInstance().getPets()) {
                final String skinName = provider.getTranslatedSkinName(skin.getName());
                if (pet.hasSkin((EntityPlayer)player, skin.getName())) {
                    ChatUtils.sendColoredMessage(sender, new String[] { "�cLe joueur �c" + player.func_70005_c_() + " �eposs\u00e8de d\u00e9j\u00e0 le skin �6" + skinName });
                }
                else {
                    PetSkinShopProvider.getInstance().addSkin((EntityPlayer)player, skin.getName());
                    ChatUtils.sendColoredMessage(sender, new String[] { "�eVous avez bien donn\u00e9 le skin �c" + skinName + " �e\u00e0 �a" + player.func_70005_c_() });
                }
            }
            return true;
        });
    }
}
