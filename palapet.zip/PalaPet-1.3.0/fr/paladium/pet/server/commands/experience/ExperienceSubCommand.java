//Decompiled by Procyon!

package fr.paladium.pet.server.commands.experience;

import fr.paladium.palaforgeutils.lib.subcommand.*;
import fr.paladium.palaforgeutils.lib.subcommand.base.impl.*;
import fr.paladium.palaforgeutils.lib.subcommand.base.*;
import net.minecraft.command.*;
import fr.paladium.palaforgeutils.lib.subcommand.data.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.constant.*;
import java.util.*;

public class ExperienceSubCommand extends ASubCommand
{
    public static final String NAME = "experience";
    public static final String PERMISSION = "paladium.pet.experience";
    
    public ExperienceSubCommand() {
        final ASubCommand playerSub = (ASubCommand)PlayerSubCommand.create("(player)").build((ASubCommand)this);
        final ASubCommand setSub = (ASubCommand)StringSubCommand.create("set").build(playerSub);
        final ASubCommand numberSub = (ASubCommand)NumberSubCommand.create("(value)", "d\u00e9finir l'EXP du familier").build(setSub, this.set());
        final ASubCommand addSub = (ASubCommand)StringSubCommand.create("add").build(playerSub);
        final ASubCommand numberSub2 = (ASubCommand)NumberSubCommand.create("(value)", "ajouter de l'EXP au familier").build(addSub, this.add());
    }
    
    private ISubCallback add() {
        return (sender, data) -> {
            final Optional<EntityPlayerMP> result = (Optional<EntityPlayerMP>)data.getTargetedPlayer();
            if (!result.isPresent()) {
                return false;
            }
            final EntityPlayerMP target = result.get();
            final PetPlayer pet = PetPlayer.get((EntityPlayer)target);
            final int value = data.getInteger();
            if (pet == null || !pet.has()) {
                PetTranslateEnum.MESSAGE_TARGET_NO_PET.message(sender, new Object[] { target.func_70005_c_() });
                return true;
            }
            pet.addExperience((EntityPlayer)target, (double)value);
            PetTranslateEnum.MESSAGE_EXPERIENCE_ADD.message(sender, new Object[] { target.func_70005_c_(), value });
            PetTranslateEnum.MESSAGE_EXPERIENCE_ADD_TARGET.message((ICommandSender)target, new Object[] { sender.func_70005_c_(), value });
            return true;
        };
    }
    
    private ISubCallback set() {
        return (sender, data) -> {
            final Optional<EntityPlayerMP> result = (Optional<EntityPlayerMP>)data.getTargetedPlayer();
            if (!result.isPresent()) {
                return false;
            }
            final EntityPlayerMP target = result.get();
            final PetPlayer pet = PetPlayer.get((EntityPlayer)target);
            final int value = data.getInteger();
            if (pet == null || !pet.has()) {
                PetTranslateEnum.MESSAGE_TARGET_NO_PET.message(sender, new Object[] { target.func_70005_c_() });
                return true;
            }
            pet.setExperience((EntityPlayer)target, (double)value);
            PetTranslateEnum.MESSAGE_EXPERIENCE_SET.message(sender, new Object[] { target.func_70005_c_(), value });
            PetTranslateEnum.MESSAGE_EXPERIENCE_SET_TARGET.message((ICommandSender)target, new Object[] { sender.func_70005_c_(), value });
            return true;
        };
    }
}
