//Decompiled by Procyon!

package fr.paladium.pet.server.skill;

import fr.paladium.pet.server.skill.handler.*;
import java.util.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.server.config.skill.*;
import fr.paladium.pet.server.skill.skill.*;

public class SkillManager
{
    private static SkillManager instance;
    private HashSet<ASkillHandler> handlers;
    private HashSet<UUID> bypassSet;
    
    public SkillManager() {
        SkillManager.instance = this;
        this.handlers = new HashSet<ASkillHandler>();
        this.bypassSet = new HashSet<UUID>();
    }
    
    public static SkillManager getInstance() {
        if (SkillManager.instance == null) {
            SkillManager.instance = new SkillManager();
        }
        return SkillManager.instance;
    }
    
    public boolean isBypassed(final EntityPlayer player) {
        return this.bypassSet.contains(player.func_110124_au());
    }
    
    public void registerHandler(final Class<? extends ASkillHandler> clazz) {
        try {
            final ASkillHandler handler = (ASkillHandler)clazz.newInstance();
            this.handlers.add(handler);
        }
        catch (InstantiationException | IllegalAccessException ex2) {
            final ReflectiveOperationException ex;
            final ReflectiveOperationException e = ex;
            e.printStackTrace();
        }
    }
    
    public void updateSkills() {
        final SkillConfig config = SkillConfig.get();
        final Skill skill;
        this.handlers.forEach(handler -> {
            skill = config.findSkillById(handler.getId()).orElse(null);
            if (skill != null) {
                skill.setHandler(handler);
            }
        });
    }
    
    public HashSet<ASkillHandler> getHandlers() {
        return this.handlers;
    }
    
    public HashSet<UUID> getBypassSet() {
        return this.bypassSet;
    }
}
