//Decompiled by Procyon!

package fr.paladium.pet.server.skill.handler.impl.active;

import fr.paladium.pet.server.skill.handler.*;
import net.minecraft.world.*;
import fr.paladium.palajobs.utils.forge.location.*;
import net.minecraft.init.*;
import fr.paladium.pet.common.utils.*;
import net.minecraft.entity.player.*;
import java.util.*;
import net.minecraft.block.*;
import fr.paladium.pet.common.network.data.*;

public class BedrockDrillSkill extends ASkillHandler
{
    public static final String ID = "bedrock_drill";
    
    public BedrockDrillSkill() {
        super("bedrock_drill");
    }
    
    private Cuboid getCuboid(final EntityPlayerMP player, final World world, final double value) {
        return new Cuboid(world, player.field_70165_t + value, player.field_70163_u - 1.0, player.field_70161_v + value, player.field_70165_t, player.field_70163_u - 1.0, player.field_70161_v);
    }
    
    public boolean drill(final EntityPlayerMP player, final World world, final double value) {
        final Cuboid cuboid = this.getCuboid(player, world, value);
        for (final Location location : cuboid.getLocations()) {
            final int blockX = location.getBlockX();
            final int blockY = location.getBlockY();
            final int blockZ = location.getBlockZ();
            final Block block = world.func_147439_a(blockX, blockY, blockZ);
            if (!block.equals(Blocks.field_150357_h)) {
                continue;
            }
            final Block upperBlock = world.func_147439_a(blockX, blockY + 1, blockZ);
            if (upperBlock.equals(Blocks.field_150357_h)) {
                continue;
            }
            if (!PetUtils.canInteractBedrock((EntityPlayer)player, blockX, blockY, blockZ)) {
                continue;
            }
            world.func_147468_f(blockX, blockY, blockZ);
        }
        return true;
    }
    
    public boolean perform(final EntityPlayerMP player, final PetPlayer pet) {
        double value = this.getSkill().getPersonalValue(pet) - 1.0;
        if (value <= 1.0) {
            value = 1.0;
        }
        value = Math.ceil(value);
        return this.drill(player, player.field_70170_p, value);
    }
}
