//Decompiled by Procyon!

package fr.paladium.pet.server.skill.handler.impl.active;

import fr.paladium.pet.server.skill.handler.*;
import java.util.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.command.*;

public class EnchantedSkill extends ASkillHandler
{
    public static final String ID = "enchanted";
    public static final HashMap<UUID, Integer> VALUES;
    
    public EnchantedSkill() {
        super("enchanted");
    }
    
    public boolean perform(final EntityPlayerMP player, final PetPlayer pet) {
        final double value = this.getSkill().getPersonalValue(pet);
        if (value <= 0.0) {
            return false;
        }
        final int intValue = (int)Math.ceil(value);
        EnchantedSkill.VALUES.put(player.func_110124_au(), intValue);
        PetTranslateEnum.MESSAGE_ENCHANTED_ENABLED.message((ICommandSender)player, new Object[] { intValue });
        return true;
    }
    
    static {
        VALUES = new HashMap<UUID, Integer>();
    }
}
