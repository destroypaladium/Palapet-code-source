//Decompiled by Procyon!

package fr.paladium.pet.server.skill.handler.impl.active;

import fr.paladium.pet.server.skill.handler.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;

public class PocketHappinessSkill extends ASkillHandler
{
    public static final String ID = "pocket_happiness";
    
    public PocketHappinessSkill() {
        super("pocket_happiness");
    }
    
    public boolean perform(final EntityPlayerMP player, final PetPlayer pet) {
        final double value = this.getSkill().getPersonalValue(pet);
        if (value <= 0.0) {
            return false;
        }
        pet.earnHappiness(player, (int)value);
        return true;
    }
}
