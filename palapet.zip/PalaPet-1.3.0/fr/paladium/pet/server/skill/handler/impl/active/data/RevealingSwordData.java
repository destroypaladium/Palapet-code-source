//Decompiled by Procyon!

package fr.paladium.pet.server.skill.handler.impl.active.data;

import net.minecraft.entity.*;

public class RevealingSwordData
{
    private long durationMillis;
    private long expirationMillis;
    private String targetName;
    
    public RevealingSwordData(final long durationMillis) {
        this.durationMillis = durationMillis;
    }
    
    public void update(final EntityLivingBase living) {
        this.targetName = living.func_70005_c_();
        this.expirationMillis = System.currentTimeMillis() + this.durationMillis;
    }
    
    public boolean isExpired() {
        return System.currentTimeMillis() >= this.expirationMillis;
    }
    
    public long getDurationMillis() {
        return this.durationMillis;
    }
    
    public long getExpirationMillis() {
        return this.expirationMillis;
    }
    
    public String getTargetName() {
        return this.targetName;
    }
    
    public void setDurationMillis(final long durationMillis) {
        this.durationMillis = durationMillis;
    }
    
    public void setExpirationMillis(final long expirationMillis) {
        this.expirationMillis = expirationMillis;
    }
    
    public void setTargetName(final String targetName) {
        this.targetName = targetName;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof RevealingSwordData)) {
            return false;
        }
        final RevealingSwordData other = (RevealingSwordData)o;
        if (!other.canEqual(this)) {
            return false;
        }
        if (this.getDurationMillis() != other.getDurationMillis()) {
            return false;
        }
        if (this.getExpirationMillis() != other.getExpirationMillis()) {
            return false;
        }
        final Object this$targetName = this.getTargetName();
        final Object other$targetName = other.getTargetName();
        if (this$targetName == null) {
            if (other$targetName == null) {
                return true;
            }
        }
        else if (this$targetName.equals(other$targetName)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof RevealingSwordData;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final long $durationMillis = this.getDurationMillis();
        result = result * 59 + (int)($durationMillis >>> 32 ^ $durationMillis);
        final long $expirationMillis = this.getExpirationMillis();
        result = result * 59 + (int)($expirationMillis >>> 32 ^ $expirationMillis);
        final Object $targetName = this.getTargetName();
        result = result * 59 + (($targetName == null) ? 43 : $targetName.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "RevealingSwordData(durationMillis=" + this.getDurationMillis() + ", expirationMillis=" + this.getExpirationMillis() + ", targetName=" + this.getTargetName() + ")";
    }
}
