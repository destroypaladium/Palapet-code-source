//Decompiled by Procyon!

package fr.paladium.pet.server.skill.handler;

import fr.paladium.pet.server.skill.skill.*;
import fr.paladium.pet.common.network.data.*;

public class PassiveResponse
{
    public static final double NONE_VALUE = 0.0;
    private final boolean has;
    private final Skill skill;
    
    public boolean has(final double value) {
        return (this.skill != null && this.has && this.skill.getValue() <= 0.0) || (this.has && value > 0.0);
    }
    
    public double getPersonalValue(final PetPlayer pet) {
        if (this.skill == null) {
            return 0.0;
        }
        if (!pet.isSkillSelected(this.skill)) {
            return 0.0;
        }
        return this.skill.getPersonalValue(pet);
    }
    
    public double getValueAsPercent(final double value) {
        if (value <= 0.0) {
            return 0.0;
        }
        return value / 100.0;
    }
    
    public boolean isHas() {
        return this.has;
    }
    
    public Skill getSkill() {
        return this.skill;
    }
    
    public PassiveResponse(final boolean has, final Skill skill) {
        this.has = has;
        this.skill = skill;
    }
}
