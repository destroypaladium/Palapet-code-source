//Decompiled by Procyon!

package fr.paladium.pet.server.skill.handler;

import fr.paladium.pet.server.skill.skill.*;
import fr.paladium.pet.server.config.skill.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.common.network.data.additional.skill.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.command.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.server.skill.*;
import fr.paladium.palaforgeutils.lib.task.*;
import fr.paladium.pet.common.event.skill.*;
import net.minecraftforge.common.*;
import cpw.mods.fml.common.eventhandler.*;
import java.util.concurrent.*;

public abstract class ASkillHandler
{
    private String id;
    
    public ASkillHandler(final String id) {
        this.id = id;
    }
    
    public Skill getSkill() {
        return SkillConfig.get().getActive(this.id);
    }
    
    public abstract boolean perform(final EntityPlayerMP p0, final PetPlayer p1);
    
    public void handle(final EntityPlayerMP player, final PetPlayer pet, final SkillData data) {
        final Skill skill = this.getSkill();
        if (skill == null) {
            PetTranslateEnum.MESSAGE_SKILL_NO_FOUND.message((ICommandSender)player);
            return;
        }
        final String skillName = skill.getName((EntityPlayer)player);
        final long now = System.currentTimeMillis();
        final long cooldown = skill.getCooldown(now, data.getNextUseMillis());
        if (!SkillManager.getInstance().isBypassed((EntityPlayer)player) && skill.isOnCooldown(cooldown)) {
            PetTranslateEnum.MESSAGE_SKILL_ON_COOLDOWN.message((ICommandSender)player, new Object[] { skillName, DurationConverter.fromMillisToString(cooldown) });
            return;
        }
        final ActiveSkillUsedEvent event = new ActiveSkillUsedEvent((EntityPlayer)player, pet, skill);
        if (MinecraftForge.EVENT_BUS.post((Event)event)) {
            return;
        }
        if (!this.perform(player, pet)) {
            PetTranslateEnum.MESSAGE_CANT_USE_SKILL.message((ICommandSender)player, new Object[] { skillName });
            return;
        }
        PetTranslateEnum.MESSAGE_SKILL_USED.message((ICommandSender)player, new Object[] { skillName });
        final long cooldownReduction = this.applyPetSkillCooldownReduction(TimeUnit.MINUTES.toMillis(skill.getCooldownInMinutes()), pet);
        data.use(pet, now + cooldownReduction);
        pet.setLastSkillUsage(now);
    }
    
    private long applyPetSkillCooldownReduction(final long cooldownMillis, final PetPlayer pet) {
        final PassiveResponse response = PassiveSkillEnum.BOOSTED_HARVEST.getResponse(pet, SkillConfig.get());
        final double value = response.getPersonalValue(pet);
        if (!response.has(value)) {
            return cooldownMillis;
        }
        final long bonus = (long)(cooldownMillis * response.getValueAsPercent(value));
        return cooldownMillis - bonus;
    }
    
    public String getId() {
        return this.id;
    }
    
    public void setId(final String id) {
        this.id = id;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof ASkillHandler)) {
            return false;
        }
        final ASkillHandler other = (ASkillHandler)o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$id = this.getId();
        final Object other$id = other.getId();
        if (this$id == null) {
            if (other$id == null) {
                return true;
            }
        }
        else if (this$id.equals(other$id)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof ASkillHandler;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $id = this.getId();
        result = result * 59 + (($id == null) ? 43 : $id.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "ASkillHandler(id=" + this.getId() + ")";
    }
}
