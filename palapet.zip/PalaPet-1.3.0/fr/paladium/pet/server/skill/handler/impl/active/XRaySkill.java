//Decompiled by Procyon!

package fr.paladium.pet.server.skill.handler.impl.active;

import fr.paladium.pet.server.skill.handler.*;
import net.minecraft.init.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.palaforgeutils.lib.task.*;
import net.minecraft.world.*;
import fr.paladium.palajobs.utils.forge.location.*;
import net.minecraft.block.*;
import fr.paladium.pet.common.utils.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.server.skill.listener.tickable.*;
import fr.paladium.pet.server.skill.handler.impl.active.data.*;
import java.util.*;

public class XRaySkill extends ASkillHandler
{
    public static final String ID = "x_ray";
    private final List<Block> whitelistedBlocks;
    
    public XRaySkill() {
        super("x_ray");
        this.whitelistedBlocks = Arrays.asList(Blocks.field_150348_b, Blocks.field_150347_e, Blocks.field_150351_n, (Block)Blocks.field_150354_m, Blocks.field_150355_j, (Block)Blocks.field_150358_i, Blocks.field_150353_l, (Block)Blocks.field_150356_k, Blocks.field_150346_d, (Block)Blocks.field_150349_c, Blocks.field_150322_A, Blocks.field_150424_aL);
    }
    
    public boolean perform(final EntityPlayerMP player, final PetPlayer pet) {
        final double value = this.getSkill().getPersonalValue(pet);
        if (value <= 1.0) {
            return false;
        }
        final XraySkillTask task = new XraySkillTask(player, value, this.whitelistedBlocks);
        task.start();
        return true;
    }
    
    @Schedule(async = true, repeat = 1)
    public static class XraySkillTask extends ATask
    {
        private final EntityPlayerMP player;
        private final List<Block> whitelistedBlocks;
        private final double value;
        
        public XraySkillTask(final EntityPlayerMP player, final double value, final List<Block> whitelistedBlocks) {
            super("XRay-" + UUID.randomUUID());
            this.player = player;
            this.value = value;
            this.whitelistedBlocks = whitelistedBlocks;
        }
        
        private boolean isWhitelisted(final Block block) {
            return this.whitelistedBlocks.contains(block);
        }
        
        private Cuboid getCuboid(final EntityPlayerMP player, final World world, final double value) {
            return new Cuboid(world, player.field_70165_t - value, player.field_70163_u - value, player.field_70161_v - value, player.field_70165_t + value, player.field_70163_u + value, player.field_70161_v + value);
        }
        
        public void pickaxe(final EntityPlayerMP player, final World world, final double value) {
            final Cuboid cuboid = this.getCuboid(player, world, value);
            final long now = System.currentTimeMillis();
            int increment = 0;
            int currentBlocks = 0;
            for (final Location location : cuboid.getLocations()) {
                final int blockX = location.getBlockX();
                final int blockY = location.getBlockY();
                final int blockZ = location.getBlockZ();
                if (!world.func_72899_e(blockX, blockY, blockZ)) {
                    continue;
                }
                final Block block = world.func_147439_a(blockX, blockY, blockZ);
                if (block instanceof BlockAir || block instanceof BlockOre) {
                    continue;
                }
                if (!this.isWhitelisted(block)) {
                    continue;
                }
                if (!PetUtils.canInteract((EntityPlayer)player, block, blockX, blockY, blockZ)) {
                    continue;
                }
                TickableListener.XRAY_TICKABLES.add(BlockTickable.of(blockX, blockY, blockZ, Blocks.field_150350_a, now + 2L * increment));
                if (++currentBlocks < 10) {
                    continue;
                }
                ++increment;
                currentBlocks = 0;
            }
        }
        
        public void run() {
            if (this.player == null || this.player.field_70128_L) {
                return;
            }
            this.pickaxe(this.player, this.player.field_70170_p, this.value);
        }
    }
}
