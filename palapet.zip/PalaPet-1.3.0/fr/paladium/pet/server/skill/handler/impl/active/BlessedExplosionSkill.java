//Decompiled by Procyon!

package fr.paladium.pet.server.skill.handler.impl.active;

import fr.paladium.pet.server.skill.handler.*;
import java.util.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.command.*;

public class BlessedExplosionSkill extends ASkillHandler
{
    public static final String ID = "blessed_explosion";
    public static final int RADIUS = 5;
    public static final HashMap<UUID, Double> VALUES;
    
    public BlessedExplosionSkill() {
        super("blessed_explosion");
    }
    
    public boolean perform(final EntityPlayerMP player, final PetPlayer pet) {
        final double value = this.getSkill().getPersonalValue(pet);
        if (value <= 0.0) {
            return false;
        }
        BlessedExplosionSkill.VALUES.put(player.func_110124_au(), value);
        PetTranslateEnum.MESSAGE_BLESSED_EXPLOSION.message((ICommandSender)player, new Object[] { (int)value });
        return true;
    }
    
    static {
        VALUES = new HashMap<UUID, Double>();
    }
}
