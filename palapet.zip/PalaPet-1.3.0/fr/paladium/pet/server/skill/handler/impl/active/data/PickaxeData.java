//Decompiled by Procyon!

package fr.paladium.pet.server.skill.handler.impl.active.data;

public class PickaxeData
{
    private double value;
    private long expirationMillis;
    
    public double getValue() {
        return this.value;
    }
    
    public long getExpirationMillis() {
        return this.expirationMillis;
    }
    
    public void setValue(final double value) {
        this.value = value;
    }
    
    public void setExpirationMillis(final long expirationMillis) {
        this.expirationMillis = expirationMillis;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof PickaxeData)) {
            return false;
        }
        final PickaxeData other = (PickaxeData)o;
        return other.canEqual(this) && Double.compare(this.getValue(), other.getValue()) == 0 && this.getExpirationMillis() == other.getExpirationMillis();
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof PickaxeData;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final long $value = Double.doubleToLongBits(this.getValue());
        result = result * 59 + (int)($value >>> 32 ^ $value);
        final long $expirationMillis = this.getExpirationMillis();
        result = result * 59 + (int)($expirationMillis >>> 32 ^ $expirationMillis);
        return result;
    }
    
    @Override
    public String toString() {
        return "PickaxeData(value=" + this.getValue() + ", expirationMillis=" + this.getExpirationMillis() + ")";
    }
    
    public PickaxeData(final double value, final long expirationMillis) {
        this.value = value;
        this.expirationMillis = expirationMillis;
    }
}
