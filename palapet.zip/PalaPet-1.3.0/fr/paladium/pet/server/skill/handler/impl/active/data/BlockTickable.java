//Decompiled by Procyon!

package fr.paladium.pet.server.skill.handler.impl.active.data;

import net.minecraft.block.*;
import net.minecraft.world.*;

public class BlockTickable
{
    private int x;
    private int y;
    private int z;
    private Block block;
    private long pasteTime;
    
    public BlockTickable(final int x, final int y, final int z, final Block block, final long pasteTime) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.block = block;
        this.pasteTime = pasteTime;
    }
    
    public boolean paste(final World world, final long now) {
        if (now < this.pasteTime) {
            return false;
        }
        world.func_147449_b(this.x, this.y, this.z, this.block);
        return true;
    }
    
    public static BlockTickable of(final int x, final int y, final int z, final Block block, final long pasteTime) {
        return new BlockTickable(x, y, z, block, pasteTime);
    }
}
