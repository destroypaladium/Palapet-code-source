//Decompiled by Procyon!

package fr.paladium.pet.server.skill.handler.impl.active;

import fr.paladium.pet.server.skill.handler.*;
import java.util.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.command.*;

public class RepairSkill extends ASkillHandler
{
    public static final HashMap<UUID, Integer> VALUES;
    public static final String ID = "repair";
    
    public RepairSkill() {
        super("repair");
    }
    
    public boolean perform(final EntityPlayerMP player, final PetPlayer pet) {
        final double value = this.getSkill().getPersonalValue(pet);
        if (value <= 0.0) {
            return false;
        }
        final int intValue = (int)Math.ceil(value);
        RepairSkill.VALUES.put(player.func_110124_au(), intValue);
        PetTranslateEnum.MESSAGE_PET_REPAIR.message((ICommandSender)player, new Object[] { intValue });
        return true;
    }
    
    static {
        VALUES = new HashMap<UUID, Integer>();
    }
}
