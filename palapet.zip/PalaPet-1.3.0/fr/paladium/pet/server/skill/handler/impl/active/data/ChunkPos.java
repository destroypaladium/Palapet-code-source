//Decompiled by Procyon!

package fr.paladium.pet.server.skill.handler.impl.active.data;

import java.util.*;

public class ChunkPos
{
    private final int posX;
    private final int posZ;
    
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || this.getClass() != obj.getClass()) {
            return false;
        }
        final ChunkPos chunkPos = (ChunkPos)obj;
        return this.posX == chunkPos.posX && this.posZ == chunkPos.posZ;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.posX, this.posZ);
    }
    
    public static ChunkPos of(final int x, final int z) {
        return new ChunkPos(x, z);
    }
    
    public int getPosX() {
        return this.posX;
    }
    
    public int getPosZ() {
        return this.posZ;
    }
    
    public ChunkPos(final int posX, final int posZ) {
        this.posX = posX;
        this.posZ = posZ;
    }
}
