//Decompiled by Procyon!

package fr.paladium.pet.server.skill.handler.impl.active;

import fr.paladium.pet.server.skill.handler.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.common.utils.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.command.*;
import fr.paladium.pet.common.network.data.additional.skill.*;

public class FastChangeSkill extends ASkillHandler
{
    public static final String ID = "fast_change";
    
    public FastChangeSkill() {
        super("fast_change");
    }
    
    public void reduceSkillCooldowns(final EntityPlayerMP player, final PetPlayer pet, final double value) {
        final double percent = PetUtils.getValueAsPercent(value);
        final long now = System.currentTimeMillis();
        final long n;
        long cooldown;
        final double n2;
        long decrease;
        pet.getSkillData().getSkills().forEach((slot, data) -> {
            if (data.getSkillId() != null) {
                cooldown = data.getChangeCooldown(player, n);
                if (cooldown > 0L) {
                    decrease = (long)(cooldown * n2);
                    if (decrease <= 0L) {
                        data.setLastChangeMillis(0L);
                    }
                    else {
                        data.setLastChangeMillis(data.getLastChangeMillis() - decrease);
                    }
                }
            }
        });
    }
    
    public boolean perform(final EntityPlayerMP player, final PetPlayer pet) {
        final double value = this.getSkill().getPersonalValue(pet);
        if (value <= 0.0) {
            return false;
        }
        this.reduceSkillCooldowns(player, pet, value);
        PetTranslateEnum.MESSAGE_FAST_CHANGE_SUCCESS.message((ICommandSender)player);
        return true;
    }
}
