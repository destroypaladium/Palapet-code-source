//Decompiled by Procyon!

package fr.paladium.pet.server.skill.handler.impl.active;

import fr.paladium.pet.server.skill.handler.*;
import java.util.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.command.*;

public class VeterinarySkill extends ASkillHandler
{
    public static final String ID = "veterinary";
    public static final HashSet<UUID> VALUES;
    
    public VeterinarySkill() {
        super("veterinary");
    }
    
    public boolean perform(final EntityPlayerMP player, final PetPlayer pet) {
        PetTranslateEnum.MESSAGE_VETERINARY_USED.message((ICommandSender)player);
        VeterinarySkill.VALUES.add(player.func_110124_au());
        return true;
    }
    
    static {
        VALUES = new HashSet<UUID>();
    }
}
