//Decompiled by Procyon!

package fr.paladium.pet.server.skill.handler.impl.active;

import fr.paladium.pet.server.skill.handler.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.server.skill.listener.active.*;
import fr.paladium.pet.common.constant.*;
import fr.paladium.palaforgeutils.lib.task.*;
import net.minecraft.command.*;
import fr.paladium.pet.common.*;
import fr.paladium.pet.common.network.packet.skill.breakspeed.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import java.util.concurrent.*;

public class UnbreakablePickaxeSkill extends ASkillHandler
{
    public static final String ID = "unbreakable_pickaxe";
    public static final long DURATION;
    
    public UnbreakablePickaxeSkill() {
        super("unbreakable_pickaxe");
    }
    
    public boolean perform(final EntityPlayerMP player, final PetPlayer pet) {
        final double value = this.getSkill().getPersonalValue(pet);
        if (value <= 1.0) {
            return false;
        }
        BreakSpeedListener.INSTANCE.put(player, value);
        PetTranslateEnum.MESSAGE_UNBREAKABLE_PICKAXE.message((ICommandSender)player, new Object[] { String.format("%.2f", value), DurationConverter.fromMillisToString(UnbreakablePickaxeSkill.DURATION) });
        PetCommonProxy.getInstance().getNetwork().sendTo((IMessage)new SCObsidianBreakSpeedPacket(value, UnbreakablePickaxeSkill.DURATION), player);
        return true;
    }
    
    static {
        DURATION = TimeUnit.MINUTES.toMillis(1L);
    }
}
