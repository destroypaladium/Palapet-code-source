//Decompiled by Procyon!

package fr.paladium.pet.server.skill.handler.impl.active;

import fr.paladium.pet.server.skill.handler.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.world.*;
import fr.paladium.pet.server.config.global.*;
import net.minecraft.entity.*;
import net.minecraft.util.*;
import net.minecraft.entity.player.*;
import java.util.*;

public class MonsterSlayerSkill extends ASkillHandler
{
    public static final String ID = "monster_slayer";
    private static final float DAMAGE = 18.0f;
    
    public MonsterSlayerSkill() {
        super("monster_slayer");
    }
    
    public boolean perform(final EntityPlayerMP player, final PetPlayer pet) {
        final double radius = this.getSkill().getPersonalValue(pet);
        if (radius <= 0.0) {
            return false;
        }
        final World world = player.field_70170_p;
        final AxisAlignedBB axisAlignedBB = AxisAlignedBB.func_72330_a(player.field_70165_t - radius, player.field_70163_u - radius, player.field_70161_v - radius, player.field_70165_t + radius, player.field_70163_u + radius, player.field_70161_v + radius);
        this.attackMobs(world, player, axisAlignedBB);
        return true;
    }
    
    private void attackMobs(final World world, final EntityPlayerMP player, final AxisAlignedBB axisAlignedBB) {
        final GlobalConfig config = GlobalConfig.get();
        final List<EntityLivingBase> livings = (List<EntityLivingBase>)world.func_72872_a((Class)EntityLivingBase.class, axisAlignedBB);
        for (final EntityLivingBase living : livings) {
            if (living instanceof EntityPlayerMP) {
                continue;
            }
            final String name = living.getClass().getSimpleName();
            if (!config.getWhitelistedDamageEntities().contains(name)) {
                continue;
            }
            living.func_70097_a(DamageSource.func_76365_a((EntityPlayer)player), 18.0f);
        }
    }
}
