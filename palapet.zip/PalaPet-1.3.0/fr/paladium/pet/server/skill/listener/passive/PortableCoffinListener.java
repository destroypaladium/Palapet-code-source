//Decompiled by Procyon!

package fr.paladium.pet.server.skill.listener.passive;

import net.minecraftforge.event.entity.living.*;
import net.minecraft.util.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import net.minecraft.init.*;
import fr.paladium.combattag.*;
import org.bukkit.*;
import net.minecraft.block.*;
import net.minecraft.item.*;
import fr.paladium.pet.common.utils.*;
import net.minecraft.world.*;
import fr.paladium.pet.server.skill.handler.*;
import cpw.mods.fml.common.eventhandler.*;
import java.util.*;

public class PortableCoffinListener
{
    private static final int CHEST_INVENTORY_SIZE = 27;
    
    @SubscribeEvent
    public void onDeath(final LivingDeathEvent event) {
        if (!(event.entityLiving instanceof EntityPlayerMP)) {
            return;
        }
        final EntityPlayerMP player = (EntityPlayerMP)event.entityLiving;
        final World world = player.field_70170_p;
        final int x = MathHelper.func_76128_c(player.field_70165_t);
        final int y = MathHelper.func_76128_c(player.field_70163_u);
        final int z = MathHelper.func_76128_c(player.field_70161_v);
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        final PassiveResponse response = PassiveSkillEnum.PORTABLE_COFFIN.getResponse(pet);
        if (!response.isHas()) {
            return;
        }
        if (world.func_147439_a(x, y, z) != Blocks.field_150350_a || world.func_147439_a(x, y + 1, z) != Blocks.field_150350_a) {
            return;
        }
        try {
            if (CombatTag.getInstance().getManager().isInCombat(Bukkit.getPlayer(player.func_110124_au()))) {
                return;
            }
        }
        catch (Exception ex) {}
        if (!PetUtils.canInteract((EntityPlayer)player, x, y, z) || !PetUtils.canInteract((EntityPlayer)player, x, y + 1, z)) {
            return;
        }
        if (this.isEmpty(player.field_71071_by.field_70462_a) && this.isEmpty(player.field_71071_by.field_70460_b)) {
            return;
        }
        final List<ItemStack> items = this.getAndRemoveItems(player);
        if (items.size() <= 27) {
            world.func_147449_b(x, y, z, (Block)Blocks.field_150486_ae);
            ChestUtils.fillChest(world, x, y, z, (ItemStack[])items.toArray(new ItemStack[0]));
            return;
        }
        world.func_147449_b(x, y, z, (Block)Blocks.field_150486_ae);
        world.func_147449_b(x, y + 1, z, (Block)Blocks.field_150486_ae);
        ChestUtils.fillChest(world, x, y, z, (ItemStack[])items.subList(0, 27).toArray(new ItemStack[0]));
        ChestUtils.fillChest(world, x, y + 1, z, (ItemStack[])items.subList(27, items.size()).toArray(new ItemStack[0]));
    }
    
    private boolean isEmpty(final ItemStack[] items) {
        for (final ItemStack item : items) {
            if (item != null) {
                return false;
            }
        }
        return true;
    }
    
    private List<ItemStack> getAndRemoveItems(final EntityPlayerMP player) {
        final List<ItemStack> items = new ArrayList<ItemStack>();
        for (int i = 0; i < player.field_71071_by.func_70302_i_(); ++i) {
            final ItemStack item = player.field_71071_by.func_70301_a(i);
            if (item != null) {
                items.add(item);
                player.field_71071_by.func_70299_a(i, (ItemStack)null);
            }
        }
        for (int i = 0; i < player.field_71071_by.field_70460_b.length; ++i) {
            final ItemStack item = player.field_71071_by.field_70460_b[i];
            if (item != null) {
                items.add(item);
                player.field_71071_by.field_70460_b[i] = null;
            }
        }
        return items;
    }
}
