//Decompiled by Procyon!

package fr.paladium.pet.server.skill.listener.passive;

import net.minecraftforge.event.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import fr.paladium.pet.server.skill.handler.*;
import cpw.mods.fml.common.eventhandler.*;

public class FeedListener
{
    @SubscribeEvent
    public void onFeed(final PlayerUseItemEvent.Finish event) {
        final EntityPlayerMP player = (EntityPlayerMP)event.entityPlayer;
        final ItemStack stack = event.item;
        if (stack == null || !(stack.func_77973_b() instanceof ItemFood) || player.func_71024_bL().func_75116_a() == 20) {
            return;
        }
        final ItemFood food = (ItemFood)stack.func_77973_b();
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        final PassiveResponse response = PassiveSkillEnum.STOMACH_ON_LEGS.getResponse(pet);
        final double value = response.getPersonalValue(pet);
        if (!response.has(value)) {
            return;
        }
        final int defaultFood = (int)(food.func_150906_h(stack) * 10.0f);
        final int ret = (int)(defaultFood * (1.0 + response.getValueAsPercent(value)));
        final int foodToAdd = ret - defaultFood;
        player.func_71024_bL().func_75122_a(foodToAdd, food.func_150906_h(stack));
        player.func_71024_bL().func_75118_a((EntityPlayer)player);
    }
}
