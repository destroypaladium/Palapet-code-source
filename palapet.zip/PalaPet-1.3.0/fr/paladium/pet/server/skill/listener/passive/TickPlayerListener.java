//Decompiled by Procyon!

package fr.paladium.pet.server.skill.listener.passive;

import cpw.mods.fml.common.gameevent.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.world.*;
import cpw.mods.fml.common.eventhandler.*;
import net.minecraft.util.*;
import net.minecraft.entity.*;
import net.minecraft.entity.item.*;
import fr.paladium.pet.server.skill.handler.*;
import java.util.*;

public class TickPlayerListener
{
    public static final float VANILLA_SPEED = 0.1f;
    
    @SubscribeEvent
    public void onTick(final TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.START) {
            return;
        }
        final EntityPlayerMP player = (EntityPlayerMP)event.player;
        final World world = player.field_70170_p;
        final PetPlayer pet = PetPlayer.get(event.player);
        if (pet == null || !pet.has()) {
            return;
        }
        this.performMagnet(player, world, pet);
    }
    
    public void performMagnet(final EntityPlayerMP player, final World world, final PetPlayer pet) {
        final PassiveResponse response = PassiveSkillEnum.MAGNET.getResponse(pet);
        final double value = response.getPersonalValue(pet);
        if (!response.has(value)) {
            return;
        }
        final float magnet = 0.05f;
        final AxisAlignedBB axis = AxisAlignedBB.func_72330_a(player.field_70165_t - value, player.field_70163_u - value, player.field_70161_v - value, player.field_70165_t + value, player.field_70163_u + value, player.field_70161_v + value);
        final List<?> items = (List<?>)world.func_72872_a((Class)Entity.class, axis);
        EntityItem entityItem2;
        EntityItem entityItem;
        final float n;
        final EntityItem entityItem3;
        final EntityItem entityItem4;
        items.forEach(item -> {
            if (item instanceof EntityItem) {
                entityItem = (entityItem2 = item);
                entityItem2.field_70159_w += ((player.field_70165_t - entityItem.field_70165_t > 0.0) ? n : ((double)(-n)));
                entityItem3.field_70181_x += ((player.field_70163_u - entityItem.field_70163_u > 0.0) ? n : ((double)(-n)));
                entityItem4.field_70179_y += ((player.field_70161_v - entityItem.field_70161_v > 0.0) ? n : ((double)(-n)));
            }
        });
    }
}
