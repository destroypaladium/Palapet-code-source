//Decompiled by Procyon!

package fr.paladium.pet.server.skill.listener.active;

import fr.paladium.pet.common.event.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.server.skill.handler.impl.active.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.command.*;
import java.util.*;
import cpw.mods.fml.common.eventhandler.*;

public class EnchantListener
{
    @SubscribeEvent
    public void onEnchant(final PlayerEnchantItemEvent event) {
        final int cost = event.getCost();
        final EntityPlayerMP player = (EntityPlayerMP)event.getPlayer();
        final UUID uniqueId = player.func_110124_au();
        if (!EnchantedSkill.VALUES.containsKey(uniqueId)) {
            return;
        }
        final int value = EnchantedSkill.VALUES.get(uniqueId);
        if (cost < value) {
            return;
        }
        EnchantedSkill.VALUES.remove(uniqueId);
        PetTranslateEnum.MESSAGE_ENCHANTED_SUCCESS.message((ICommandSender)player, new Object[] { value });
        player.func_82242_a(value);
    }
}
