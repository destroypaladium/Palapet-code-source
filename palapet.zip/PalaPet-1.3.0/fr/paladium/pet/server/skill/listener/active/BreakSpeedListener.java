//Decompiled by Procyon!

package fr.paladium.pet.server.skill.listener.active;

import java.util.*;
import fr.paladium.pet.server.skill.handler.impl.active.data.*;
import net.minecraftforge.event.entity.player.*;
import net.minecraft.init.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.*;
import fr.paladium.pet.common.network.packet.skill.breakspeed.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import net.minecraft.block.*;
import fr.paladium.pet.server.skill.handler.*;
import cpw.mods.fml.common.eventhandler.*;
import fr.paladium.pet.server.skill.handler.impl.active.*;
import java.util.concurrent.*;

public class BreakSpeedListener
{
    public static final long GLOBAL_DURATION;
    public static BreakSpeedListener INSTANCE;
    private final HashMap<UUID, PickaxeData> dataMap;
    
    public BreakSpeedListener() {
        BreakSpeedListener.INSTANCE = this;
        this.dataMap = new HashMap<UUID, PickaxeData>();
    }
    
    @SubscribeEvent
    public void onBreakSpeed(final PlayerEvent.BreakSpeed event) {
        final EntityPlayerMP player = (EntityPlayerMP)event.entityPlayer;
        final Block block = event.block;
        final UUID uniqueId = player.func_110124_au();
        if (block.equals(Blocks.field_150343_Z) && this.dataMap.containsKey(uniqueId)) {
            final PickaxeData data = this.dataMap.get(uniqueId);
            if (!this.isExpired(data.getExpirationMillis())) {
                event.newSpeed = event.originalSpeed * (float)data.getValue();
                return;
            }
            this.dataMap.remove(uniqueId);
        }
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        final PassiveResponse response = PassiveSkillEnum.GOOD_PICKAXE.getResponse(pet);
        final double value = response.getPersonalValue(pet);
        final double multiplier = 1.0 + response.getValueAsPercent(value);
        if (!response.has(value)) {
            return;
        }
        PetCommonProxy.getInstance().getNetwork().sendTo((IMessage)new SCGlobalBreakSpeedPacket(multiplier, BreakSpeedListener.GLOBAL_DURATION), player);
        event.newSpeed = event.originalSpeed * (float)multiplier;
    }
    
    private boolean isExpired(final long duration) {
        return System.currentTimeMillis() >= duration;
    }
    
    public void put(final EntityPlayerMP player, final double value) {
        final PickaxeData data = new PickaxeData(value, System.currentTimeMillis() + UnbreakablePickaxeSkill.DURATION);
        this.dataMap.put(player.func_110124_au(), data);
    }
    
    static {
        GLOBAL_DURATION = TimeUnit.SECONDS.toMillis(1L);
    }
}
