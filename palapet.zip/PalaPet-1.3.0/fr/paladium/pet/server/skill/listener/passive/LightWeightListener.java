//Decompiled by Procyon!

package fr.paladium.pet.server.skill.listener.passive;

import net.minecraftforge.event.entity.living.*;
import net.minecraft.util.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.server.skill.handler.*;
import cpw.mods.fml.common.eventhandler.*;

public class LightWeightListener
{
    @SubscribeEvent
    public void onFall(final LivingHurtEvent event) {
        if (!event.source.equals(DamageSource.field_76379_h) || !(event.entityLiving instanceof EntityPlayerMP)) {
            return;
        }
        final EntityPlayerMP player = (EntityPlayerMP)event.entityLiving;
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        final PassiveResponse response = PassiveSkillEnum.LIGHTWEIGHT.getResponse(pet);
        final double value = response.getPersonalValue(pet);
        if (!response.has(value)) {
            return;
        }
        final double percent = response.getValueAsPercent(value);
        final float decrease = (float)(event.ammount * percent);
        event.ammount -= decrease;
    }
}
