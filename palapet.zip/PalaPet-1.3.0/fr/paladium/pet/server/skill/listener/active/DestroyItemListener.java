//Decompiled by Procyon!

package fr.paladium.pet.server.skill.listener.active;

import net.minecraftforge.event.entity.player.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.server.skill.handler.impl.active.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.command.*;
import fr.paladium.palaforgeutils.lib.item.*;
import java.util.*;
import net.minecraft.item.*;
import cpw.mods.fml.common.eventhandler.*;
import net.minecraft.nbt.*;

public class DestroyItemListener
{
    @SubscribeEvent
    public void onBreak(final PlayerDestroyItemEvent event) {
        final EntityPlayerMP player = (EntityPlayerMP)event.entityPlayer;
        final UUID uniqueId = player.func_110124_au();
        final ItemStack stack = event.original;
        if (stack == null || !RepairSkill.VALUES.containsKey(uniqueId)) {
            return;
        }
        if (!(stack.func_77973_b() instanceof ItemTool) && !(stack.func_77973_b() instanceof ItemSword)) {
            return;
        }
        final double value = RepairSkill.VALUES.get(uniqueId);
        final double random = Math.random() * 100.0;
        RepairSkill.VALUES.remove(uniqueId);
        if (random > value) {
            PetTranslateEnum.MESSAGE_PET_REPAIR_FAILED.message((ICommandSender)player);
            return;
        }
        final ItemStack copy = this.copy(stack);
        ItemUtils.spawnItemInWorld(player.field_70170_p, player.field_70165_t, player.field_70163_u, player.field_70161_v, copy);
        PetTranslateEnum.MESSAGE_PET_REPAIR_SUCCESS.message((ICommandSender)player);
    }
    
    public ItemStack copy(final ItemStack parent) {
        final ItemStack itemstack = new ItemStack(parent.func_77973_b(), 1, 0);
        if (parent.field_77990_d != null) {
            itemstack.field_77990_d = (NBTTagCompound)parent.field_77990_d.func_74737_b();
        }
        return itemstack;
    }
}
