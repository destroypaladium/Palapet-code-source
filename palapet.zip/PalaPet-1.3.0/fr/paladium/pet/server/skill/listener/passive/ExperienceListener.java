//Decompiled by Procyon!

package fr.paladium.pet.server.skill.listener.passive;

import net.minecraftforge.event.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.server.skill.handler.*;
import cpw.mods.fml.common.eventhandler.*;

public class ExperienceListener
{
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onEarn(final PlayerPickupXpEvent event) {
        final EntityPlayerMP player = (EntityPlayerMP)event.entityPlayer;
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        final PassiveResponse response = PassiveSkillEnum.EXPERIENCE_ABSORBER.getResponse(pet);
        final double value = response.getPersonalValue(pet);
        if (!response.has(value)) {
            return;
        }
        final double random = Math.random() * 100.0;
        if (random > value) {
            return;
        }
        event.orb.field_70530_e *= 2;
    }
}
