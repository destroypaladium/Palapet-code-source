//Decompiled by Procyon!

package fr.paladium.pet.server.skill.listener.passive;

import net.minecraftforge.event.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import net.minecraft.potion.*;
import net.minecraft.item.*;
import fr.paladium.pet.server.skill.handler.*;
import java.util.*;
import cpw.mods.fml.common.eventhandler.*;

public class PotionListener
{
    @SubscribeEvent
    public void onConsumePotion(final PlayerUseItemEvent.Finish event) {
        final EntityPlayerMP player = (EntityPlayerMP)event.entityPlayer;
        final ItemStack stack = event.item;
        if (stack == null || !(stack.func_77973_b() instanceof ItemPotion)) {
            return;
        }
        final ItemPotion potion = (ItemPotion)stack.func_77973_b();
        if (ItemPotion.func_77831_g(stack.func_77960_j()) || potion.func_150892_m(stack)) {
            return;
        }
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        final PassiveResponse response = PassiveSkillEnum.HERBALIST.getResponse(pet);
        final double value = response.getPersonalValue(pet);
        if (!response.has(value)) {
            return;
        }
        final List<PotionEffect> effects = (List<PotionEffect>)potion.func_77832_l(stack);
        if (effects == null || effects.isEmpty()) {
            return;
        }
        for (final PotionEffect effect : effects) {
            if (effect == null) {
                continue;
            }
            final Item item = Item.func_150899_d(effect.func_76456_a());
            if (item == null) {
                continue;
            }
            if (item instanceof ItemPotion) {
                continue;
            }
            final int duration = (int)(effect.func_76459_b() * (1.0 + response.getValueAsPercent(value)));
            player.func_70690_d(new PotionEffect(effect.func_76456_a(), duration, effect.func_76458_c(), effect.func_82720_e()));
        }
    }
}
