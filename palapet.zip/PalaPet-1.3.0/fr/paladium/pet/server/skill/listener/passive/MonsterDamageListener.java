//Decompiled by Procyon!

package fr.paladium.pet.server.skill.listener.passive;

import net.minecraftforge.event.entity.living.*;
import fr.paladium.pet.server.config.global.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import net.minecraft.entity.*;
import fr.paladium.pet.server.skill.handler.*;
import cpw.mods.fml.common.eventhandler.*;

public class MonsterDamageListener
{
    @SubscribeEvent
    public void onHurt(final LivingHurtEvent event) {
        final EntityLivingBase living = event.entityLiving;
        if (living == null) {
            return;
        }
        final String name = living.getClass().getSimpleName();
        final GlobalConfig config = GlobalConfig.get();
        if (!config.getWhitelistedDamageEntities().contains(name)) {
            return;
        }
        if (event.source == null || !(event.source.func_76346_g() instanceof EntityPlayerMP)) {
            return;
        }
        final EntityPlayerMP player = (EntityPlayerMP)event.source.func_76346_g();
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        final PassiveResponse response = PassiveSkillEnum.VITAL_POINT.getResponse(pet);
        final double value = response.getPersonalValue(pet);
        if (!response.has(value)) {
            return;
        }
        final double percentage = response.getValueAsPercent(value);
        final float increase = (float)(event.ammount * percentage);
        event.ammount += increase;
    }
}
