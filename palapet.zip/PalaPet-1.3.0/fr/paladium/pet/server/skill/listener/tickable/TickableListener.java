//Decompiled by Procyon!

package fr.paladium.pet.server.skill.listener.tickable;

import java.util.*;
import fr.paladium.pet.server.skill.handler.impl.active.data.*;
import cpw.mods.fml.common.gameevent.*;
import net.minecraft.server.*;
import net.minecraft.world.*;
import cpw.mods.fml.common.eventhandler.*;
import java.util.concurrent.*;

public class TickableListener
{
    public static final int MAX_BLOCKS_PER_MS = 10;
    public static final long MS_INCREMENT_PER_BLOCKS_COUNTS = 2L;
    public static final Set<BlockTickable> XRAY_TICKABLES;
    public static final Set<BlockTickable> AXE_TICKABLES;
    
    @SubscribeEvent
    public void onTick(final TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.START) {
            return;
        }
        final long now = System.currentTimeMillis();
        final World world = MinecraftServer.func_71276_C().func_130014_f_();
        TickableListener.XRAY_TICKABLES.removeIf(blockTickable -> blockTickable.paste(world, now));
        TickableListener.AXE_TICKABLES.removeIf(blockTickable -> blockTickable.paste(world, now));
    }
    
    static {
        XRAY_TICKABLES = ConcurrentHashMap.newKeySet();
        AXE_TICKABLES = ConcurrentHashMap.newKeySet();
    }
}
