//Decompiled by Procyon!

package fr.paladium.pet.server.skill.data;

import java.util.*;
import net.minecraft.item.*;

public class ItemMeta
{
    public final Item item;
    public final int metadata;
    
    public ItemMeta(final Item item, final int metadata) {
        this.item = item;
        this.metadata = metadata;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o != null && this.getClass() == o.getClass()) {
            final ItemMeta itemMeta = (ItemMeta)o;
            return this.metadata == itemMeta.metadata && this.item.equals(itemMeta.item);
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.item, this.metadata);
    }
    
    public static ItemMeta of(final ItemStack stack) {
        return new ItemMeta(stack.func_77973_b(), stack.func_77960_j());
    }
    
    public Item getItem() {
        return this.item;
    }
    
    public int getMetadata() {
        return this.metadata;
    }
}
