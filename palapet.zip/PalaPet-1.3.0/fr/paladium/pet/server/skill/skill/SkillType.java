//Decompiled by Procyon!

package fr.paladium.pet.server.skill.skill;

public enum SkillType
{
    PASSIVE, 
    ACTIVE;
}
