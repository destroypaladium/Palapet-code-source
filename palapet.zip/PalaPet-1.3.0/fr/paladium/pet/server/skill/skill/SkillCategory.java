//Decompiled by Procyon!

package fr.paladium.pet.server.skill.skill;

public enum SkillCategory
{
    MOVEMENT("D\u00e9placement"), 
    UTILS("Utilitaire"), 
    MINER("Mineur"), 
    FARMER("Fermier"), 
    HUNTER("Chasseur"), 
    ALCHEMIST("Alchimiste"), 
    PET("Familier"), 
    PLUNDER("Pillage"), 
    CLAIMED_LAND("Base claim"), 
    OBJECT("Objet");
    
    private final String name;
    
    private SkillCategory(final String name) {
        this.name = name;
    }
}
