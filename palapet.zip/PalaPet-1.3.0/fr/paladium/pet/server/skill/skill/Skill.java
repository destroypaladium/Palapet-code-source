//Decompiled by Procyon!

package fr.paladium.pet.server.skill.skill;

import fr.paladium.pet.server.skill.handler.*;
import fr.paladium.palaconfiguration.server.strategy.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.common.network.data.additional.skill.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.command.*;
import fr.paladium.pet.*;
import net.minecraft.entity.player.*;
import fr.paladium.translate.common.texttotranslate.*;

public class Skill
{
    public static final int NO_REQUIRED_LEVEL = -1;
    private String id;
    private String icon;
    private SkillType type;
    private SkillCategory category;
    private int requiredLevel;
    private double value;
    private int cooldownInMinutes;
    @PrintExclude
    private ASkillHandler handler;
    
    public void handle(final EntityPlayerMP player, final PetPlayer pet, final SkillData data) {
        if (this.handler == null) {
            PetTranslateEnum.MESSAGE_SKILL_NO_FOUND.message((ICommandSender)player, new Object[] { this.id });
            PetLogger.error("No handler for skill " + this.id);
            return;
        }
        this.handler.handle(player, pet, data);
    }
    
    public void setHandler(final ASkillHandler handler) {
        this.handler = handler;
        PetLogger.info("SKILL => Set handler " + handler.getClass().getSimpleName() + " for skill " + this.id);
    }
    
    public boolean hasRequiredLevel(final int level) {
        return level >= this.requiredLevel;
    }
    
    public double getPersonalValue(final PetPlayer pet) {
        return pet.getSkillValue(this);
    }
    
    public String getName(final EntityPlayer player) {
        return TTT.format(player, this.getTTTName(), new Object[0]);
    }
    
    public String getTTTName() {
        return "pet.skill." + this.id + ".name";
    }
    
    public String getTTTDescription() {
        return "pet.skill." + this.id + ".description";
    }
    
    public String getFormattedDescription(final EntityPlayer player, final double value) {
        final String description = this.getTTTDescription();
        try {
            final String formattedValue = this.formatNumber(value);
            return TTT.format(player, description, new Object[] { formattedValue });
        }
        catch (Exception ex) {
            try {
                return TTT.format(player, description, new Object[0]);
            }
            catch (Exception ex2) {
                return description;
            }
        }
    }
    
    private String formatNumber(final double number) {
        return (number % 1.0 == 0.0) ? String.format("%d", (int)number) : String.format("%.1f", number);
    }
    
    public long getCooldown(final long now, final long nextUseMillis) {
        return nextUseMillis - now;
    }
    
    public boolean isOnCooldown(final long cooldown) {
        return cooldown > 0L;
    }
    
    public String getId() {
        return this.id;
    }
    
    public String getIcon() {
        return this.icon;
    }
    
    public SkillType getType() {
        return this.type;
    }
    
    public SkillCategory getCategory() {
        return this.category;
    }
    
    public int getRequiredLevel() {
        return this.requiredLevel;
    }
    
    public double getValue() {
        return this.value;
    }
    
    public int getCooldownInMinutes() {
        return this.cooldownInMinutes;
    }
    
    public ASkillHandler getHandler() {
        return this.handler;
    }
    
    public void setId(final String id) {
        this.id = id;
    }
    
    public void setIcon(final String icon) {
        this.icon = icon;
    }
    
    public void setType(final SkillType type) {
        this.type = type;
    }
    
    public void setCategory(final SkillCategory category) {
        this.category = category;
    }
    
    public void setRequiredLevel(final int requiredLevel) {
        this.requiredLevel = requiredLevel;
    }
    
    public void setValue(final double value) {
        this.value = value;
    }
    
    public void setCooldownInMinutes(final int cooldownInMinutes) {
        this.cooldownInMinutes = cooldownInMinutes;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof Skill)) {
            return false;
        }
        final Skill other = (Skill)o;
        if (!other.canEqual(this)) {
            return false;
        }
        if (this.getRequiredLevel() != other.getRequiredLevel()) {
            return false;
        }
        if (Double.compare(this.getValue(), other.getValue()) != 0) {
            return false;
        }
        if (this.getCooldownInMinutes() != other.getCooldownInMinutes()) {
            return false;
        }
        final Object this$id = this.getId();
        final Object other$id = other.getId();
        Label_0107: {
            if (this$id == null) {
                if (other$id == null) {
                    break Label_0107;
                }
            }
            else if (this$id.equals(other$id)) {
                break Label_0107;
            }
            return false;
        }
        final Object this$icon = this.getIcon();
        final Object other$icon = other.getIcon();
        Label_0144: {
            if (this$icon == null) {
                if (other$icon == null) {
                    break Label_0144;
                }
            }
            else if (this$icon.equals(other$icon)) {
                break Label_0144;
            }
            return false;
        }
        final Object this$type = this.getType();
        final Object other$type = other.getType();
        Label_0181: {
            if (this$type == null) {
                if (other$type == null) {
                    break Label_0181;
                }
            }
            else if (this$type.equals(other$type)) {
                break Label_0181;
            }
            return false;
        }
        final Object this$category = this.getCategory();
        final Object other$category = other.getCategory();
        Label_0218: {
            if (this$category == null) {
                if (other$category == null) {
                    break Label_0218;
                }
            }
            else if (this$category.equals(other$category)) {
                break Label_0218;
            }
            return false;
        }
        final Object this$handler = this.getHandler();
        final Object other$handler = other.getHandler();
        if (this$handler == null) {
            if (other$handler == null) {
                return true;
            }
        }
        else if (this$handler.equals(other$handler)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof Skill;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        result = result * 59 + this.getRequiredLevel();
        final long $value = Double.doubleToLongBits(this.getValue());
        result = result * 59 + (int)($value >>> 32 ^ $value);
        result = result * 59 + this.getCooldownInMinutes();
        final Object $id = this.getId();
        result = result * 59 + (($id == null) ? 43 : $id.hashCode());
        final Object $icon = this.getIcon();
        result = result * 59 + (($icon == null) ? 43 : $icon.hashCode());
        final Object $type = this.getType();
        result = result * 59 + (($type == null) ? 43 : $type.hashCode());
        final Object $category = this.getCategory();
        result = result * 59 + (($category == null) ? 43 : $category.hashCode());
        final Object $handler = this.getHandler();
        result = result * 59 + (($handler == null) ? 43 : $handler.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "Skill(id=" + this.getId() + ", icon=" + this.getIcon() + ", type=" + this.getType() + ", category=" + this.getCategory() + ", requiredLevel=" + this.getRequiredLevel() + ", value=" + this.getValue() + ", cooldownInMinutes=" + this.getCooldownInMinutes() + ", handler=" + this.getHandler() + ")";
    }
    
    public Skill(final String id, final String icon, final SkillType type, final SkillCategory category, final int requiredLevel, final double value, final int cooldownInMinutes, final ASkillHandler handler) {
        this.id = id;
        this.icon = icon;
        this.type = type;
        this.category = category;
        this.requiredLevel = requiredLevel;
        this.value = value;
        this.cooldownInMinutes = cooldownInMinutes;
        this.handler = handler;
    }
}
