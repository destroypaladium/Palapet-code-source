//Decompiled by Procyon!

package fr.paladium.pet.server;

import fr.paladium.pet.common.*;
import fr.paladium.pet.server.config.assignment.*;
import fr.paladium.pet.server.config.skill.*;
import fr.paladium.pet.server.config.global.*;
import fr.paladium.pet.server.assignement.task.*;
import fr.paladium.palaforgeutils.lib.java.map.player.*;
import java.util.*;
import fr.paladium.palaforgeutils.lib.subcommand.builder.*;
import fr.paladium.pet.server.commands.*;
import fr.paladium.pet.server.skill.*;
import cpw.mods.fml.common.event.*;
import fr.paladium.pet.server.assignement.*;
import fr.paladium.pet.server.assignement.handler.impl.*;
import fr.paladium.pet.server.skill.handler.*;
import fr.paladium.pet.server.skill.handler.impl.active.*;
import fr.paladium.palaconfiguration.server.manager.*;
import fr.paladium.pet.server.skill.listener.passive.*;
import fr.paladium.pet.server.skill.listener.active.*;
import fr.paladium.pet.server.assignement.listener.*;
import fr.paladium.pet.server.listener.*;
import fr.paladium.pet.server.skill.listener.tickable.*;
import fr.paladium.pet.common.registry.*;

public class PetServerProxy extends PetCommonProxy
{
    private static PetServerProxy instance;
    private final RegistryManager registryManager;
    private AssignmentConfig assignmentConfig;
    private SkillConfig skillConfig;
    private GlobalConfig globalConfig;
    private AssignmentResetTask task;
    private SessionPlayerMap<HashSet<String>> playerSkinsMap;
    
    public PetServerProxy() {
        PetServerProxy.instance = this;
        this.registryManager = new RegistryManager();
    }
    
    public void onPreInit(final FMLPreInitializationEvent event) {
        super.onPreInit(event);
        this.registerListeners();
        this.registerAssignmentHandlers();
    }
    
    public void onInit(final FMLInitializationEvent event) {
        super.onInit(event);
        SubCommandBuilder.create("pet", "G\u00e9rer son familier").string().executable().register((Class)PetSubCommand.class);
        this.registerConfigs();
        this.registerSkillHandlers();
    }
    
    public void onPostInit(final FMLPostInitializationEvent event) {
        super.onPostInit(event);
        SkillManager.getInstance().updateSkills();
    }
    
    public void onServerStarting(final FMLServerStartingEvent event) {
        super.onServerStarting(event);
        this.registryManager.getRegistries().forEach(registry -> registry.onServerStarting(event));
    }
    
    public void onServerStarted(final FMLServerStartedEvent event) {
        super.onServerStarted(event);
        this.registryManager.getRegistries().forEach(registry -> registry.onServerStarted(event));
        (this.task = new AssignmentResetTask()).start();
    }
    
    private void registerAssignmentHandlers() {
        final AssignmentManager manager = AssignmentManager.getInstance();
        manager.registerHandler((Class)ConnectionAssignmentHandler.class);
        manager.registerHandler((Class)DailyJobAssignmentHandler.class);
        manager.registerHandler((Class)DailyPalapassAssignmentHandler.class);
        manager.registerHandler((Class)DarkAssignmentHandler.class);
        manager.registerHandler((Class)ItemAssignmentHandler.class);
        manager.registerHandler((Class)LightAssignmentHandler.class);
        manager.registerHandler((Class)SleepAssignmentHandler.class);
        manager.registerHandler((Class)WalkAssignmentHandler.class);
        manager.registerHandler((Class)WaterAssignmentHandler.class);
    }
    
    private void registerSkillHandlers() {
        final SkillManager manager = SkillManager.getInstance();
        manager.registerHandler(MonsterSlayerSkill.class);
        manager.registerHandler(PocketHappinessSkill.class);
        manager.registerHandler(BedrockDrillSkill.class);
        manager.registerHandler(UnbreakablePickaxeSkill.class);
        manager.registerHandler(GravitationalAxeSkill.class);
        manager.registerHandler(XRaySkill.class);
        manager.registerHandler(FastChangeSkill.class);
        manager.registerHandler(EnchantedSkill.class);
        manager.registerHandler(RepairSkill.class);
        manager.registerHandler(VeterinarySkill.class);
        manager.registerHandler(BlessedExplosionSkill.class);
    }
    
    private void registerConfigs() {
        final ConfigurationManager configurationManager = ConfigurationManager.getInstance();
        this.assignmentConfig = (AssignmentConfig)configurationManager.register((Class)AssignmentConfig.class);
        this.skillConfig = (SkillConfig)configurationManager.register((Class)SkillConfig.class);
        this.globalConfig = (GlobalConfig)configurationManager.register((Class)GlobalConfig.class);
    }
    
    private void registerListeners() {
        this.addListener(new Class[] { ExperienceListener.class, BreakSpeedListener.class, PortableCoffinListener.class, LightWeightListener.class, FeedListener.class, PotionListener.class, TickPlayerListener.class, MonsterDamageListener.class, EnchantListener.class, DestroyItemListener.class });
        this.addListener(new Class[] { AssignmentDailyJobListener.class, AssignmentDailyPalapassListener.class, AssignmentMoveListener.class, AssignmentTickListener.class });
        this.addListener(new Class[] { CaptureListener.class, ConnectionListener.class, HappinessListener.class, JobListener.class, JoinListener.class, NotificationListener.class, TickListener.class, SkillSyncListener.class, TickableListener.class });
    }
    
    public SessionPlayerMap<HashSet<String>> getPlayerSkinsMap() {
        if (this.playerSkinsMap == null) {
            this.playerSkinsMap = new SessionPlayerMap<HashSet<String>>() {
                public HashSet<String> getDefaultValue() {
                    return new HashSet<String>();
                }
            };
        }
        return this.playerSkinsMap;
    }
    
    public RegistryManager getRegistryManager() {
        return this.registryManager;
    }
    
    public AssignmentConfig getAssignmentConfig() {
        return this.assignmentConfig;
    }
    
    public SkillConfig getSkillConfig() {
        return this.skillConfig;
    }
    
    public GlobalConfig getGlobalConfig() {
        return this.globalConfig;
    }
    
    public AssignmentResetTask getTask() {
        return this.task;
    }
    
    public static PetServerProxy getInstance() {
        return PetServerProxy.instance;
    }
}
