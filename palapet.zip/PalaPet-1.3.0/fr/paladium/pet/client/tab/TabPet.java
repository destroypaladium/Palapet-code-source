//Decompiled by Procyon!

package fr.paladium.pet.client.tab;

import net.minecraft.creativetab.*;
import net.minecraft.item.*;
import net.minecraft.init.*;

public class TabPet extends CreativeTabs
{
    public static final String LABEL = "tab_pet";
    public static final TabPet INSTANCE;
    
    public TabPet() {
        super("tab_pet");
    }
    
    public Item func_78016_d() {
        return Item.func_150898_a(Blocks.field_150484_ah);
    }
    
    static {
        INSTANCE = new TabPet();
    }
}
