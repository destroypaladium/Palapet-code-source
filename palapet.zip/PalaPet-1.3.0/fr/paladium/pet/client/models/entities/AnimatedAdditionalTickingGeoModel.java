//Decompiled by Procyon!

package fr.paladium.pet.client.models.entities;

import software.bernie.geckolib3.model.*;

public abstract class AnimatedAdditionalTickingGeoModel<T extends IAnimatable> extends AnimatedTickingGeoModel<T>
{
}
