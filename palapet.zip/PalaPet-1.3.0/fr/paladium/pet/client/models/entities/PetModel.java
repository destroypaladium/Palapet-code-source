//Decompiled by Procyon!

package fr.paladium.pet.client.models.entities;

import software.bernie.geckolib3.model.*;
import fr.paladium.pet.common.entity.*;
import net.minecraft.util.*;
import fr.paladium.pet.client.ui.utils.*;
import net.minecraft.entity.*;

public class PetModel extends AnimatedTickingGeoModel<EntityDummyPet>
{
    private static final String PETS_FOLDER = "pets";
    
    public ResourceLocation getAnimationFileLocation(final EntityDummyPet entity) {
        return PetUIUtils.getGeckoAnimationFileLocation("pets", entity.getSkinId());
    }
    
    public ResourceLocation getModelLocation(final Entity entity) {
        return PetUIUtils.getGeckoModelLocation("pets", ((EntityDummyPet)entity).getSkinId());
    }
    
    public ResourceLocation getTextureLocation(final Entity entity) {
        return PetUIUtils.getGeckoTextureLocation("pets", ((EntityDummyPet)entity).getSkinId());
    }
}
