//Decompiled by Procyon!

package fr.paladium.pet.client.models.entities;

import software.bernie.geckolib3.model.*;
import fr.paladium.pet.common.entity.*;
import net.minecraft.util.*;
import fr.paladium.pet.client.ui.utils.*;
import net.minecraft.entity.*;

public class CageModel extends AnimatedTickingGeoModel<EntityPetCage>
{
    private static final String CAGE_FOLDER = "cage";
    private static final String CAGE_MODEL = "cage";
    
    public ResourceLocation getAnimationFileLocation(final EntityPetCage entity) {
        return PetUIUtils.getGeckoAnimationFileLocation("cage", "cage");
    }
    
    public ResourceLocation getModelLocation(final Entity entity) {
        return PetUIUtils.getGeckoModelLocation("cage", "cage");
    }
    
    public ResourceLocation getTextureLocation(final Entity entity) {
        return PetUIUtils.getGeckoTextureLocation("blocks", "cage");
    }
}
