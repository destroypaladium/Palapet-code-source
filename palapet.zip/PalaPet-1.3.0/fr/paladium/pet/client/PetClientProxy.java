//Decompiled by Procyon!

package fr.paladium.pet.client;

import fr.paladium.pet.common.*;
import fr.paladium.pet.client.ui.utils.data.*;
import net.minecraft.client.settings.*;
import fr.paladium.pet.client.listener.*;
import net.minecraft.client.renderer.entity.*;
import fr.paladium.pet.common.entity.*;
import fr.paladium.pet.common.tile.cage.*;
import net.minecraft.client.renderer.tileentity.*;
import fr.paladium.pet.client.renderer.*;
import cpw.mods.fml.client.registry.*;
import cpw.mods.fml.common.event.*;
import net.minecraft.client.*;
import fr.paladium.pet.common.pet.*;
import fr.paladium.pet.client.ui.utils.*;
import fr.paladium.pet.*;
import java.util.*;
import net.minecraft.util.*;
import net.minecraft.client.resources.*;
import fr.paladium.pet.server.skill.handler.*;

public class PetClientProxy extends PetCommonProxy
{
    public static int cageRenderId;
    private static PetClientProxy instance;
    private List<SkillRollSlotData> skillRollSlots;
    private HashMap<String, Double> skillValues;
    private KeyBinding keySkillRoll;
    
    public PetClientProxy() {
        PetClientProxy.instance = this;
        this.skillValues = new HashMap<String, Double>();
        this.skillRollSlots = new ArrayList<SkillRollSlotData>();
    }
    
    @Override
    public void onPreInit(final FMLPreInitializationEvent event) {
        super.onPreInit(event);
        this.addListener(new Class[] { PetRenderListener.class, ClientBreakSpeedListener.class, SkillRollListener.class });
        RenderingRegistry.registerEntityRenderingHandler((Class)EntityDummyPet.class, (Render)new PetGeoRenderer());
        RenderingRegistry.registerEntityRenderingHandler((Class)EntityPetCage.class, (Render)new CageGeoRenderer());
        PetClientProxy.cageRenderId = RenderingRegistry.getNextAvailableRenderId();
        ClientRegistry.bindTileEntitySpecialRenderer((Class)TileEntityPetCage.class, (TileEntitySpecialRenderer)new TileEntityPetCageRenderer());
        RenderingRegistry.registerBlockHandler(PetClientProxy.cageRenderId, (ISimpleBlockRenderingHandler)new PetCageRenderInventory());
    }
    
    @Override
    public void onInit(final FMLInitializationEvent event) {
        super.onInit(event);
        ClientRegistry.registerKeyBinding(this.keySkillRoll = new KeyBinding("pet.key.skill_roll", 46, "key.categories.pet"));
    }
    
    @Override
    public void onPostInit(final FMLPostInitializationEvent event) {
        super.onPostInit(event);
        this.loadAdditionalData();
    }
    
    public void loadAdditionalData() {
        final IResourceManager manager = Minecraft.func_71410_x().func_110442_L();
        final List<PetAdditionalData> pets = PetCommonProxy.getInstance().getPets();
        for (final PetAdditionalData pet : pets) {
            final ResourceLocation location = PetUIUtils.getAdditionalDataFileLocation(pet.getName());
            try {
                final IResource resource = manager.func_110536_a(location);
                pet.read(resource.func_110527_b());
                PetLogger.info("Loaded additional data for pet " + pet.getName());
            }
            catch (Exception e) {
                PetLogger.error("Failed to load additional data for pet " + pet.getName());
            }
        }
    }
    
    public double getSkillValue(final PassiveSkillEnum skill) {
        return this.getSkillValue(skill.getId());
    }
    
    public double getSkillValue(final String skill) {
        return this.skillValues.getOrDefault(skill, 0.0);
    }
    
    public SkillRollSlotData findSkillRollData(final int slot) {
        for (final SkillRollSlotData data : this.skillRollSlots) {
            if (data.getSlot() == slot) {
                return data;
            }
        }
        return SkillRollSlotData.none(slot);
    }
    
    public void setSkillRollSlots(final List<SkillRollSlotData> skillRollSlots) {
        this.skillRollSlots = skillRollSlots;
    }
    
    public void setSkillValues(final HashMap<String, Double> skillValues) {
        this.skillValues = skillValues;
    }
    
    public void setKeySkillRoll(final KeyBinding keySkillRoll) {
        this.keySkillRoll = keySkillRoll;
    }
    
    public List<SkillRollSlotData> getSkillRollSlots() {
        return this.skillRollSlots;
    }
    
    public HashMap<String, Double> getSkillValues() {
        return this.skillValues;
    }
    
    public KeyBinding getKeySkillRoll() {
        return this.keySkillRoll;
    }
    
    public static PetClientProxy getInstance() {
        return PetClientProxy.instance;
    }
}
