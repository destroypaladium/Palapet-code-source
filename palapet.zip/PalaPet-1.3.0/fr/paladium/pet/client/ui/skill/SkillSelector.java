//Decompiled by Procyon!

package fr.paladium.pet.client.ui.skill;

import net.minecraft.util.*;
import java.util.*;
import net.minecraftforge.client.event.*;
import net.minecraft.client.*;
import org.lwjgl.opengl.*;
import fr.paladium.lib.apollon.utils.*;
import fr.paladium.pet.client.*;
import org.lwjgl.*;
import glm.vec._3.*;
import glm.mat._4.*;
import glm.vec._4.*;
import fr.paladium.pet.client.ui.utils.*;
import fr.paladium.pet.client.ui.utils.data.*;
import java.nio.*;

public class SkillSelector
{
    private static ResourceLocation text;
    private static ResourceLocation selector;
    private ArrayList<Boolean> isHover;
    private double selectorAngle;
    private double targetSelectorAngle;
    
    public SkillSelector() {
        this.isHover = new ArrayList<Boolean>(Collections.nCopies(7, false));
        this.selectorAngle = -1.0;
        this.targetSelectorAngle = -1.0;
    }
    
    private static double mouseAngle(final int x, final int y, final int mx, final int my) {
        return (Math.atan2(my - y, mx - x) + 6.283185307179586) % 6.283185307179586;
    }
    
    public void draw(final int mx, final int my, final float partialTick, final RenderGameOverlayEvent event) {
        final int fps = Integer.parseInt(Minecraft.func_71410_x().field_71426_K.split(" fps")[0]);
        final double selectorAngleDiff = this.targetSelectorAngle - this.selectorAngle;
        final double absSelectorAngleDiff = Math.abs(selectorAngleDiff);
        final double selectorAngleOffset = 0.2 / (((fps == 0) ? 1 : fps) / 60.0f) * absSelectorAngleDiff / 3.0;
        if (absSelectorAngleDiff > 0.2) {
            this.selectorAngle += ((selectorAngleDiff > 0.0) ? selectorAngleOffset : (-selectorAngleOffset));
        }
        else {
            this.selectorAngle = this.targetSelectorAngle;
        }
        final int x = event.resolution.func_78326_a() / 2;
        final int y = event.resolution.func_78328_b() / 2;
        final float f1 = Minecraft.func_71410_x().field_71474_y.field_74341_c * 0.6f + 0.2f;
        final int angle = (int)(event.resolution.func_78327_c() * 0.271);
        final int circles = 6;
        this.drawCircle(x, y, angle, circles, mx, my, event);
        this.drawSelector(x, y, angle, circles, mx, my, event);
    }
    
    public void drawSelector(final double x, final double y, final int radius, final int segments, final int mx, final int my, final RenderGameOverlayEvent event) {
        final double angle = mouseAngle((int)x, (int)y, mx, my);
        final float degPer = 6.2831855f / segments;
        boolean foundSelector = false;
        for (int seg = 0; seg < segments; ++seg) {
            final boolean mouseInSector = degPer * seg < angle && angle < degPer * (seg + 1);
            if (mouseInSector && this.isHover.get(seg)) {
                if (60 * seg - this.targetSelectorAngle < -60.0) {
                    this.selectorAngle = this.targetSelectorAngle - 360.0;
                    this.targetSelectorAngle = 60 * seg;
                }
                else if (60 * seg - this.targetSelectorAngle > 60.0) {
                    this.selectorAngle = 360.0 - this.targetSelectorAngle;
                    this.targetSelectorAngle = 60 * seg;
                }
                else {
                    this.targetSelectorAngle = 60 * seg;
                }
                foundSelector = true;
                break;
            }
        }
        if (foundSelector) {
            final float width = (float)(event.resolution.func_78327_c() * 0.07559999823570251);
            final float height = (float)(event.resolution.func_78324_d() * 0.07559999823570251);
            GL11.glPushMatrix();
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.8f);
            GL11.glTranslated(event.resolution.func_78327_c() / 2.0, event.resolution.func_78324_d() / 2.0, 100.0);
            GL11.glRotated(98.0 + this.selectorAngle, 0.0, 0.0, 1.0);
            GL11.glTranslated(-event.resolution.func_78327_c() / 2.0, -event.resolution.func_78324_d() / 2.0, 100.0);
            GuiUtils.drawImageTransparent(event.resolution.func_78327_c() / 100.0 * 50.0, event.resolution.func_78324_d() / 100.0 * 31.0, SkillSelector.selector, (double)width, (double)height);
            GL11.glPopMatrix();
        }
    }
    
    public void drawCircle(final double x, final double y, final int radius, final int segments, final int mx, final int my, final RenderGameOverlayEvent event) {
        final float degPer = 6.2831855f / segments;
        Minecraft.func_71410_x().field_71424_I.func_76320_a("root.DrawWheel");
        boolean hover = false;
        for (int seg = 0; seg < segments; ++seg) {
            float offsetHoverW = 1.0f;
            float offsetHoverH = 1.0f;
            float offsetZ = 100.0f;
            final float rad = (seg + 0.5f) * degPer;
            float xp = (float)(x + Math.cos(rad) * radius);
            float yp = (float)(y + Math.sin(rad) * radius);
            final ResourceLocation texture = SkillSelector.text;
            Color wheelColor = new Color(10, 10, 20, 170);
            if (this.isHover.get(seg) && !hover) {
                hover = true;
                offsetHoverW = 1.1315f;
                offsetHoverH = 1.1315f;
                offsetZ = 150.0f;
                xp = (float)(x + Math.cos(rad) * (radius + 2));
                yp = (float)(y + Math.sin(rad) * (radius + 2));
                wheelColor = new Color(239, 57, 38);
            }
            final SkillRollSlotData data = PetClientProxy.getInstance().findSkillRollData(seg);
            if (data != null && data.isUsageCooldown()) {
                wheelColor = new Color(255, 165, 0);
            }
            float xsp = xp;
            float ysp = yp;
            double mod = 1.0;
            int xdp = (int)((xp - x) * mod + x);
            int ydp = (int)((yp - y) * mod + y);
            if (xsp < x) {
                xsp -= 0.0f;
            }
            if (ysp < y) {
                ysp -= 0.0f;
            }
            mod = 0.6;
            xdp = (int)((xp - x) * mod + x);
            ydp = (int)((yp - y) * mod + y);
            Minecraft.func_71410_x().field_71424_I.func_76320_a("root.DrawWheelsegment");
            GL11.glPushMatrix();
            final float width = (float)(event.resolution.func_78327_c() * 0.1340000033378601 * offsetHoverW);
            final float height = (float)(event.resolution.func_78324_d() * 0.19869999587535858 * offsetHoverH);
            final FloatBuffer matrice = BufferUtils.createFloatBuffer(16);
            final Vec3 pos1 = new Vec3(xdp - width / 2.29, ydp - height / 2.18, 300.0);
            final Vec3 pos2 = new Vec3(xdp + width * 0.5403 - width / 2.29, ydp + height * 0.1461 - height / 2.18, 300.0);
            final Vec3 pos3 = new Vec3(xdp + width - width / 2.29, ydp + height * 0.5296 - height / 2.18, 300.0);
            final Vec3 pos4 = new Vec3(xdp + width * 0.6282 - width / 2.29, ydp + height - height / 2.18, 300.0);
            final Vec3 pos5 = new Vec3(xdp - width / 2.29, ydp + height * 0.6696 - height / 2.18, 300.0);
            GL11.glTranslated((double)xdp, (double)ydp, (double)offsetZ);
            GL11.glRotated(37.0 + 360.0 / segments * (seg + 1), 0.0, 0.0, 1.0);
            GL11.glTranslated((double)(-xdp), (double)(-ydp), (double)offsetZ);
            wheelColor.bind();
            GuiUtils.drawImageTransparent(xdp - width / 2.29, ydp - height / 2.18, texture, (double)width, (double)height);
            Color.WHITE.bind();
            GL11.glGetFloat(2982, matrice);
            final float[] f = new float[16];
            matrice.get(f);
            final Mat4 view = new Mat4(f);
            final Vec4 pos1rot = view.mul(new Vec4(pos1, 1.0f));
            final Vec4 pos2rot = view.mul(new Vec4(pos2, 1.0f));
            final Vec4 pos3rot = view.mul(new Vec4(pos3, 1.0f));
            final Vec4 pos4rot = view.mul(new Vec4(pos4, 1.0f));
            final Vec4 pos5rot = view.mul(new Vec4(pos5, 1.0f));
            final Polygon2D polygon = new Polygon2D();
            polygon.addPoint(pos1rot.x, pos1rot.y);
            polygon.addPoint(pos2rot.x, pos2rot.y);
            polygon.addPoint(pos3rot.x, pos3rot.y);
            polygon.addPoint(pos4rot.x, pos4rot.y);
            polygon.addPoint(pos5rot.x, pos5rot.y);
            if (polygon.contains(mx, my)) {
                this.isHover.set(seg, true);
            }
            else {
                this.isHover.set(seg, false);
            }
            final ResourceLocation logo = PetClientProxy.getInstance().findSkillRollData(seg).getLogo();
            GL11.glPopMatrix();
            GL11.glPushMatrix();
            final float pictWidth = (float)(event.resolution.func_78327_c() * 0.05090000107884407);
            final float pictHeight = (float)(event.resolution.func_78324_d() * 0.10719999670982361);
            GL11.glTranslated((double)(xdp - pictWidth / 2.0f), (double)(ydp - pictHeight / 2.0f), (double)(offsetZ * 2.3f));
            GuiUtils.drawImageTransparent(0.0, 0.0, logo, (double)pictWidth, (double)pictHeight, false);
            GL11.glPopMatrix();
            Minecraft.func_71410_x().field_71424_I.func_76319_b();
        }
        Minecraft.func_71410_x().field_71424_I.func_76319_b();
    }
    
    public ArrayList<Boolean> getIsHover() {
        return this.isHover;
    }
    
    static {
        SkillSelector.text = new ResourceLocation("cosmetics", "emotes/gui/sideGui.png");
        SkillSelector.selector = new ResourceLocation("cosmetics", "emotes/gui/selector.png");
    }
}
