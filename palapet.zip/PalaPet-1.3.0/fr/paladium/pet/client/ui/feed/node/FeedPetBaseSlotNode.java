//Decompiled by Procyon!

package fr.paladium.pet.client.ui.feed.node;

import fr.paladium.lib.apollon.nodes.slot.*;
import net.minecraft.inventory.*;

public class FeedPetBaseSlotNode extends SlotNode
{
    private static final String TEXTURE = "palapet:textures/ui/feed/slot/slot";
    private static final String HOVERED_TEXTURE = "palapet:textures/ui/feed/slot/slot_hover";
    
    public FeedPetBaseSlotNode(final IInventory inventory, final int slotIndex, final double x, final double y, final double size) {
        super(inventory, slotIndex, x, y, size, size);
        this.setItemScale(0.8f);
        this.setTexture("palapet:textures/ui/feed/slot/slot");
        this.setHoveredTexture("palapet:textures/ui/feed/slot/slot_hover");
    }
}
