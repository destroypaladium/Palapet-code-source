//Decompiled by Procyon!

package fr.paladium.pet.client.ui.feed;

import fr.paladium.lib.apollon.ui.*;
import fr.paladium.pet.common.container.*;
import net.minecraft.client.gui.*;
import fr.paladium.pet.common.constant.*;
import fr.paladium.lib.apollon.nodes.abstracts.*;
import fr.paladium.lib.apollon.nodes.label.*;
import fr.paladium.pet.client.ui.feed.node.*;
import net.minecraft.inventory.*;
import fr.paladium.lib.apollon.nodes.buttons.buttons.*;
import fr.paladium.lib.apollon.utils.*;
import fr.paladium.pet.common.*;
import fr.paladium.pet.common.network.packet.pet.*;
import cpw.mods.fml.common.network.simpleimpl.*;

public class UIFeedPetContainer extends UIContainer
{
    private final InventoryFeedPet inventory;
    private final String title;
    private final String subtitle;
    
    public UIFeedPetContainer(final ContainerFeedPet container) {
        super((GuiScreen)null, "palapet:feed_pet", (Container)container);
        this.inventory = new InventoryFeedPet();
        this.title = PetTranslateEnum.GUI_NODE_FEED_TITLE.text();
        this.subtitle = PetTranslateEnum.GUI_NODE_FEED_SUBTITLE.text();
    }
    
    public void func_73866_w_() {
        super.func_73866_w_();
        final double titleX = this.width(30.95f);
        final double titleY = this.height(14.0f);
        this.addNode((ANode)new MinecraftTitleNodeLabel(titleX, titleY, this.title));
        this.addNode((ANode)new MinecraftSubTitleNodeLabel(titleX, titleY + this.height(10.0f), this.subtitle));
        this.addNode((ANode)new FeedPetBaseSlotNode((IInventory)this.inventory, 0, (double)this.width(46.04f), (double)this.height(29.77f), (double)this.width(7.916f)));
        final double backNodeX = this.width(65.5f);
        final MinecraftBackNode backNode;
        this.addNode((ANode)(backNode = new MinecraftBackNode(backNodeX, (double)this.height(13.5f), this.prev)));
        backNode.setCallback(c -> PetCommonProxy.getInstance().getNetwork().sendToServer((IMessage)new BBOpenUIPacket()));
        this.addNode((ANode)new MinecraftCloseNode(backNodeX + this.width(2.476f), (double)this.height(13.0f)));
        double startX = this.width(34.479f);
        double startY = this.height(52.87f);
        final double slotSpaceX = this.width(3.5f);
        final double slotSpaceY = this.height(6.5f);
        final double slotSize = this.width(3.125f);
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.addNode((ANode)new FeedPetBaseSlotNode((IInventory)this.field_146297_k.field_71439_g.field_71071_by, j + i * 9 + 9, startX + slotSpaceX * j, startY + slotSpaceY * i, slotSize));
            }
        }
        startX = this.width(34.479f);
        startY = this.height(74.63f);
        for (int i = 0; i < 9; ++i) {
            this.addNode((ANode)new FeedPetBaseSlotNode((IInventory)this.field_146297_k.field_71439_g.field_71071_by, i, startX + slotSpaceX * i, startY, slotSize));
        }
    }
    
    public void preDraw(final int mouseX, final int mouseY, final float ticks) {
        this.func_146276_q_();
        this.drawBackground(this.width(50.0f) - this.width(49.745f) / 2.0f, this.height(50.0f) - this.height(79.16f) / 2.0f, this.width(49.475f), this.height(79.16f));
    }
    
    public void fixedUpdate() {
        super.fixedUpdate();
    }
    
    private void drawBackground(final double x, final double y, final double width, final double height) {
        this.func_146276_q_();
        BackgroundHelper.createMinecraft((double)this.width(43.021f), (double)this.height(76.481f));
    }
    
    public void func_73869_a(final char c, final int keyCode) {
        if (keyCode == 1) {
            PetCommonProxy.getInstance().getNetwork().sendToServer((IMessage)new BBOpenUIPacket());
            return;
        }
        super.func_73869_a(c, keyCode);
    }
}
