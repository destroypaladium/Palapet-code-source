//Decompiled by Procyon!

package fr.paladium.pet.client.ui.capture;

import fr.paladium.lib.apollon.ui.*;
import net.minecraft.util.*;
import fr.paladium.lib.apollon.animation.*;
import fr.paladium.pet.common.tile.cage.*;
import fr.paladium.pet.common.constant.*;
import fr.paladium.palaforgeutils.lib.sound.*;
import net.minecraft.client.audio.*;
import net.minecraft.client.gui.*;
import fr.paladium.lib.apollon.nodes.label.*;
import fr.paladium.lib.apollon.nodes.abstracts.*;
import fr.paladium.lib.apollon.nodes.progressbar.*;
import fr.paladium.pet.common.capture.*;
import fr.paladium.lib.apollon.utils.*;
import fr.paladium.lib.apollon.utils.text.*;
import java.util.*;
import fr.paladium.pet.common.*;
import fr.paladium.pet.common.network.packet.capture.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import fr.paladium.lib.aurelienribon.tweenengine.*;

public class UICapture extends UI
{
    private static final ResourceLocation SPACEBAR_TEXTURE;
    private static final ResourceLocation SPACEBAR_PRESSED_TEXTURE;
    private static final Color BAR_COLOR;
    private final CaptureCategory category;
    private long lastCursorUpdate;
    private AnimatedObject cursorValue;
    private long end;
    private double sectionBaseX;
    private final String title;
    private final String subtitle;
    private final String clickSpaceText;
    private final int x;
    private final int y;
    private final int z;
    
    public UICapture(final CaptureCategory category, final CageStatus status, final int x, final int y, final int z) {
        this.category = category;
        this.title = PetTranslateEnum.GUI_CAPTURE_TITLE.text();
        this.subtitle = status.getTranslate().text();
        this.clickSpaceText = PetTranslateEnum.GUI_CAPTURE_CLICK_SPACE.text();
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public void func_73866_w_() {
        super.func_73866_w_();
        if (this.cursorValue == null) {
            this.field_146297_k.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_147674_a(new ResourceLocation(SoundUtils.NOTE_PIANO.getSoundName()), 0.5f));
            (this.cursorValue = new AnimatedObject()).setValue((float)Math.random());
            this.cursorValue.createSequence().push(this.category.getDuration() * (1.0f - this.cursorValue.getValue()), 1.0f, (TweenEquation)TweenEquations.easeNone).push((float)this.category.getDuration(), 0.0f, (TweenEquation)TweenEquations.easeNone).push((float)this.category.getDuration(), 1.0f, (TweenEquation)TweenEquations.easeNone).push((float)this.category.getDuration(), 0.0f, (TweenEquation)TweenEquations.easeNone).push((float)this.category.getDuration(), 1.0f, (TweenEquation)TweenEquations.easeNone).start();
            this.cursorValue.getTimeline().addCallback(4, base -> {
                this.field_146297_k.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_147674_a(new ResourceLocation(SoundUtils.ITEM_BREAK.getSoundName()), 5.0f));
                this.sendPacket(-150);
                this.field_146297_k.func_147108_a((GuiScreen)null);
                return;
            });
            this.lastCursorUpdate = System.currentTimeMillis();
            this.end = System.currentTimeMillis() + this.category.getDuration() * 4L + (long)(this.category.getDuration() * (1.0f - this.cursorValue.getValue()));
        }
        this.addNode((ANode)new MinecraftTitleNodeLabel((double)this.width(23.0f), (double)this.height(27.59f), this.title));
        final double barX = this.width(23.0f);
        final double barY = this.height(53.33f);
        final double barWidth = this.width(53.0f);
        this.addNode((ANode)new MinecraftProgressBarNode(barX, barY, barWidth, Color.WHITE));
        double sectionTotalWidth = 0.0;
        for (final CaptureSection section : this.category.getSections()) {
            sectionTotalWidth += barWidth * (section.getPercentage() / 100.0f);
        }
        this.sectionBaseX = barX + (barWidth - sectionTotalWidth) * Math.random();
        double sectionOffsetX = 0.0;
        for (final CaptureSection section2 : this.category.getSections()) {
            final double sectionWidth = barWidth * (section2.getPercentage() / 100.0f);
            this.addNode((ANode)new MinecraftProgressBarNode(this.sectionBaseX + sectionOffsetX, barY, sectionWidth, section2.getColor()).setMin(0.0f).setMax(1.0f).setValue(1.0f));
            sectionOffsetX += sectionWidth;
        }
    }
    
    public void preDraw(final int mouseX, final int mouseY, final float ticks) {
        BackgroundHelper.createMinecraft((double)this.width(58.54f), (double)this.height(50.0f), true);
    }
    
    public void postDraw(final int mouseX, final int mouseY, final float ticks) {
        final double barX = this.width(23.0f);
        final double barY = this.height(53.33f);
        final double barWidth = this.width(53.0f);
        GuiUtils.drawCenteredStringWithCustomFont(this.field_146297_k, this.subtitle, (double)this.width(50.0f), (double)this.height(42.0f), Color.WHITE, Fonts.PIXEL_NES.getFont(), 70);
        GuiUtils.drawCenteredStringWithCustomFont(this.field_146297_k, this.clickSpaceText, (double)this.width(50.0f), (double)this.height(46.0f), Color.decode("#41414E"), Fonts.PIXEL_NES.getFont(), 20);
        final ResourceLocation spacebar = (this.field_146297_k.field_71439_g.field_70173_aa % 20 < 10) ? UICapture.SPACEBAR_TEXTURE : UICapture.SPACEBAR_PRESSED_TEXTURE;
        GuiUtils.drawImageTransparent((double)this.width(47.8f), (double)this.height(45.9f), spacebar, (double)this.width(2.44f), (double)this.height(1.48f), false);
        final float timeRemaining = Math.max(0.0f, (this.end - System.currentTimeMillis()) / 1000.0f);
        GuiUtils.drawSplittedString(this.field_146297_k, String.format("%.1f", timeRemaining), barX + barWidth, (double)this.height(60.0f), Color.decode("#41414E"), Fonts.PIXEL_NES.getFont(), 20, (double)this.field_146294_l, TextAlign.RIGHT);
        final List<CaptureSection> showedSections = new ArrayList<CaptureSection>();
        final double darkY = this.height(65.0f);
        double darkX = barX;
        GuiUtils.drawRect(darkX, darkY, darkX + this.width(1.0f), darkY + this.width(1.0f), UICapture.BAR_COLOR);
        darkX += this.width(1.5f);
        GuiUtils.drawStringWithCustomFont(this.field_146297_k, "-150", darkX, darkY + this.height(0.2f), Color.WHITE, Fonts.PIXEL_NES.getFont(), 40);
        for (int i = 1; i < this.category.getSections().size() + 1; ++i) {
            final CaptureSection section = this.category.getSections().get(i - 1);
            if (!showedSections.contains(section)) {
                final int value = section.getValue();
                final String sign = (section.getValue() > 0) ? "+" : "";
                double ox = barX + this.width(8.0f) * (i / 2);
                final double oy = this.height(65.0f) + this.height(3.5f) * (i % 2);
                GuiUtils.drawRect(ox, oy, ox + this.width(1.0f), oy + this.width(1.0f), section.getColor());
                ox += this.width(1.5f);
                ox += GuiUtils.drawStringWithCustomFont(this.field_146297_k, sign + String.valueOf(value), ox, oy + this.height(0.2f), Color.WHITE, Fonts.PIXEL_NES.getFont(), 40);
                showedSections.add(section);
            }
        }
        final long now = System.currentTimeMillis();
        this.cursorValue.getTimeline().update((float)(now - this.lastCursorUpdate));
        this.lastCursorUpdate = now;
        final double cursorX = barX + barWidth * this.cursorValue.getValue();
        final double cursorY = barY + this.height(2.87f);
        final double cursorWidth = this.width(0.4f);
        final double cursorHeight = this.height(8.0f);
        GuiUtils.drawRect(cursorX - cursorWidth / 2.0, cursorY - cursorHeight / 2.0, cursorX + cursorWidth / 2.0, cursorY + cursorHeight / 2.0, Color.WHITE.darker(0.5f));
        GuiUtils.drawRect(cursorX - cursorWidth / 2.0, cursorY - cursorHeight / 2.0, cursorX + cursorWidth / 2.0, cursorY - this.height(0.8f) + cursorHeight / 2.0, Color.WHITE);
    }
    
    protected void func_73869_a(final char c, final int keyCode) {
        if (keyCode == 57) {
            final float value = this.cursorValue.getValue();
            final double barX = this.width(23.0f);
            final double barWidth = this.width(53.0f);
            final double cursorX = barX + barWidth * value;
            CaptureSection focusedSection = null;
            double sectionOffsetX = 0.0;
            for (final CaptureSection section : this.category.getSections()) {
                final double sectionWidth = barWidth * (section.getPercentage() / 100.0f);
                final double sectionX = this.sectionBaseX + sectionOffsetX;
                if (cursorX > sectionX && cursorX < sectionX + sectionWidth) {
                    focusedSection = section;
                    break;
                }
                sectionOffsetX += sectionWidth;
            }
            if (focusedSection != null) {
                final String soundName = (focusedSection.getValue() <= 0) ? SoundUtils.ITEM_BREAK.getSoundName() : "random.orb";
                this.field_146297_k.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_147674_a(new ResourceLocation(soundName), 0.5f));
                this.sendPacket(focusedSection.getValue());
                this.field_146297_k.func_147108_a((GuiScreen)null);
            }
            else {
                this.field_146297_k.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_147674_a(new ResourceLocation(SoundUtils.ITEM_BREAK.getSoundName()), 5.0f));
                this.sendPacket(-150);
                this.field_146297_k.func_147108_a((GuiScreen)null);
            }
        }
        if (keyCode == 1) {
            this.field_146297_k.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_147674_a(new ResourceLocation(SoundUtils.ITEM_BREAK.getSoundName()), 5.0f));
            this.sendPacket(-150);
        }
        super.func_73869_a(c, keyCode);
    }
    
    public void sendPacket(final int score) {
        PetCommonProxy.getInstance().getNetwork().sendToServer((IMessage)new CSPacketTrapInteraction(score, this.x, this.y, this.z));
    }
    
    static {
        SPACEBAR_TEXTURE = new ResourceLocation("palajobs", "textures/gui/fishing/space.png");
        SPACEBAR_PRESSED_TEXTURE = new ResourceLocation("palajobs", "textures/gui/fishing/space_pressed.png");
        BAR_COLOR = Color.decode("#323232");
    }
}
