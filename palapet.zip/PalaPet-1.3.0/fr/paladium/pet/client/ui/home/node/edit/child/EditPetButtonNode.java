//Decompiled by Procyon!

package fr.paladium.pet.client.ui.home.node.edit.child;

import fr.paladium.lib.apollon.nodes.buttons.buttons.*;
import fr.paladium.lib.apollon.utils.*;
import fr.paladium.lib.apollon.nodes.abstracts.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.*;

public class EditPetButtonNode extends TexturedNodeButton
{
    private static final String TEXTURE = "palapet:textures/ui/home/edit_pet";
    
    @Deprecated
    public EditPetButtonNode(final double x, final double y, final double width, final double height) {
        super(x, y, width, height, "palapet:textures/ui/home/edit_pet");
        this.setAnimationDuration(0.1f);
        this.setCallback(node -> Minecraft.func_71410_x().func_147108_a((GuiScreen)null));
    }
    
    public EditPetButtonNode(final double x, final double y) {
        this(x, y, GuiUtils.width(1.9f), GuiUtils.width(1.9f));
    }
}
