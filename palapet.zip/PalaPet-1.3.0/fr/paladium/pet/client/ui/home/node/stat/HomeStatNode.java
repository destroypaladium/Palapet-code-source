//Decompiled by Procyon!

package fr.paladium.pet.client.ui.home.node.stat;

import fr.paladium.lib.apollon.nodes.abstracts.*;
import net.minecraft.util.*;
import net.minecraft.client.*;
import fr.paladium.lib.apollon.utils.text.*;
import fr.paladium.lib.apollon.fontV2.*;
import fr.paladium.lib.apollon.utils.*;
import fr.paladium.pet.client.ui.utils.data.*;
import java.util.*;
import fr.paladium.translate.common.texttotranslate.*;
import fr.paladium.pet.common.constant.*;

public class HomeStatNode extends ANode
{
    private static final Color PROGRESS_VOID_COLOR;
    private static final Color PROGRESS_VOID_UNDER_COLOR;
    private final StatType type;
    private final ResourceLocation logo;
    private final int value;
    private final int maxValue;
    private final HomeData homeData;
    private final List<String> texts;
    
    public HomeStatNode(final HomeData homedata, final double x, final double y, final double width, final double height, final StatType type, final int value, final int maxValue) {
        super(x, y, width, height);
        this.homeData = homedata;
        this.logo = new ResourceLocation("palapet", type.getTexture());
        this.type = type;
        this.value = value;
        this.maxValue = maxValue;
        this.texts = this.initTexts();
    }
    
    public void draw(final Minecraft mc, final int mouseX, final int mouseY) {
        super.draw(mc, mouseX, mouseY);
        final double logoX = this.ui.width(1.979f);
        final double logoY = this.ui.width(1.979f);
        GuiUtils.drawImageTransparent(this.x, this.y, this.logo, logoX, logoY);
        final double textX = this.x + logoX + this.ui.width(0.894f);
        double textY = this.y + this.ui.height(0.75f);
        int fontSize = 120;
        FontObj font = Fonts.MONTSERRAT_EXTRABOLD.getFont();
        GuiUtils.drawStringWithCustomFont(mc, this.type.getName().toUpperCase(), textX, textY, Color.WHITE, font, fontSize);
        final String text = String.valueOf(this.value + "/" + this.maxValue);
        font = Fonts.MINECRAFT_DUNGEONS_REGULAR.getFont();
        fontSize = 40;
        textY -= this.height(5.0f);
        GuiUtils.drawSplittedString(mc, text, this.x + this.width(100), textY, Color.WHITE, font, fontSize, (double)this.width(90.0f), TextAlign.RIGHT);
        this.drawProgressBar(logoY);
        this.drawHover(mouseX, mouseY);
    }
    
    private void drawHover(final int mouseX, final int mouseY) {
        if (!this.isHovered(mouseX, mouseY)) {
            return;
        }
        GuiUtils.hovers.add(new HoverObject(mouseX, mouseY, (List)this.texts, this.getHoverFont(), this.getHoverColor()));
    }
    
    private void drawProgressBar(final double logoY) {
        final double progressSpace = this.ui.height(1.389f);
        final double progressBarX = this.x;
        final double progressBarY = this.y + logoY + progressSpace;
        final double progressbarEndY = progressBarY + (this.height - logoY - progressSpace);
        GuiUtils.drawRect(progressBarX, progressBarY, progressBarX + this.width, progressbarEndY, HomeStatNode.PROGRESS_VOID_COLOR);
        final double underHeight = this.ui.height(0.648f);
        GuiUtils.drawRect(progressBarX, progressbarEndY - underHeight, progressBarX + this.width, progressbarEndY, HomeStatNode.PROGRESS_VOID_UNDER_COLOR);
        final double progress = this.value / (double)this.maxValue;
        final double progressWidth = progress * this.width;
        GuiUtils.drawRect(progressBarX, progressBarY, progressBarX + progressWidth, progressbarEndY, this.type.getProgressColor());
        GuiUtils.drawRect(progressBarX, progressbarEndY - underHeight, progressBarX + progressWidth, progressbarEndY, this.type.getProgressUnderColor());
    }
    
    private List<String> initTexts() {
        final ConfigClientData config = ConfigClientData.get();
        if (this.type.equals(StatType.EXPERIENCE)) {
            return this.initExperienceText(config);
        }
        if (this.type.equals(StatType.HAPPINESS)) {
            return this.initHappinessText(config);
        }
        return new ArrayList<String>();
    }
    
    private List<String> initHappinessText(final ConfigClientData config) {
        final String tttPrefix = "pet.gui.home.stat.happiness.line.";
        final List<String> tttList = new ArrayList<String>();
        for (int i = 0; i < 5; ++i) {
            final String key = tttPrefix + i;
            if (i == 1) {
                tttList.add(TTT.format(key, new Object[] { config.getHappinessLoss() }));
            }
            else {
                final int happinessMultiplier = (int)Math.floor(this.homeData.getHappinessMultiplier() * 100.0);
                if (i == 4) {
                    tttList.add(TTT.format(key, new Object[] { happinessMultiplier }));
                }
                else {
                    tttList.add(TTT.format(key, new Object[0]));
                }
            }
        }
        return tttList;
    }
    
    private List<String> initExperienceText(final ConfigClientData config) {
        final String tttPrefix = "pet.gui.home.stat.experience.line.";
        final List<String> tttList = new ArrayList<String>();
        for (int i = 0; i < 6; ++i) {
            final String key = tttPrefix + i;
            if (i == 5) {
                tttList.add(TTT.format(key, new Object[] { this.homeData.getLevel() }));
            }
            else {
                tttList.add(TTT.format(key, new Object[0]));
            }
        }
        return tttList;
    }
    
    public boolean onClick(final int i, final int i1, final int i2) {
        return false;
    }
    
    public void onRelease(final int i, final int i1, final int i2) {
    }
    
    public void onKeyTyped(final char c, final int i) {
    }
    
    public void onHover(final int i, final int i1) {
    }
    
    public void onHoverOut(final int i, final int i1) {
    }
    
    public void fixedUpdate() {
    }
    
    static {
        PROGRESS_VOID_COLOR = Color.decode("#323232");
        PROGRESS_VOID_UNDER_COLOR = Color.decode("#1A1A1A");
    }
    
    public enum StatType
    {
        HAPPINESS("Bonheur", "textures/ui/home/happiness_logo.png", Color.decode("#FC64C9"), Color.decode("#9B3077")), 
        EXPERIENCE("Exp\u00e9rience", "textures/ui/home/experience_logo.png", Color.decode("#5ED42A"), Color.decode("#3B8818"));
        
        private final String name;
        private final String texture;
        private final Color progressColor;
        private final Color progressUnderColor;
        
        private StatType(final String name, final String texture, final Color progressColor, final Color progressUnderColor) {
            this.name = name;
            this.texture = texture;
            this.progressColor = progressColor;
            this.progressUnderColor = progressUnderColor;
        }
        
        public String getName() {
            if (this.equals(StatType.EXPERIENCE)) {
                return PetTranslateEnum.GUI_NODE_STATS_EXPERIENCE.text();
            }
            return PetTranslateEnum.GUI_NODE_STATS_HAPPINESS.text();
        }
        
        public String getTexture() {
            return this.texture;
        }
        
        public Color getProgressColor() {
            return this.progressColor;
        }
        
        public Color getProgressUnderColor() {
            return this.progressUnderColor;
        }
    }
}
