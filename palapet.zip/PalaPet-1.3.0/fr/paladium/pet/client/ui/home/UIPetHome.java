//Decompiled by Procyon!

package fr.paladium.pet.client.ui.home;

import fr.paladium.pet.common.*;
import fr.paladium.pet.common.network.packet.pet.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import fr.paladium.pet.common.constant.*;
import fr.paladium.lib.apollon.nodes.label.*;
import fr.paladium.lib.apollon.nodes.buttons.buttons.*;
import fr.paladium.pet.client.ui.home.node.edit.*;
import fr.paladium.pet.client.ui.home.node.stat.*;
import fr.paladium.pet.client.ui.home.node.assignment.*;
import fr.paladium.pet.client.ui.home.node.skill.*;
import fr.paladium.lib.apollon.nodes.abstracts.*;
import fr.paladium.lib.apollon.nodes.buttons.utils.*;
import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.lib.apollon.nodes.flex.*;
import fr.paladium.pet.client.ui.home.node.skill.child.*;
import java.util.*;
import fr.paladium.lib.apollon.utils.*;
import fr.paladium.lib.apollon.ui.*;
import fr.paladium.palaforgeutils.lib.task.*;
import fr.paladium.pet.client.ui.home.popup.*;

public class UIPetHome extends UI
{
    public static final Color BACKGROUND_COLOR;
    private final HomeData data;
    
    public UIPetHome(final HomeData data) {
        this.data = data;
        PetCommonProxy.getInstance().getNetwork().sendToServer((IMessage)new BBUpdateClientConfigPacket());
    }
    
    public void func_73866_w_() {
        super.func_73866_w_();
        final MinecraftTitleNodeLabel titleNode = new MinecraftTitleNodeLabel((double)this.width(11.146f), (double)this.height(7.463f), PetTranslateEnum.GUI_HOME_TITLE.text());
        final MinecraftCloseNode closeNode = new MinecraftCloseNode((double)this.width(88.0f), (double)this.height(7.0f));
        final EditPetNode editPetNode = new EditPetNode(this, (double)this.width(11.146f), (double)this.height(16.574f), (double)this.width(16.574f), (double)this.height(35.741f));
        final double hapinessX = this.width(31.667f);
        final double hapinessY = this.height(17.222f);
        final double statWidth = this.width(27.865f);
        final double statHeight = this.height(10.594f);
        final HomeStatNode happinessNode = new HomeStatNode(this.data, hapinessX, hapinessY, statWidth, statHeight, HomeStatNode.StatType.HAPPINESS, this.data.getHappiness(), this.data.getMaxHappiness());
        final double experienceX = hapinessX + statWidth + this.width(1.823f);
        final double experienceY = hapinessY;
        final HomeStatNode experienceNode = new HomeStatNode(this.data, experienceX, experienceY, statWidth, statHeight, HomeStatNode.StatType.EXPERIENCE, this.data.getExperience(), this.data.getMaxExperience());
        final AssignmentGlobalNode assignmentNode = new AssignmentGlobalNode(this.data, (double)this.width(31.719f), (double)this.height(34.537f), (double)this.width(57.5f), (double)this.height(17.778f));
        final double skillNodeX = this.width(11.146f);
        final double skillNodeY = this.height(56.204f);
        final double skillNodeWidth = this.width(76.51f);
        final double skillNodeHeight = this.height(31.54f);
        final double skillNodeBackgroundY = this.height(61.296f);
        final SkillGlobalNode skillNode = new SkillGlobalNode(this, skillNodeX, skillNodeY, skillNodeWidth, skillNodeHeight, skillNodeBackgroundY);
        this.addNode((ANode)titleNode);
        this.addNode((ANode)closeNode);
        this.addNode((ANode)editPetNode);
        this.addNode((ANode)happinessNode);
        this.addNode((ANode)experienceNode);
        this.addNode((ANode)assignmentNode);
        this.addNode((ANode)skillNode);
        final double scrollAreaX = skillNodeX + skillNodeWidth + this.width(0.5f);
        final ScrollArea scrollArea = new ScrollArea(scrollAreaX, skillNodeBackgroundY, skillNodeHeight, (double)this.width(0.8f), (double)this.height(20.83f));
        final MinecraftScrollableArea area = MinecraftScrollableArea.builder().bounds(skillNodeX + this.width(1.1f), skillNodeBackgroundY, skillNodeX + skillNodeWidth + this.width(1.0f), skillNodeBackgroundY + skillNodeHeight);
        area.setScrollArea(scrollArea);
        this.addScrollableArea((ScrollableArea)area);
        this.initSkills(scrollArea, (ScrollableArea)area);
    }
    
    private void initSkills(final ScrollArea scrollArea, final ScrollableArea area) {
        int count = 0;
        final List<List<SlotClientData>> splitSkills = new ArrayList<List<SlotClientData>>();
        for (final SlotClientData data : this.data.getSlots()) {
            if (count == 0) {
                splitSkills.add(new ArrayList<SlotClientData>());
            }
            splitSkills.get(splitSkills.size() - 1).add(data);
            if (++count == 2) {
                count = 0;
            }
        }
        int posIncrement = 0;
        for (final List<SlotClientData> data2 : splitSkills) {
            final FlexNode flexNode = FlexNode.horizontal((double)this.width(12.292f), (double)this.height(63.241f + 12.5f * posIncrement++), (double)this.height(10.556f)).setMargin((double)this.width(1.25f));
            for (final SlotClientData d : data2) {
                final SlotClientData.SkillColorInfo info = d.getColorInfo();
                final SkillNode skl = new SkillNode(d, 0.0, 0.0, (double)this.width(36.563f), (double)this.height(10.556f));
                skl.setCallback(callback -> {
                    if (info.isCooldown() && !this.data.isBypass()) {
                        final long remaining = d.getNextChangeMillis() - System.currentTimeMillis();
                        PetTranslateEnum.MESSAGE_CHANGE_SKILL_COOLDOWN.notification(DurationConverter.fromMillisToString(remaining));
                        return;
                    }
                    if ((info.isCooldown() || info.equals(SlotClientData.SkillColorInfo.LOCKED)) && !this.data.isBypass()) {
                        return;
                    }
                    this.openPopup((UIPopup)new UIAssignSkillPopup(this, d.getSlot()));
                });
                skl.setSolid(false);
                flexNode.addChild((ANode)skl);
            }
            this.addNode((ANode)flexNode);
            flexNode.setArea(area);
        }
    }
    
    public void preDraw(final int mouseX, final int mouseY, final float ticks) {
        super.preDraw(mouseX, mouseY, ticks);
        this.func_146276_q_();
        BackgroundHelper.createMinecraft((double)this.width(83.22f), (double)this.height(88.889f));
    }
    
    public void postDraw(final int mouseX, final int mouseY, final float ticks) {
        super.postDraw(mouseX, mouseY, ticks);
    }
    
    public void openSkillRollUI() {
        this.openPopup((UIPopup)new UISkillRollPopup(this));
    }
    
    public void openEditPetUI() {
        this.openPopup((UIPopup)new UIChangeSkinPopup(this));
    }
    
    public HomeData getData() {
        return this.data;
    }
    
    static {
        BACKGROUND_COLOR = Color.decode("#1A1A1A");
    }
}
