//Decompiled by Procyon!

package fr.paladium.pet.client.ui.home.popup.node;

import fr.paladium.lib.apollon.nodes.abstracts.*;
import net.minecraft.util.*;
import fr.paladium.pet.client.ui.home.popup.*;
import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.pet.common.entity.*;
import fr.paladium.pet.client.ui.utils.*;
import net.minecraft.client.*;
import fr.paladium.lib.apollon.utils.*;

public class PetSkinNode extends AClickableNode
{
    private static final ResourceLocation BACKGROUND;
    private static final Color GREEN_FINISH_COLOR;
    private final UIChangeSkinPopup popup;
    private final SkinData data;
    private final EntityDummyPet pet;
    
    public PetSkinNode(final double x, final double y, final double size, final SkinData data, final UIChangeSkinPopup popup) {
        super(x, y, size, size);
        this.data = data;
        this.popup = popup;
        this.pet = PetRenderUtils.getPetFromEnum(this.data.getSkinId());
    }
    
    public void draw(final Minecraft mc, final int mouseX, final int mouseY) {
        super.draw(mc, mouseX, mouseY);
        final double size = this.width;
        final double x = this.x;
        final double y = this.y;
        GuiUtils.drawImageTransparent(x, y, PetSkinNode.BACKGROUND, size, size);
        if (this.isSelected()) {
            GuiUtils.drawRect(x, y, x + size, y + size, new Color(PetSkinNode.GREEN_FINISH_COLOR.r, PetSkinNode.GREEN_FINISH_COLOR.g, PetSkinNode.GREEN_FINISH_COLOR.b, 0.11f));
        }
        this.pet.field_70142_S = 0.0;
        this.pet.field_70137_T = 0.0;
        this.pet.field_70136_U = 0.0;
        this.pet.func_70634_a(0.0, 0.0, 0.0);
        this.pet.field_70173_aa = mc.field_71439_g.field_70173_aa;
        PetRenderUtils.drawPetOnUI((float)(x + this.width(50.0f)), (float)(y + this.height(70.0f)), this.width(40.0f), 300.0f, 0.0f, this.pet, 0.0f);
    }
    
    private boolean isSelected() {
        final SkinData selected = this.popup.getSelectedSkin();
        return this.data.getSkinId().equals(selected.getSkinId());
    }
    
    public boolean onClick(final int mouseX, final int mouseY, final int mouseButton) {
        return super.onClick(mouseX, mouseY, mouseButton);
    }
    
    public UIChangeSkinPopup getPopup() {
        return this.popup;
    }
    
    public SkinData getData() {
        return this.data;
    }
    
    public EntityDummyPet getPet() {
        return this.pet;
    }
    
    static {
        BACKGROUND = new ResourceLocation("palapet", "textures/ui/home/slot.png");
        GREEN_FINISH_COLOR = new Color(48, 203, 31);
    }
}
