//Decompiled by Procyon!

package fr.paladium.pet.client.ui.home.node.skill;

import fr.paladium.lib.apollon.nodes.abstracts.*;
import net.minecraft.util.*;
import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.pet.client.ui.home.*;
import fr.paladium.pet.common.constant.*;
import fr.paladium.lib.apollon.nodes.buttons.buttons.*;
import net.minecraft.client.*;
import fr.paladium.lib.apollon.utils.*;
import fr.paladium.lib.apollon.fontV2.*;
import fr.paladium.pet.client.ui.home.popup.*;
import fr.paladium.lib.apollon.ui.*;

public class SkillGlobalNode extends ANode
{
    private static final ResourceLocation LOGO;
    private final HomeData data;
    private final String title;
    private double buttonPosX;
    private final double backgroundY;
    private final UIPetHome parentUI;
    
    public SkillGlobalNode(final UIPetHome parentUI, final double x, final double y, final double width, final double height, final double backgroundY) {
        super(x, y, width, height);
        this.data = parentUI.getData();
        this.title = PetTranslateEnum.GUI_NODE_SKILL_TITLE.text();
        this.backgroundY = backgroundY;
        this.parentUI = parentUI;
    }
    
    public void onInit() {
        super.onInit();
        final ANode button = new MinecraftTextCallToActionNode((double)this.width(78.5f), (double)this.height(0.2f), (double)this.width(21.0f), PetTranslateEnum.GUI_NODE_SKILL_BUTTON_TITLE.text()).setCallback(callback -> this.ui.openPopup((UIPopup)new UISkillRollPopup(this.parentUI)));
        this.addChild(button);
        this.buttonPosX = this.width(78.5f) + this.width(21.0f);
    }
    
    public void draw(final Minecraft mc, final int mouseX, final int mouseY) {
        super.draw(mc, mouseX, mouseY);
        GuiUtils.drawRect(this.x, this.backgroundY, this.x + this.width, this.backgroundY + this.height, UIPetHome.BACKGROUND_COLOR);
        final double logoX = this.ui.width(1.979f);
        final double logoY = this.ui.width(1.979f);
        GuiUtils.drawImageTransparent(this.x, this.y, SkillGlobalNode.LOGO, logoX, logoY);
        final double textX = this.x + logoX + this.width(1.094f);
        final double textY = this.y + this.ui.height(0.75f);
        final int fontSize = 140;
        final FontObj font = Fonts.MONTSERRAT_EXTRABOLD.getFont();
        GuiUtils.drawStringWithCustomFont(mc, this.title, textX, textY, Color.WHITE, font, fontSize);
        final double barX = textX + GuiUtils.getStringWidth(mc, this.title, font, fontSize) + this.width(1.0f);
        final double barY = textY + GuiUtils.getFontHeight(mc, font, fontSize) / 2.0f;
        final double barHeight = this.height(0.4f);
        GuiUtils.drawRect(barX, barY, this.buttonPosX - this.width(7.5f), barY + barHeight, Color.WHITE);
    }
    
    public boolean onClick(final int i, final int i1, final int i2) {
        return false;
    }
    
    public void onRelease(final int i, final int i1, final int i2) {
    }
    
    public void onKeyTyped(final char c, final int i) {
    }
    
    public void onHover(final int i, final int i1) {
    }
    
    public void onHoverOut(final int i, final int i1) {
    }
    
    public void fixedUpdate() {
    }
    
    static {
        LOGO = new ResourceLocation("palapet", "textures/ui/home/skill_logo.png");
    }
}
