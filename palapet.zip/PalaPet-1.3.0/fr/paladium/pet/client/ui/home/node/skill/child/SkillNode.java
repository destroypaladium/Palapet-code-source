//Decompiled by Procyon!

package fr.paladium.pet.client.ui.home.node.skill.child;

import fr.paladium.lib.apollon.nodes.abstracts.*;
import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.client.*;
import fr.paladium.lib.apollon.utils.*;
import java.util.concurrent.*;
import fr.paladium.lib.apollon.utils.text.*;
import fr.paladium.lib.apollon.fontV2.*;
import java.util.*;

public class SkillNode extends AClickableNode
{
    private static final Color HOVER_COLOR;
    private final SlotClientData data;
    private final String activeSkill;
    private final String passiveSkill;
    private final String active;
    private final String passive;
    
    public SkillNode(final SlotClientData data, final double x, final double y, final double width, final double height) {
        super(x, y, width, height);
        this.data = data;
        this.activeSkill = PetTranslateEnum.GUI_NODE_SKILL_ACTIVE_SKILL.text();
        this.passiveSkill = PetTranslateEnum.GUI_NODE_SKILL_PASSIVE_SKILL.text();
        this.active = PetTranslateEnum.GUI_NODE_SKILL_ACTIVE.text();
        this.passive = PetTranslateEnum.GUI_NODE_SKILL_PASSIVE.text();
    }
    
    public void draw(final Minecraft mc, final int mouseX, final int mouseY) {
        super.draw(mc, mouseX, mouseY);
        GuiUtils.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, this.data.getColorInfo().getBackgroundColor());
        GuiUtils.drawBorder(this.x, this.y, this.x + this.width, this.y + this.height, this.data.getColorInfo().getBorderColor(), 1.0);
        final double nameX = this.x + this.width(15.0f);
        final double nameY = this.y + this.height(50.0f) / 2.0f;
        final double logoSize = this.width(7.0f);
        final double logoX = nameX - this.width(11.0f);
        final double logoY = nameY - this.height(2.0f);
        GuiUtils.drawImageTransparent(logoX, logoY, this.data.getLogo(), logoSize, logoSize, false);
        final String enumName = this.data.getColorInfo().toString();
        if (enumName.contains(this.active) || enumName.contains(this.passive)) {
            final String text = enumName.contains(this.active) ? this.activeSkill : this.passiveSkill;
            FontObj font = Fonts.MONTSERRAT_BOLD.getFont();
            int fontSize = 1;
            double textWidth = GuiUtils.getStringWidth(mc, text, font, fontSize);
            double labelY = this.y + this.height(13.0f);
            double labelX = this.x + this.width(100.0f) - textWidth - this.width(1.5f);
            GuiUtils.drawStringWithCustomFont(mc, text, labelX, labelY, this.data.getColorInfo().getBorderColor(), font, fontSize);
            final double labelWidth = GuiUtils.getStringWidth(mc, text, font, fontSize);
            final double labelHeight = GuiUtils.getFontHeight(mc, font, fontSize);
            final double cooldownX = labelX + labelWidth / 2.0;
            final double cooldownY = labelY + labelHeight + this.height(2.0f);
            if (this.data.getColorInfo().isCooldown()) {
                long remaining = this.data.getNextChangeMillis() - System.currentTimeMillis();
                if (remaining < 0L) {
                    remaining = 0L;
                }
                final String cooldownText = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(remaining) % 24L, TimeUnit.MILLISECONDS.toMinutes(remaining) % 60L, TimeUnit.MILLISECONDS.toSeconds(remaining) % 60L);
                font = Fonts.MONTSERRAT_REGULAR.getFont();
                fontSize = 1;
                textWidth = GuiUtils.getStringWidth(mc, cooldownText, font, fontSize);
                labelY = this.y + this.height(13.0f);
                labelX = this.x + this.width(100.0f) - textWidth - this.width(1.8f);
                GuiUtils.drawStringWithCustomFont(mc, cooldownText, labelX, cooldownY, this.data.getColorInfo().getBorderColor(), font, fontSize);
            }
        }
        FontObj font2 = Fonts.MONTSERRAT_EXTRABOLD.getFont();
        int fontSize2 = 50;
        GuiUtils.drawStringWithCustomFont(mc, this.data.getName().toUpperCase(), nameX, nameY, Color.WHITE, font2, fontSize2);
        final double descriptionX = nameX;
        double descriptionY = nameY + GuiUtils.getFontHeight(mc, font2, fontSize2) + this.height(13.0f);
        font2 = Fonts.MONTSERRAT_MEDIUM.getFont();
        fontSize2 = 15;
        final List<String> lines = (List<String>)GuiUtils.getSplittedString(mc, this.data.getDescription(), font2, fontSize2, (double)this.width(80.0f));
        final int lineHeight = GuiUtils.getFontHeight(mc, font2, fontSize2 + 10);
        for (int lineCount = Math.min(lines.size(), 3), i = 0; i < lineCount; ++i) {
            String text2 = lines.get(i);
            if (i == lineCount - 1 && lineCount != lines.size()) {
                text2 += TextOverflow.ELLIPSIS.getOverflow();
            }
            GuiUtils.drawStringWithCustomFont(mc, text2, descriptionX, descriptionY, Color.WHITE, font2, fontSize2);
            descriptionY += lineHeight;
        }
        if (this.isHovered() && this.data.getColorInfo() != SlotClientData.SkillColorInfo.LOCKED) {
            GuiUtils.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, SkillNode.HOVER_COLOR);
        }
    }
    
    static {
        HOVER_COLOR = new Color(0, 0, 0, 30);
    }
}
