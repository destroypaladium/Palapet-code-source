//Decompiled by Procyon!

package fr.paladium.pet.client.ui.home.popup;

import fr.paladium.lib.apollon.ui.*;
import fr.paladium.pet.client.ui.home.*;
import net.minecraft.client.gui.*;
import fr.paladium.lib.apollon.nodes.buttons.buttons.*;
import fr.paladium.pet.common.constant.*;
import fr.paladium.lib.apollon.nodes.label.*;
import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.pet.client.ui.home.node.skill.child.*;
import fr.paladium.lib.apollon.nodes.abstracts.*;
import fr.paladium.lib.apollon.nodes.buttons.utils.*;
import fr.paladium.lib.apollon.utils.*;
import fr.paladium.pet.common.*;
import fr.paladium.pet.common.network.packet.skill.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import fr.paladium.pet.common.network.packet.pet.*;

public class UIAssignSkillPopup extends UIPopup
{
    public static final String UI_ID = "palapet:POPUP-ASSIGN-SKILL";
    private final int slot;
    private final HomeData data;
    
    public UIAssignSkillPopup(final UIPetHome ui, final int slot) {
        super((GuiScreen)ui, "palapet:POPUP-ASSIGN-SKILL");
        this.slot = slot;
        this.data = ui.getData();
    }
    
    public void func_73866_w_() {
        super.func_73866_w_();
        final double areaX = this.width(31.71f);
        final double titleY = this.height(15.0f);
        final double subTitileY = titleY + this.height(10.0f);
        final ANode closeNode = new MinecraftCloseNode((double)this.width(68.0f), (double)this.height(13.0f)).setCallback(c -> this.closePopup());
        final MinecraftTitleNodeLabel titleNode = new MinecraftTitleNodeLabel(areaX, titleY, PetTranslateEnum.GUI_ASSIGN_SKILL_TITLE.text());
        final MinecraftSubTitleNodeLabel subtitleNode = new MinecraftSubTitleNodeLabel(areaX, subTitileY, PetTranslateEnum.GUI_ASSIGN_SKILL_SUBTITLE.text(this.slot + 1));
        final double areaY = this.height(30.019f);
        final double areaWidth = this.width(37.99f);
        final double areaHeight = this.height(52.593f);
        final double scrollAreaX = areaX + areaWidth - this.width(1.0f);
        final double scrollAreaY = areaY;
        final double scrollAreaWidth = this.width(0.83f);
        final double scrollAreaHeight = areaHeight;
        final ScrollArea scrollArea = new ScrollArea(scrollAreaX, scrollAreaY, scrollAreaHeight, (double)this.width(0.8f), (double)this.height(35.83f));
        final MinecraftScrollableArea area = MinecraftScrollableArea.builder().bounds(areaX, areaY, areaX + areaWidth, areaY + areaHeight);
        for (int i = 0; i < this.data.getSelectableSlots().size(); ++i) {
            final SlotClientData slotData = this.data.getSelectableSlots().get(i);
            final SkillNode skillNode = new SkillNode(slotData, (double)this.width(31.719f), (double)this.height(31.019f + 10.5f * i), (double)this.width(35.99f), (double)this.height(9.352f));
            skillNode.setCallback(callback -> {
                PetCommonProxy.getInstance().getNetwork().sendToServer((IMessage)new CSAssignSkillPacket(this.slot, slotData.getId()));
                PetCommonProxy.getInstance().getNetwork().sendToServer((IMessage)new BBOpenUIPacket());
            });
            this.addNode((ANode)skillNode);
            skillNode.setArea((ScrollableArea)area);
        }
        area.setScrollArea(scrollArea);
        this.addScrollableArea((ScrollableArea)area);
        this.addNode(closeNode);
        this.addNode((ANode)titleNode);
        this.addNode((ANode)subtitleNode);
    }
    
    public void preDraw(final int mouseX, final int mouseY, final float ticks) {
        this.func_146276_q_();
        BackgroundHelper.createMinecraft((double)this.width(43.021f), (double)this.height(76.481f));
    }
    
    public void postDraw(final int mouseX, final int mouseY, final float ticks) {
    }
}
