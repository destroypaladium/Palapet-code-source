//Decompiled by Procyon!

package fr.paladium.pet.client.ui.home.node.assignment;

import fr.paladium.lib.apollon.nodes.abstracts.*;
import net.minecraft.util.*;
import fr.paladium.lib.apollon.nodes.flex.*;
import fr.paladium.pet.common.constant.*;
import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.pet.client.ui.home.node.assignment.child.*;
import net.minecraft.client.*;
import fr.paladium.lib.apollon.utils.*;
import java.util.*;
import java.util.concurrent.*;
import fr.paladium.lib.apollon.fontV2.*;

public class AssignmentGlobalNode extends ANode
{
    private static final ResourceLocation LOGO;
    private final HomeData data;
    private final String title;
    private final String actualisationText;
    private FlexNode flexNode;
    
    public AssignmentGlobalNode(final HomeData data, final double x, final double y, final double width, final double height) {
        super(x, y, width, height);
        this.data = data;
        this.title = PetTranslateEnum.GUI_NODE_ASSIGNMENT_TITLE.text();
        this.actualisationText = PetTranslateEnum.GUI_NODE_ASSIGNMENT_REMAINING.text();
    }
    
    private void initFlexNode(final double startX, final double startY, final double nodeWidth, final double nodeHeight) {
        if (this.flexNode != null) {
            return;
        }
        final FlexNode flexNode = FlexNode.horizontal(startX, startY, nodeHeight).setMargin((double)this.width(0.7f));
        final int i = 0;
        for (final AssignmentClientData assignment : this.data.getAssignments()) {
            final AssignmentNode node = new AssignmentNode(assignment, 0.0, 0.0, nodeWidth, nodeHeight);
            flexNode.addChild((ANode)node);
        }
        this.addChild((ANode)(this.flexNode = flexNode));
    }
    
    public void draw(final Minecraft mc, final int mouseX, final int mouseY) {
        super.draw(mc, mouseX, mouseY);
        final double logoX = this.ui.width(1.979f);
        final double logoY = this.ui.width(1.979f);
        GuiUtils.drawImageTransparent(this.x, this.y, AssignmentGlobalNode.LOGO, logoX, logoY);
        final double textX = this.x + logoX + this.width(1.094f);
        final double textY = this.y + this.ui.height(0.75f);
        final int fontSize = 140;
        final FontObj font = Fonts.MONTSERRAT_EXTRABOLD.getFont();
        GuiUtils.drawStringWithCustomFont(mc, this.title, textX, textY, Color.WHITE, font, fontSize);
        final Calendar now = Calendar.getInstance();
        final Calendar midnight = Calendar.getInstance();
        midnight.set(11, 23);
        midnight.set(12, 59);
        midnight.set(13, 59);
        midnight.set(14, 999);
        final long remainingTime = midnight.getTimeInMillis() - now.getTimeInMillis();
        final FontObj remainingFont = Fonts.MONTSERRAT_SEMIBOLD.getFont();
        final int remainingFontSize = 1;
        final String duration = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(remainingTime), TimeUnit.MILLISECONDS.toMinutes(remainingTime) % 60L, TimeUnit.MILLISECONDS.toSeconds(remainingTime) % 60L);
        final String remainingString = this.actualisationText + duration;
        final double textWidth = GuiUtils.getStringWidth(mc, remainingString, remainingFont, remainingFontSize);
        final double remainingX = this.x + this.width(100.0f) - textWidth;
        final double remainingY = textY + this.height(6.0f);
        GuiUtils.drawStringWithCustomFont(mc, remainingString.toUpperCase(), remainingX, remainingY, Color.WHITE, remainingFont, remainingFontSize);
        final double barX = textX + GuiUtils.getStringWidth(mc, this.title, font, fontSize) + this.width(1.0f);
        final double barY = textY + GuiUtils.getFontHeight(mc, font, fontSize) / 2.0f;
        final double barHeight = this.height(0.5f);
        final double barEndX = Math.floor(remainingX - this.width(1.0f));
        GuiUtils.drawRect(barX, barY, barEndX, barY + barHeight, Color.WHITE);
        final double flexNodeX = 0.0;
        final double flexNodeY = logoY + this.height(6.0f);
        final double flexNodeWidth = this.width(24.5f);
        final double flexNodeHeight = flexNodeY + this.height(47.0f);
        this.initFlexNode(flexNodeX, flexNodeY, flexNodeWidth, flexNodeHeight);
    }
    
    public boolean onClick(final int i, final int i1, final int i2) {
        return false;
    }
    
    public void onRelease(final int i, final int i1, final int i2) {
    }
    
    public void onKeyTyped(final char c, final int i) {
    }
    
    public void onHover(final int i, final int i1) {
    }
    
    public void onHoverOut(final int i, final int i1) {
    }
    
    public void fixedUpdate() {
    }
    
    static {
        LOGO = new ResourceLocation("palapet", "textures/ui/home/assignment_logo.png");
    }
}
