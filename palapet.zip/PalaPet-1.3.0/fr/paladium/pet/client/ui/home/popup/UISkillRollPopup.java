//Decompiled by Procyon!

package fr.paladium.pet.client.ui.home.popup;

import fr.paladium.lib.apollon.ui.*;
import net.minecraft.util.*;
import fr.paladium.pet.client.ui.home.popup.node.*;
import fr.paladium.pet.client.ui.home.*;
import net.minecraft.client.gui.*;
import fr.paladium.pet.common.constant.*;
import fr.paladium.lib.apollon.nodes.buttons.buttons.*;
import fr.paladium.lib.apollon.nodes.label.*;
import fr.paladium.lib.apollon.nodes.abstracts.*;
import java.util.function.*;
import fr.paladium.pet.client.ui.utils.data.*;
import java.util.*;
import fr.paladium.lib.apollon.utils.*;

public class UISkillRollPopup extends UIPopup
{
    public static final String UI_ID = "palapet:POPUP-ASSIGN-SKILL";
    private static final ResourceLocation BACKGROUND_ROLL;
    private final HomeData data;
    private SkillSlotNode selectedSkill;
    private List<SkillHitBoxNode> hitBoxes;
    
    public UISkillRollPopup(final UIPetHome ui) {
        super((GuiScreen)ui, "palapet:POPUP-ASSIGN-SKILL");
        this.data = ui.getData();
        this.selectedSkill = null;
        this.hitBoxes = new ArrayList<SkillHitBoxNode>();
    }
    
    public void func_73866_w_() {
        super.func_73866_w_();
        final double titleX = this.width(30.95f);
        final double titleY = this.height(14.0f);
        final MinecraftTitleNodeLabel titleNode = new MinecraftTitleNodeLabel(titleX, titleY, PetTranslateEnum.GUI_SKILL_ROLL_TITLE.text()).setFontSize(180);
        final MinecraftSubTitleNodeLabel subTitleNode = new MinecraftSubTitleNodeLabel(titleX, titleY + this.height(9.0f), PetTranslateEnum.GUI_SKILL_ROLL_SUBTITLE.text()).setFontSize(25);
        final MinecraftCloseNode closeNode = new MinecraftCloseNode((double)this.width(67.976f), (double)this.height(13.0f));
        closeNode.setCallback(c -> this.closePopup());
        final TextNodeLabel descriptionNode = new TextNodeLabel((double)this.width(31.406f), (double)this.height(73.611f), PetTranslateEnum.GUI_SKILL_ROLL_DESCRIPTION.text(), Fonts.MONTSERRAT_BOLD.getFont(), 2, Color.WHITE);
        this.addNode((ANode)titleNode);
        this.addNode((ANode)subTitleNode);
        this.addNode((ANode)closeNode);
        this.addNode((ANode)descriptionNode);
        (this.hitBoxes = new ArrayList<SkillHitBoxNode>()).add(new SkillHitBoxNode(this, this.data.findSkillRollData(0), (double)this.width(50.5f), (double)this.height(60.9f), (double)this.width(9.3f), (double)this.height(9.5f), (double)this.width(53.5f), (double)this.height(64.0f)));
        this.hitBoxes.add(new SkillHitBoxNode(this, this.data.findSkillRollData(1), (double)this.width(40.4f), (double)this.height(60.9f), (double)this.width(9.3f), (double)this.height(9.5f), (double)this.width(44.5f), (double)this.height(64.0f)));
        this.hitBoxes.add(new SkillHitBoxNode(this, this.data.findSkillRollData(2), (double)this.width(38.5f), (double)this.height(41.5f), (double)this.width(4.5f), (double)this.height(16.5f), (double)this.width(39.3f), (double)this.height(48.2f)));
        this.hitBoxes.add(new SkillHitBoxNode(this, this.data.findSkillRollData(3), (double)this.width(40.5f), (double)this.height(29.5f), (double)this.width(9.3f), (double)this.height(9.5f), (double)this.width(44.5f), (double)this.height(32.5f)));
        this.hitBoxes.add(new SkillHitBoxNode(this, this.data.findSkillRollData(4), (double)this.width(50.5f), (double)this.height(29.5f), (double)this.width(9.3f), (double)this.height(9.5f), (double)this.width(54.0f), (double)this.height(32.5f)));
        this.hitBoxes.add(new SkillHitBoxNode(this, this.data.findSkillRollData(5), (double)this.width(57.0f), (double)this.height(41.5f), (double)this.width(4.5f), (double)this.height(16.5f), (double)this.width(58.5f), (double)this.height(48.2f)));
        this.hitBoxes.forEach((Consumer<? super Object>)this::addNode);
        int index = 0;
        final double slotStartX = this.width(31.406f);
        final double slotStartY = this.height(76.315f);
        final double slotSize = this.width(4.948f);
        final double space = this.width(6.25f);
        for (final SlotClientData slot : this.data.getSlots()) {
            if (!slot.getColorInfo().isActive()) {
                continue;
            }
            boolean found = false;
            for (final SkillRollSlotData skillRollSlot : this.data.getSkillRollSlots()) {
                if (skillRollSlot.getSkillId().equals(slot.getId())) {
                    found = true;
                    break;
                }
            }
            if (found) {
                continue;
            }
            final SkillSlotNode skillSlotNode = new SkillSlotNode(slotStartX + space * index, slotStartY, slotSize, slot, this, (List)this.hitBoxes);
            skillSlotNode.setCallback(c -> this.selectedSkill = skillSlotNode);
            this.addNode((ANode)skillSlotNode);
            ++index;
        }
    }
    
    public void preDraw(final int mouseX, final int mouseY, final float ticks) {
        this.func_146276_q_();
        BackgroundHelper.createMinecraft((double)this.width(43.021f), (double)this.height(76.481f));
        final double backgroundHeight;
        final double backgroundWidth = backgroundHeight = this.width(22.708f);
        final double backgroundX = this.width(50.0f) - backgroundWidth / 2.0;
        final double backgroundY = this.height(50.0f) - backgroundHeight / 2.0;
        GuiUtils.drawImageTransparent(backgroundX, backgroundY, UISkillRollPopup.BACKGROUND_ROLL, backgroundWidth, backgroundHeight);
    }
    
    protected void func_73864_a(final int mouseX, final int mouseY, final int buttonID) {
        super.func_73864_a(mouseX, mouseY, buttonID);
    }
    
    protected void func_146286_b(final int mouseX, final int mouseY, final int buttonID) {
        super.func_146286_b(mouseX, mouseY, buttonID);
        if (buttonID == 0 && this.selectedSkill != null) {
            for (final SkillHitBoxNode hitBox : this.hitBoxes) {
                if (hitBox.onAssign(this, mouseX, mouseY)) {
                    return;
                }
            }
            this.selectedSkill = null;
        }
    }
    
    public void postDraw(final int mouseX, final int mouseY, final float ticks) {
    }
    
    public HomeData getData() {
        return this.data;
    }
    
    public SkillSlotNode getSelectedSkill() {
        return this.selectedSkill;
    }
    
    public List<SkillHitBoxNode> getHitBoxes() {
        return this.hitBoxes;
    }
    
    public void setSelectedSkill(final SkillSlotNode selectedSkill) {
        this.selectedSkill = selectedSkill;
    }
    
    public void setHitBoxes(final List<SkillHitBoxNode> hitBoxes) {
        this.hitBoxes = hitBoxes;
    }
    
    static {
        BACKGROUND_ROLL = new ResourceLocation("palapet", "textures/ui/home/skill_roll_background.png");
    }
}
