//Decompiled by Procyon!

package fr.paladium.pet.client.ui.home.node.assignment.child.node;

import fr.paladium.lib.apollon.nodes.label.*;
import fr.paladium.pet.client.ui.home.node.assignment.child.*;
import fr.paladium.lib.apollon.fontV2.*;
import net.minecraft.client.*;
import fr.paladium.lib.apollon.utils.*;

public class AssignmentTextNodeLabel extends TextNodeLabel
{
    private AssignmentNode parentNode;
    
    public AssignmentTextNodeLabel(final double x, final double y, final String text, final FontObj font, final int fontSize, final Color color, final AssignmentNode parentNode) {
        super(x, y, text, font, fontSize, color);
        this.parentNode = parentNode;
    }
    
    public void draw(final Minecraft mc, final int mouseX, final int mouseY) {
        super.draw(mc, mouseX, mouseY);
        final double parentX = this.parentNode.x;
        final double parentY = this.parentNode.y;
        final double parentWidth = this.parentNode.width;
        final double parentHeight = this.parentNode.height;
        if (this.parentNode.getData().isFinish()) {
            GuiUtils.drawRect(parentX, parentY, parentX + parentWidth, parentY + parentHeight, new Color(AssignmentNode.GREEN_FINISH_COLOR.r, AssignmentNode.GREEN_FINISH_COLOR.g, AssignmentNode.GREEN_FINISH_COLOR.b, 0.3f));
            final double logoWidth = this.parentNode.width(18.888f);
            final double logoHeight = this.parentNode.width(18.888f);
            GuiUtils.drawImageTransparent(parentX + this.parentNode.width(40.0f), parentY + this.parentNode.height(30.0f), AssignmentNode.UNION_LOGO, logoWidth, logoHeight);
        }
    }
}
