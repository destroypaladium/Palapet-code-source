//Decompiled by Procyon!

package fr.paladium.pet.client.ui.home.popup.node;

import fr.paladium.lib.apollon.nodes.abstracts.*;
import net.minecraft.util.*;
import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.pet.client.ui.home.popup.*;
import net.minecraft.client.*;
import fr.paladium.lib.apollon.utils.*;
import java.util.*;

public class SkillSlotNode extends AClickableNode
{
    private static final ResourceLocation BACKGROUND;
    private final SlotClientData data;
    private final ResourceLocation logo;
    private final UISkillRollPopup parentPopup;
    private final List<SkillHitBoxNode> hitBoxes;
    
    public SkillSlotNode(final double x, final double y, final double size, final SlotClientData data, final UISkillRollPopup parentPopup, final List<SkillHitBoxNode> hitBoxes) {
        super(x, y, size, size);
        this.data = data;
        this.logo = data.getLogo();
        this.parentPopup = parentPopup;
        this.hitBoxes = hitBoxes;
    }
    
    public void draw(final Minecraft mc, final int mouseX, final int mouseY) {
        super.draw(mc, mouseX, mouseY);
        final double size = this.isHitBoxHovered() ? (this.width * 1.2) : this.width;
        final boolean selected = this.isSelected();
        final double x = selected ? (mouseX - size / 2.0) : this.x;
        final double y = selected ? (mouseY - size / 2.0) : this.y;
        GuiUtils.drawImageTransparent(x, y, SkillSlotNode.BACKGROUND, size, size);
        final double logoX = size * 0.2;
        final double logoY = size * 0.2;
        final double logoSize = size * 0.6;
        GuiUtils.drawImageTransparent(x + logoX, y + logoY, this.logo, logoSize, logoSize, false);
    }
    
    private boolean isSelected() {
        return this.parentPopup != null && this.parentPopup.getSelectedSkill() != null && this.parentPopup.getSelectedSkill().equals(this);
    }
    
    private boolean isHitBoxHovered() {
        if (!this.isSelected()) {
            return false;
        }
        for (final SkillHitBoxNode hitbox : this.hitBoxes) {
            if (hitbox.isHovered()) {
                return true;
            }
        }
        return false;
    }
    
    public void onRelease(final int mouseX, final int mouseY, final int mouseButton) {
        super.onRelease(mouseX, mouseY, mouseButton);
    }
    
    public SlotClientData getData() {
        return this.data;
    }
    
    public ResourceLocation getLogo() {
        return this.logo;
    }
    
    public UISkillRollPopup getParentPopup() {
        return this.parentPopup;
    }
    
    public List<SkillHitBoxNode> getHitBoxes() {
        return this.hitBoxes;
    }
    
    static {
        BACKGROUND = new ResourceLocation("palapet", "textures/ui/home/slot.png");
    }
}
