//Decompiled by Procyon!

package fr.paladium.pet.client.ui.home.popup.node;

import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.pet.client.ui.home.popup.*;
import fr.paladium.pet.common.*;
import fr.paladium.pet.common.network.packet.skill.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import fr.paladium.pet.common.network.packet.pet.*;
import net.minecraft.client.*;
import fr.paladium.lib.apollon.utils.*;
import fr.paladium.lib.apollon.nodes.abstracts.*;

public class SkillHitBoxNode extends AClickableNode
{
    private final SkillRollSlotData data;
    private final double iconPosX;
    private final double iconPosY;
    
    public SkillHitBoxNode(final UISkillRollPopup parentUI, final SkillRollSlotData data, final double x, final double y, final double width, final double height, final double iconPosX, final double iconPosY) {
        super(x, y, width, height);
        this.data = data;
        this.iconPosX = iconPosX;
        this.iconPosY = iconPosY;
        this.setCallback(callback -> {
            if (parentUI.getSelectedSkill() == null) {
                PetCommonProxy.getInstance().getNetwork().sendToServer((IMessage)new CSAssignRollPacket(this.data.getSlot(), "remove"));
                PetCommonProxy.getInstance().getNetwork().sendToServer((IMessage)new BBOpenSkillRollUIPacket());
            }
        });
    }
    
    public boolean onAssign(final UISkillRollPopup parentUI, final int mouseX, final int mouseY) {
        if (!this.isHovered(mouseX, mouseY) || parentUI.getSelectedSkill() == null) {
            return false;
        }
        PetCommonProxy.getInstance().getNetwork().sendToServer((IMessage)new CSAssignRollPacket(this.data.getSlot(), parentUI.getSelectedSkill().getData().getId()));
        PetCommonProxy.getInstance().getNetwork().sendToServer((IMessage)new BBOpenSkillRollUIPacket());
        return true;
    }
    
    public void draw(final Minecraft mc, final int mouseX, final int mouseY) {
        super.draw(mc, mouseX, mouseY);
        final double iconSize = GuiUtils.width(2.0f);
        GuiUtils.drawImageTransparent(this.iconPosX, this.iconPosY, this.data.getLogo(), iconSize, iconSize, false);
    }
    
    public boolean isHovered() {
        return super.isHovered();
    }
}
