//Decompiled by Procyon!

package fr.paladium.pet.client.ui.home.node.assignment.child;

import fr.paladium.lib.apollon.nodes.abstracts.*;
import net.minecraft.util.*;
import net.minecraft.client.*;
import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.pet.client.ui.home.node.assignment.child.node.*;
import fr.paladium.pet.server.config.assignment.fields.*;
import fr.paladium.pet.client.ui.home.*;
import fr.paladium.lib.apollon.utils.*;
import fr.paladium.lib.apollon.nodes.label.*;
import fr.paladium.lib.apollon.utils.text.*;
import fr.paladium.lib.apollon.fontV2.*;
import java.util.*;
import fr.paladium.pet.common.*;
import fr.paladium.pet.common.network.packet.pet.*;
import cpw.mods.fml.common.network.simpleimpl.*;

public class AssignmentNode extends ANode
{
    public static final Color GREEN_FINISH_COLOR;
    private static final Color PROGRESS_VOID_COLOR;
    private static final Color PROGRESS_VOID_UNDER_COLOR;
    private static final Color PROGRESS_COLOR;
    private static final Color PROGRESS_UNDER_COLOR;
    public static final ResourceLocation UNION_LOGO;
    private final Minecraft mc;
    private final AssignmentClientData data;
    
    public AssignmentNode(final AssignmentClientData data, final double x, final double y, final double width, final double height) {
        super(x, y, width, height);
        this.data = data;
        this.mc = Minecraft.func_71410_x();
        final double nodeWidth = this.width(30.0f);
        final double nodeHeight = this.height(15.0f);
        final ANode feedNode = new FeedButtonNode((this.width(100.0f) - nodeWidth) / 2.0, this.height(100.0f) - nodeHeight / 2.0, nodeWidth, nodeHeight).setCallback(callback -> PetCommonProxy.getInstance().getNetwork().sendToServer((IMessage)new CSPOpenFeedContainerPacket()));
        if (!this.data.isFinish() && this.data.getType().equals(AssignmentType.ITEM)) {
            this.addChild(feedNode);
        }
    }
    
    public void draw(final Minecraft mc, final int mouseX, final int mouseY) {
        super.draw(mc, mouseX, mouseY);
        GuiUtils.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, UIPetHome.BACKGROUND_COLOR);
        final double logoPosX = this.x + this.width(4.0f);
        final double logoPosY = this.y + this.height(20.0f);
        this.drawLogo(logoPosX, logoPosY);
        final double titlePosX = logoPosX + this.width(23.0f);
        final double titlePosY = logoPosY;
        final int titleFontSize = 1;
        final TextNodeLabel title = new TextNodeLabel(titlePosX, logoPosY, this.data.getName().toUpperCase(), Fonts.PIXEL_NES.getFont(), titleFontSize, Color.WHITE);
        title.setTextOverflow(TextOverflow.ELLIPSIS);
        title.setWidth((double)this.width(70.0f));
        title.draw(mc, mouseY, mouseY);
        this.drawDescription(titlePosX, titlePosY + this.height(15.0f));
        final double progressBarX = titlePosX;
        final double progressBarY = titlePosY + this.height(50.0f);
        final double progressbarHeight = this.height(7.0f);
        final double progressbarWidth = this.width(50.0f);
        this.drawProgressBar(progressBarX, progressBarY, progressbarHeight, progressbarWidth);
        if (this.data.isFinish()) {
            GuiUtils.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, new Color(AssignmentNode.GREEN_FINISH_COLOR.r, AssignmentNode.GREEN_FINISH_COLOR.g, AssignmentNode.GREEN_FINISH_COLOR.b, 0.3f));
            final double logoWidth = this.width(18.888f);
            final double logoHeight = this.width(18.888f);
            GuiUtils.drawImageTransparent(this.x + this.width(40.0f), this.y + this.height(30.0f), AssignmentNode.UNION_LOGO, logoWidth, logoHeight);
        }
    }
    
    public void drawFinish(final Minecraft mc, final int mouseX, final int mouseY) {
        if (this.data.isFinish()) {
            GuiUtils.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, new Color(AssignmentNode.GREEN_FINISH_COLOR.r, AssignmentNode.GREEN_FINISH_COLOR.g, AssignmentNode.GREEN_FINISH_COLOR.b, 0.3f));
            final double logoWidth = this.width(18.888f);
            final double logoHeight = this.width(18.888f);
            GuiUtils.drawImageTransparent(this.x + this.width(40.0f), this.y + this.height(30.0f), AssignmentNode.UNION_LOGO, logoWidth, logoHeight);
        }
    }
    
    private void drawLogo(final double posX, final double posY) {
        final double logoWidth = this.width(18.888f);
        final double logoHeight = this.width(18.888f);
        GuiUtils.drawImageTransparent(posX, posY, this.data.getLogo(), logoWidth, logoHeight, false);
    }
    
    private void drawDescription(final double posX, double posY) {
        final int fontSize = 1;
        final FontObj font = Fonts.MONTSERRAT_REGULAR.getFont();
        final List<String> lines = (List<String>)GuiUtils.getSplittedString(this.mc, this.data.getDescription(), font, fontSize, (double)this.width(70.0f));
        final int lineHeight = GuiUtils.getFontHeight(this.mc, font, fontSize + 10);
        for (int lineCount = Math.min(lines.size(), 3), i = 0; i < lineCount; ++i) {
            String text = lines.get(i);
            if (i == lineCount - 1 && lineCount != lines.size()) {
                text += TextOverflow.ELLIPSIS.getOverflow();
            }
            GuiUtils.drawStringWithCustomFont(this.mc, text, posX, posY, Color.WHITE, font, fontSize);
            posY += lineHeight;
        }
    }
    
    private void drawProgressBar(final double posX, final double posY, final double barHeight, final double barWidth) {
        GuiUtils.drawRect(posX, posY, posX + barWidth, posY + barHeight, AssignmentNode.PROGRESS_VOID_COLOR);
        final double underHeight = barHeight * 0.2;
        GuiUtils.drawRect(posX, posY + barHeight - underHeight, posX + barWidth, posY + barHeight, AssignmentNode.PROGRESS_VOID_UNDER_COLOR);
        final double progress = this.data.getProgress() / this.data.getMaxProgress();
        final double progressWidth = progress * barWidth;
        GuiUtils.drawRect(posX, posY, posX + progressWidth, posY + barHeight, AssignmentNode.PROGRESS_COLOR);
        GuiUtils.drawRect(posX, posY + barHeight - underHeight, posX + progressWidth, posY + barHeight, AssignmentNode.PROGRESS_UNDER_COLOR);
        final String progressText = this.getProgressText();
        final int fontSize = -35;
        final FontObj font = Fonts.MONTSERRAT_EXTRABOLD.getFont();
        GuiUtils.drawStringWithCustomFont(this.mc, progressText, posX + barWidth + this.width(1.0f), posY + this.height(1.0f), Color.WHITE, font, fontSize);
    }
    
    private String getProgressText() {
        final double minute = 60.0;
        final AssignmentType type = this.data.getType();
        if (type.isTimedType() && this.data.getMaxProgress() > minute) {
            final double currentMinutes = this.data.getProgress() / minute;
            final double maxMinutes = this.data.getMaxProgress() / minute;
            return this.formatNumber(currentMinutes) + "/" + this.formatNumber(maxMinutes);
        }
        return this.formatNumber(this.data.getProgress()) + "/" + this.formatNumber(this.data.getMaxProgress());
    }
    
    private String formatNumber(final double number) {
        return (number % 1.0 == 0.0) ? String.format("%d", (int)number) : String.format("%.1f", number);
    }
    
    public boolean onClick(final int i, final int i1, final int i2) {
        return false;
    }
    
    public void onRelease(final int i, final int i1, final int i2) {
    }
    
    public void onKeyTyped(final char c, final int i) {
    }
    
    public void onHover(final int i, final int i1) {
    }
    
    public void onHoverOut(final int i, final int i1) {
    }
    
    public void fixedUpdate() {
    }
    
    public Minecraft getMc() {
        return this.mc;
    }
    
    public AssignmentClientData getData() {
        return this.data;
    }
    
    static {
        GREEN_FINISH_COLOR = new Color(48, 203, 31);
        PROGRESS_VOID_COLOR = Color.decode("#323232");
        PROGRESS_VOID_UNDER_COLOR = Color.decode("#1A1A1A");
        PROGRESS_COLOR = Color.decode("#5ED42A");
        PROGRESS_UNDER_COLOR = Color.decode("#3B8818");
        UNION_LOGO = new ResourceLocation("palapet", "textures/ui/home/union_logo.png");
    }
}
