//Decompiled by Procyon!

package fr.paladium.pet.client.ui.home.node.edit;

import fr.paladium.lib.apollon.nodes.abstracts.*;
import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.pet.common.entity.*;
import fr.paladium.pet.client.ui.home.*;
import fr.paladium.pet.client.ui.home.node.edit.child.*;
import fr.paladium.pet.client.ui.utils.*;
import fr.paladium.lib.apollon.nodes.buttons.buttons.*;
import net.minecraft.client.*;
import fr.paladium.lib.apollon.utils.*;
import org.lwjgl.opengl.*;
import fr.paladium.pet.common.*;
import fr.paladium.pet.common.network.packet.pet.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import fr.paladium.pet.client.ui.home.popup.*;
import fr.paladium.lib.apollon.ui.*;

public class EditPetNode extends ANode
{
    private final HomeData data;
    private final EntityDummyPet pet;
    
    public EditPetNode(final UIPetHome parentUI, final double x, final double y, final double width, final double height) {
        super(x, y, width, height);
        this.data = parentUI.getData();
        final EditPetButtonNode editPetButtonNode = new EditPetButtonNode((double)this.width(85.0f), (double)this.height(2.0f));
        editPetButtonNode.setCallback(c -> parentUI.openPopup((UIPopup)new UIChangeSkinPopup(parentUI)));
        this.addChild((ANode)editPetButtonNode);
        this.pet = PetRenderUtils.getPetFromEnum(parentUI.getData().getCurrentSkin().getSkinId());
        final String title = this.data.isVisible() ? "Visible" : "Invisible";
        final ANode button = new MinecraftTextCallToActionNode((double)this.width(5.5f), (double)this.height(83.0f), (double)this.width(89.0f), title).setCallback(callback -> PetCommonProxy.getInstance().getNetwork().sendToServer((IMessage)new CSChangeSkinVisibilityPacket()));
        this.addChild(button);
    }
    
    public void draw(final Minecraft mc, final int mouseX, final int mouseY) {
        super.draw(mc, mouseX, mouseY);
        GuiUtils.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, UIPetHome.BACKGROUND_COLOR);
        final double logoSize = this.ui.width(13.49f);
        final double logoX = this.x + this.width(50.0f) - logoSize / 2.0;
        final double logoY = this.y + this.height(10.0f);
        this.pet.field_70142_S = 0.0;
        this.pet.field_70137_T = 0.0;
        this.pet.field_70136_U = 0.0;
        this.pet.func_70634_a(0.0, 0.0, 0.0);
        this.pet.field_70173_aa = mc.field_71439_g.field_70173_aa;
        GL11.glPushMatrix();
        GL11.glScaled(1.0, 1.0, (double)(1.0f / this.width(40.0f)));
        PetRenderUtils.drawPetOnUI((float)(this.x + this.width(50.0f)), (float)(this.y + this.height(70.0f)), this.width(40.0f), 300.0f, 0.0f, this.pet, 0.0f);
        GL11.glPopMatrix();
    }
    
    public boolean onClick(final int i, final int i1, final int i2) {
        return false;
    }
    
    public void onRelease(final int i, final int i1, final int i2) {
    }
    
    public void onKeyTyped(final char c, final int i) {
    }
    
    public void onHover(final int i, final int i1) {
    }
    
    public void onHoverOut(final int i, final int i1) {
    }
    
    public void fixedUpdate() {
    }
}
