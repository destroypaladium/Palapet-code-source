//Decompiled by Procyon!

package fr.paladium.pet.client.ui.home.popup;

import fr.paladium.lib.apollon.ui.*;
import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.pet.common.entity.*;
import fr.paladium.pet.client.ui.home.*;
import net.minecraft.client.gui.*;
import fr.paladium.pet.client.ui.utils.*;
import fr.paladium.pet.common.constant.*;
import fr.paladium.lib.apollon.nodes.label.*;
import fr.paladium.lib.apollon.nodes.buttons.buttons.*;
import fr.paladium.lib.apollon.nodes.buttons.utils.*;
import fr.paladium.lib.apollon.nodes.abstracts.*;
import fr.paladium.lib.apollon.utils.*;
import fr.paladium.pet.common.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import fr.paladium.pet.common.network.packet.pet.*;
import fr.paladium.lib.apollon.nodes.flex.*;
import fr.paladium.pet.client.ui.home.popup.node.*;
import java.util.*;

public class UIChangeSkinPopup extends UIPopup
{
    public static final String UI_ID = "palapet:POPUP-CHANGE-SKIN";
    private static final Color BACKGROUND_COLOR;
    private final HomeData data;
    private SkinData selectedSkin;
    private EntityDummyPet pet;
    
    public UIChangeSkinPopup(final UIPetHome ui) {
        super((GuiScreen)ui, "palapet:POPUP-CHANGE-SKIN");
        this.data = ui.getData();
        this.selectedSkin = this.data.getCurrentSkin();
        this.pet = PetRenderUtils.getPetFromEnum(this.selectedSkin.getSkinId());
    }
    
    public void func_73866_w_() {
        super.func_73866_w_();
        final double areaX = this.width(31.71f);
        final double titleY = this.height(15.0f);
        final double subTitleY = titleY + this.height(10.0f);
        final double validateWidth = this.width(16.51f);
        final double validateX = this.width(50.0f) - validateWidth / 2.0;
        final double validateY = this.height(81.5f);
        final ANode closeNode = new MinecraftCloseNode((double)this.width(68.0f), (double)this.height(13.0f)).setCallback(c -> this.closePopup());
        final MinecraftTitleNodeLabel titleNode = new MinecraftTitleNodeLabel(areaX, titleY, PetTranslateEnum.GUI_CHANGE_SKIN_TITLE.text());
        final MinecraftSubTitleNodeLabel subtitleNode = new MinecraftSubTitleNodeLabel(areaX, subTitleY, PetTranslateEnum.GUI_CHANGE_SKIN_SUBTITLE.text());
        final ANode validateNode = new MinecraftTextCallToActionNode(validateX, validateY, validateWidth, PetTranslateEnum.GUI_CHANGE_SKIN_VALIDATE_TEXT.text()).setCallback(callback -> this.confirm());
        final double scrollX = this.width(29.052f);
        final double scrollY = this.height(57.5f);
        final double skillNodeWidth = this.width(40.698f);
        final double skillNodeHeight = this.height(23.1f);
        final double scrollAreaX = scrollX + skillNodeWidth - this.width(0.5f);
        final ScrollArea scrollArea = new ScrollArea(scrollAreaX, scrollY, skillNodeHeight, (double)this.width(0.8f), (double)this.height(14.83f));
        final MinecraftScrollableArea area = MinecraftScrollableArea.builder().bounds(scrollX, scrollY, scrollX + skillNodeWidth, scrollY + skillNodeHeight);
        area.setScrollArea(scrollArea);
        this.addScrollableArea((ScrollableArea)area);
        this.addNode(closeNode);
        this.addNode((ANode)titleNode);
        this.addNode((ANode)subtitleNode);
        this.addNode(validateNode);
        this.initSkins((ScrollableArea)area);
    }
    
    public void preDraw(final int mouseX, final int mouseY, final float ticks) {
        this.func_146276_q_();
        BackgroundHelper.createMinecraft((double)this.width(43.021f), (double)this.height(76.481f));
        final double backgroundX = this.width(28.497f);
        final double backgroundY = this.height(29.5f);
        final double backgroundWidth = this.width(42.221f);
        final double backgroundHeight = this.height(27.407f);
        GuiUtils.drawRect(backgroundX, backgroundY, backgroundX + backgroundWidth, backgroundY + backgroundHeight, UIChangeSkinPopup.BACKGROUND_COLOR);
        final float size = 12.0f;
        final float petWidth = this.width(size);
        final float petHeight = this.width(size);
        final float petX = this.width(50.0f) - petWidth / 2.0f;
        final float petY = (float)(backgroundHeight / 2.0 + backgroundY - petHeight / 2.0f);
        this.pet.field_70142_S = 0.0;
        this.pet.field_70137_T = 0.0;
        this.pet.field_70136_U = 0.0;
        this.pet.func_70634_a(0.0, 0.0, 0.0);
        this.pet.field_70173_aa = this.field_146297_k.field_71439_g.field_70173_aa;
        PetRenderUtils.drawPetOnUI(this.width(50.0f), this.height(53.0f), this.width(8.0f), 300.0f, 0.0f, this.pet, 0.0f);
    }
    
    private void confirm() {
        if (this.selectedSkin == null) {
            return;
        }
        PetCommonProxy.getInstance().getNetwork().sendToServer((IMessage)new CSChangePetSkinPacket(this.selectedSkin.getSkinId()));
        PetCommonProxy.getInstance().getNetwork().sendToServer((IMessage)new BBOpenUIPacket());
    }
    
    private void initSkins(final ScrollableArea area) {
        int count = 0;
        final int skinPerLine = 6;
        final List<List<SkinData>> splitSkins = new ArrayList<List<SkinData>>();
        for (final SkinData skinData : this.data.getSkins()) {
            if (count == 0) {
                splitSkins.add(new ArrayList<SkinData>());
            }
            splitSkins.get(splitSkins.size() - 1).add(skinData);
            if (++count == skinPerLine) {
                count = 0;
            }
        }
        int posIncrement = 0;
        for (final List<SkinData> skinDatas : splitSkins) {
            final FlexNode flexNode = FlexNode.horizontal((double)this.width(30.052f), (double)this.height(58.5f + 12.15f * posIncrement++), (double)this.height(11.8f)).setMargin((double)this.width(0.3f));
            for (final SkinData skinData2 : skinDatas) {
                final PetSkinNode skl = new PetSkinNode(0.0, 0.0, (double)this.width(6.2f), skinData2, this);
                skl.setCallback(callback -> {
                    this.selectedSkin = skinData2;
                    this.pet = PetRenderUtils.getPetFromEnum(this.selectedSkin.getSkinId());
                });
                flexNode.addChild((ANode)skl);
            }
            this.addNode((ANode)flexNode);
            flexNode.setArea(area);
        }
    }
    
    public void postDraw(final int mouseX, final int mouseY, final float ticks) {
    }
    
    public HomeData getData() {
        return this.data;
    }
    
    public SkinData getSelectedSkin() {
        return this.selectedSkin;
    }
    
    public EntityDummyPet getPet() {
        return this.pet;
    }
    
    static {
        BACKGROUND_COLOR = Color.decode("#1A1A1E");
    }
}
