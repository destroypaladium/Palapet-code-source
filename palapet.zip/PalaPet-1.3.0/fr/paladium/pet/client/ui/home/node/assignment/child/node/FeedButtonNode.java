//Decompiled by Procyon!

package fr.paladium.pet.client.ui.home.node.assignment.child.node;

import fr.paladium.lib.apollon.nodes.buttons.buttons.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.client.*;
import fr.paladium.lib.apollon.utils.*;

public class FeedButtonNode extends MinecraftTextCallToActionNode
{
    private final String title;
    
    public FeedButtonNode(final double x, final double y, final double width, final double height) {
        super(x, y, width, height, 5.0, PetTranslateEnum.GUI_NODE_FEED_TITLE.text());
        this.title = PetTranslateEnum.GUI_NODE_FEED_TITLE.text();
    }
    
    public void drawContent(final Minecraft mc, final int mouseX, final int mouseY) {
        final int fontSize = -10;
        final int fontHeight = GuiUtils.getFontHeight(mc, Fonts.PIXEL_NES.getFont(), fontSize);
        GuiUtils.drawCenteredStringWithCustomFont(mc, this.title, this.x + this.width / 2.0, this.y + this.height / 2.0 - fontHeight / 2, Color.WHITE, Fonts.PIXEL_NES.getFont(), fontSize, true, Color.BLACK);
    }
}
