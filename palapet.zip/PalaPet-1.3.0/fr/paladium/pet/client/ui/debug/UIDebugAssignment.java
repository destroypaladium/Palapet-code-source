//Decompiled by Procyon!

package fr.paladium.pet.client.ui.debug;

import fr.paladium.lib.apollon.ui.*;
import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.pet.client.ui.home.node.assignment.child.*;
import fr.paladium.lib.apollon.nodes.buttons.utils.*;
import fr.paladium.lib.apollon.nodes.abstracts.*;
import java.util.*;

public class UIDebugAssignment extends UI
{
    private List<AssignmentClientData> assignments;
    
    public void func_73866_w_() {
        super.func_73866_w_();
        final double posX = this.width(40.0f);
        final double posY = this.height(1.0f);
        final double areaWidth = this.width(20.0f);
        final double areaHeight = this.height(98.0f);
        final double scrollAreaX = posX + areaWidth + this.width(0.5f);
        final ScrollArea scrollArea = new ScrollArea(scrollAreaX, posY, areaHeight, (double)this.width(0.8f), (double)this.height(20.83f));
        final MinecraftScrollableArea area = MinecraftScrollableArea.builder().bounds(posX, posY, posX + areaWidth, posY + areaHeight);
        int i = 0;
        for (final AssignmentClientData assignment : this.assignments) {
            final double flexNodeY = posY + this.height(0.5f) + i * this.height(16.0f);
            final double flexNodeX = posX + this.width(0.2f);
            final double flexNodeWidth = this.width(19.6f);
            final double flexNodeHeight = this.height(15.0f);
            final AssignmentNode node = new AssignmentNode(assignment, flexNodeX, flexNodeY, flexNodeWidth, flexNodeHeight);
            node.setArea((ScrollableArea)area);
            this.addNode((ANode)node);
            ++i;
        }
        area.setScrollArea(scrollArea);
        this.addScrollableArea((ScrollableArea)area);
    }
    
    public void preDraw(final int mouseX, final int mouseY, final float ticks) {
        super.preDraw(mouseX, mouseY, ticks);
        this.func_146276_q_();
    }
    
    public void postDraw(final int mouseX, final int mouseY, final float ticks) {
        super.postDraw(mouseX, mouseY, ticks);
    }
    
    public UIDebugAssignment(final List<AssignmentClientData> assignments) {
        this.assignments = assignments;
    }
}
