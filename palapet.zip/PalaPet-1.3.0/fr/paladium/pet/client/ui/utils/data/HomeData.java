//Decompiled by Procyon!

package fr.paladium.pet.client.ui.utils.data;

import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.server.skill.*;
import fr.paladium.pet.server.config.skill.*;
import fr.paladium.pet.common.network.data.additional.roll.*;
import fr.paladium.pet.server.skill.skill.*;
import fr.paladium.pet.common.network.data.additional.skill.*;
import net.minecraft.world.*;
import fr.paladium.pet.common.*;
import fr.paladium.pet.common.pet.*;
import fr.paladium.pet.common.provider.*;
import java.util.*;
import fr.paladium.pet.common.network.data.additional.assignment.*;
import fr.paladium.pet.server.config.assignment.*;

public class HomeData
{
    private final int level;
    private final int happiness;
    private final int maxHappiness;
    private int experience;
    private int maxExperience;
    private boolean visible;
    private final double happinessMultiplier;
    private final List<AssignmentClientData> assignments;
    private final List<SlotClientData> slots;
    private final List<SlotClientData> selectableSlots;
    private final List<SkinData> skins;
    private final List<SkillRollSlotData> skillRollSlots;
    private final SkinData currentSkin;
    private final boolean bypass;
    
    public HomeData(final EntityPlayerMP player, final PetPlayer pet) {
        this.level = pet.getLevel();
        this.maxHappiness = pet.getMaxHappiness();
        this.visible = pet.isVisible();
        this.assignments = this.initAssignments((EntityPlayer)player, pet);
        this.slots = this.initSlots(player, pet);
        this.selectableSlots = this.initSelectableSlots(player, pet);
        this.skillRollSlots = this.initSkillRollSlots(pet);
        this.happiness = Math.min(pet.getHappiness(), this.maxHappiness);
        this.happinessMultiplier = pet.getSkillMultiplier();
        this.currentSkin = this.initCurrentSkin(player.field_70170_p, pet);
        this.skins = this.initSkins((EntityPlayer)player, pet);
        this.bypass = SkillManager.getInstance().isBypassed((EntityPlayer)player);
        final double currentExperience = pet.getExperience();
        final double beforeLevelExperience = pet.getRequiredExperience(this.level - 1);
        final double nextLevelExperience = pet.getRequiredExperience(this.level);
        this.experience = (int)Math.floor(currentExperience - beforeLevelExperience);
        this.maxExperience = (int)Math.floor(nextLevelExperience - beforeLevelExperience);
        if (this.level == 100) {
            this.experience = 100;
            this.maxExperience = 100;
        }
    }
    
    public SkillRollSlotData findSkillRollData(final int slot) {
        for (final SkillRollSlotData data : this.skillRollSlots) {
            if (data.getSlot() == slot) {
                return data;
            }
        }
        return SkillRollSlotData.none(slot);
    }
    
    private List<SkillRollSlotData> initSkillRollSlots(final PetPlayer pet) {
        final SkillConfig config = SkillConfig.get();
        final long now = System.currentTimeMillis();
        final List<SkillRollData> rolls = pet.getSkillRollData().getRolls(pet);
        final List<SkillRollSlotData> skillRollSlots = new ArrayList<SkillRollSlotData>();
        for (final SkillRollData roll : rolls) {
            final int slot = roll.getSlot();
            final Optional<Skill> result = config.findSkillById(roll.getSkillId());
            if (!result.isPresent()) {
                continue;
            }
            final Skill skill = result.get();
            final SkillData skillData = pet.getSkill(slot);
            final boolean usageCooldown = skillData != null && skill.isOnCooldown(skill.getCooldown(now, skillData.getNextUseMillis()));
            skillRollSlots.add(SkillRollSlotData.from(slot, skill, usageCooldown));
        }
        return skillRollSlots;
    }
    
    private SkinData initCurrentSkin(final World world, final PetPlayer pet) {
        final PetAdditionalData skin = PetCommonProxy.getInstance().findPet(pet.getCurrentSkin());
        if (skin == null) {
            return SkinData.defaultData();
        }
        return new SkinData(skin.getName());
    }
    
    private List<SkinData> initSkins(final EntityPlayer player, final PetPlayer pet) {
        final List<SkinData> skins = new ArrayList<SkinData>();
        for (final String skin : PetSkinShopProvider.getInstance().getSkins(player, pet)) {
            final PetAdditionalData result = PetCommonProxy.getInstance().findPet(skin);
            if (result == null) {
                continue;
            }
            skins.add(new SkinData(result.getName()));
        }
        return skins;
    }
    
    private List<SlotClientData> initSelectableSlots(final EntityPlayerMP player, final PetPlayer pet) {
        final List<SlotClientData> slots = new ArrayList<SlotClientData>();
        final SkillConfig config = SkillConfig.get();
        final List<Skill> skills = new ArrayList<Skill>();
        final List<Skill> actives = new ArrayList<Skill>(config.getActiveSkills());
        final List<Skill> passives = new ArrayList<Skill>(config.getPassiveSkills());
        actives.sort(Comparator.comparing(skill -> skill.getName((EntityPlayer)player)));
        passives.sort(Comparator.comparing(skill -> skill.getName((EntityPlayer)player)));
        skills.addAll(actives);
        skills.addAll(passives);
        for (final Skill skill2 : skills) {
            if (!skill2.hasRequiredLevel(this.level)) {
                continue;
            }
            if (pet.isSkillSelected(skill2)) {
                continue;
            }
            slots.add(SlotClientData.from(-1, skill2, (EntityPlayer)player, pet, 0L));
        }
        return slots;
    }
    
    private List<SlotClientData> initSlots(final EntityPlayerMP player, final PetPlayer pet) {
        int index = 0;
        final long now = System.currentTimeMillis();
        final List<SlotClientData> slots = new ArrayList<SlotClientData>();
        final SkillConfig config = SkillConfig.get();
        for (final SkillData data : pet.getSkillData().getSkills().values()) {
            if (data.getSkillId().equals("no_skill")) {
                slots.add(SlotClientData.none((EntityPlayer)player, index));
            }
            else {
                final Optional<Skill> result = config.findSkillById(data.getSkillId());
                if (!result.isPresent()) {
                    slots.add(SlotClientData.none((EntityPlayer)player, index));
                }
                else {
                    final long nextChangeMillis = data.getChangeCooldown(player, now);
                    slots.add(SlotClientData.from(index, result.get(), (EntityPlayer)player, pet, nextChangeMillis));
                }
            }
            ++index;
        }
        while (index < 20) {
            slots.add(SlotClientData.locked((EntityPlayer)player, index, pet.getRequiredLevelForSlot(index)));
            ++index;
        }
        return slots;
    }
    
    private List<AssignmentClientData> initAssignments(final EntityPlayer player, final PetPlayer pet) {
        final List<AssignmentClientData> assignments = new ArrayList<AssignmentClientData>();
        final AssignmentConfig config = AssignmentConfig.get();
        for (final AssignmentData data : pet.getAssignmentData().getAssignments().values()) {
            final Optional<Assignment> result = config.findAssignmentById(data.getAssignmentId());
            if (!result.isPresent()) {
                continue;
            }
            assignments.add(AssignmentClientData.from(player, (Assignment)result.get(), data));
        }
        return assignments;
    }
    
    public int getLevel() {
        return this.level;
    }
    
    public int getHappiness() {
        return this.happiness;
    }
    
    public int getMaxHappiness() {
        return this.maxHappiness;
    }
    
    public int getExperience() {
        return this.experience;
    }
    
    public int getMaxExperience() {
        return this.maxExperience;
    }
    
    public boolean isVisible() {
        return this.visible;
    }
    
    public double getHappinessMultiplier() {
        return this.happinessMultiplier;
    }
    
    public List<AssignmentClientData> getAssignments() {
        return this.assignments;
    }
    
    public List<SlotClientData> getSlots() {
        return this.slots;
    }
    
    public List<SlotClientData> getSelectableSlots() {
        return this.selectableSlots;
    }
    
    public List<SkinData> getSkins() {
        return this.skins;
    }
    
    public List<SkillRollSlotData> getSkillRollSlots() {
        return this.skillRollSlots;
    }
    
    public SkinData getCurrentSkin() {
        return this.currentSkin;
    }
    
    public boolean isBypass() {
        return this.bypass;
    }
}
