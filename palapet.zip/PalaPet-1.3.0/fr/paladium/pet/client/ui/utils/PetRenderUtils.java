//Decompiled by Procyon!

package fr.paladium.pet.client.ui.utils;

import java.nio.*;
import net.minecraft.world.*;
import net.minecraft.client.*;
import fr.paladium.pet.common.entity.*;
import fr.paladium.pet.client.renderer.*;
import fr.paladium.lib.apollon.utils.*;
import net.minecraft.entity.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.*;

public class PetRenderUtils
{
    private static final FloatBuffer COLOR_BUFFER;
    
    public static EntityDummyPet getPetFromEnum(final String skin) {
        try {
            final EntityDummyPet pet = EntityDummyPet.class.getConstructor(World.class).newInstance(Minecraft.func_71410_x().field_71441_e);
            pet.setSkinId(skin);
            return pet;
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    public static EntityPetCage getCageFromEnum() {
        try {
            return EntityPetCage.class.getConstructor(World.class).newInstance(Minecraft.func_71410_x().field_71441_e);
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    public static void drawPetOnUI(final float x, final float y, final float scale, final float mouseX, final float mouseY, final EntityDummyPet entity, final float rotate) {
        if (entity == null) {
            return;
        }
        final Render render = RenderManager.field_78727_a.func_78713_a((Entity)entity);
        if (!(render instanceof PetGeoRenderer)) {
            return;
        }
        GuiUtils.renderEntity((double)x, (double)y, (double)scale, mouseX, mouseY, (EntityLivingBase)entity);
    }
    
    private static FloatBuffer setColorBuffer(final float red, final float green, final float blue, final float alpha) {
        PetRenderUtils.COLOR_BUFFER.clear();
        PetRenderUtils.COLOR_BUFFER.put(red).put(green).put(blue).put(alpha);
        PetRenderUtils.COLOR_BUFFER.flip();
        return PetRenderUtils.COLOR_BUFFER;
    }
    
    static {
        COLOR_BUFFER = GLAllocation.func_74529_h(16);
    }
}
