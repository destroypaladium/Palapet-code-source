//Decompiled by Procyon!

package fr.paladium.pet.client.ui.utils.data;

import fr.paladium.pet.common.*;

public class SkinData
{
    private final String skinId;
    
    public SkinData(final String pet) {
        this.skinId = pet;
    }
    
    public static SkinData defaultData() {
        final String pet = PetCommonProxy.DEFAULT_PETS.get(0);
        return new SkinData(pet);
    }
    
    public String getSkinId() {
        return this.skinId;
    }
}
