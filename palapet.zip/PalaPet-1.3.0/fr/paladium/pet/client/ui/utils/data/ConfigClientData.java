//Decompiled by Procyon!

package fr.paladium.pet.client.ui.utils.data;

import fr.paladium.pet.server.config.global.*;

public class ConfigClientData
{
    private static ConfigClientData DATA;
    private int experiencePerConnection;
    private int happinessLoss;
    
    public static ConfigClientData of(final GlobalConfig config) {
        return new ConfigClientData((int)config.getExperiencePerConnection(), config.getHappinessLoss());
    }
    
    public static void set(final ConfigClientData data) {
        ConfigClientData.DATA = data;
    }
    
    public static ConfigClientData get() {
        if (ConfigClientData.DATA == null) {
            ConfigClientData.DATA = new ConfigClientData(0, 0);
        }
        return ConfigClientData.DATA;
    }
    
    public int getExperiencePerConnection() {
        return this.experiencePerConnection;
    }
    
    public int getHappinessLoss() {
        return this.happinessLoss;
    }
    
    public ConfigClientData(final int experiencePerConnection, final int happinessLoss) {
        this.experiencePerConnection = experiencePerConnection;
        this.happinessLoss = happinessLoss;
    }
}
