//Decompiled by Procyon!

package fr.paladium.pet.client.ui.utils;

import net.minecraft.util.*;

public class PetUIUtils
{
    public static ResourceLocation getResourceFromTexturePath(final String path) {
        ResourceLocation resource = null;
        if (path == null) {
            return unknownResource();
        }
        if (path.contains(":")) {
            final String[] split = path.split(":");
            resource = new ResourceLocation(split[0], split[1]);
        }
        else {
            resource = new ResourceLocation(path);
        }
        return resource;
    }
    
    public static ResourceLocation getGeckoAnimationFileLocation(final String folder, final String modelName) {
        return new ResourceLocation("palapet", "animations/" + folder + "/" + modelName + ".animation.json");
    }
    
    public static ResourceLocation getAdditionalDataFileLocation(final String modelName) {
        return new ResourceLocation("palapet", "data/" + modelName + ".json");
    }
    
    public static ResourceLocation getGeckoModelLocation(final String folder, final String modelName) {
        return new ResourceLocation("palapet", "geo/" + folder + "/" + modelName + ".geo.json");
    }
    
    public static ResourceLocation getGeckoTextureLocation(final String folder, final String modelName) {
        return new ResourceLocation("palapet", "textures/" + folder + "/" + modelName + ".png");
    }
    
    public static ResourceLocation unknownResource() {
        return new ResourceLocation("palapet", "textures/ui/home/unknown_logo.png");
    }
}
