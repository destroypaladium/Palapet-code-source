//Decompiled by Procyon!

package fr.paladium.pet.client.ui.utils.data;

import net.minecraft.util.*;
import fr.paladium.pet.server.skill.skill.*;

public class SkillRollSlotData
{
    private int slot;
    private String skillId;
    private boolean usageCooldown;
    private ResourceLocation logo;
    
    public static SkillRollSlotData from(final int slot, final Skill skill, final boolean usageCooldown) {
        return new SkillRollSlotData(slot, skill.getId(), usageCooldown, new ResourceLocation("palapet:textures/ui/skill/" + skill.getIcon() + ".png"));
    }
    
    public static SkillRollSlotData none(final int slot) {
        return new SkillRollSlotData(slot, "", false, new ResourceLocation("palapet:textures/ui/home/unknown_logo.png"));
    }
    
    public int getSlot() {
        return this.slot;
    }
    
    public String getSkillId() {
        return this.skillId;
    }
    
    public boolean isUsageCooldown() {
        return this.usageCooldown;
    }
    
    public ResourceLocation getLogo() {
        return this.logo;
    }
    
    public void setSlot(final int slot) {
        this.slot = slot;
    }
    
    public void setSkillId(final String skillId) {
        this.skillId = skillId;
    }
    
    public void setUsageCooldown(final boolean usageCooldown) {
        this.usageCooldown = usageCooldown;
    }
    
    public void setLogo(final ResourceLocation logo) {
        this.logo = logo;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof SkillRollSlotData)) {
            return false;
        }
        final SkillRollSlotData other = (SkillRollSlotData)o;
        if (!other.canEqual(this)) {
            return false;
        }
        if (this.getSlot() != other.getSlot()) {
            return false;
        }
        if (this.isUsageCooldown() != other.isUsageCooldown()) {
            return false;
        }
        final Object this$skillId = this.getSkillId();
        final Object other$skillId = other.getSkillId();
        Label_0091: {
            if (this$skillId == null) {
                if (other$skillId == null) {
                    break Label_0091;
                }
            }
            else if (this$skillId.equals(other$skillId)) {
                break Label_0091;
            }
            return false;
        }
        final Object this$logo = this.getLogo();
        final Object other$logo = other.getLogo();
        if (this$logo == null) {
            if (other$logo == null) {
                return true;
            }
        }
        else if (this$logo.equals(other$logo)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof SkillRollSlotData;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        result = result * 59 + this.getSlot();
        result = result * 59 + (this.isUsageCooldown() ? 79 : 97);
        final Object $skillId = this.getSkillId();
        result = result * 59 + (($skillId == null) ? 43 : $skillId.hashCode());
        final Object $logo = this.getLogo();
        result = result * 59 + (($logo == null) ? 43 : $logo.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "SkillRollSlotData(slot=" + this.getSlot() + ", skillId=" + this.getSkillId() + ", usageCooldown=" + this.isUsageCooldown() + ", logo=" + this.getLogo() + ")";
    }
    
    public SkillRollSlotData(final int slot, final String skillId, final boolean usageCooldown, final ResourceLocation logo) {
        this.slot = slot;
        this.skillId = skillId;
        this.usageCooldown = usageCooldown;
        this.logo = logo;
    }
}
