//Decompiled by Procyon!

package fr.paladium.pet.client.ui.utils.data;

import net.minecraft.util.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.server.skill.skill.*;
import fr.paladium.pet.common.constant.*;
import fr.paladium.lib.apollon.utils.*;

public class SlotClientData
{
    private static final ResourceLocation UNKNOWN_LOGO;
    private static final ResourceLocation LOCKED_LOGO;
    private int slot;
    private int requiredLevel;
    private String id;
    private String name;
    private String description;
    private ResourceLocation logo;
    private long nextChangeMillis;
    private SkillColorInfo colorInfo;
    
    public static SlotClientData from(final int slot, final Skill skill, final EntityPlayer player, final PetPlayer pet, long nextChangeMillis) {
        final double value = skill.getPersonalValue(pet);
        SkillColorInfo color;
        if (nextChangeMillis > 0L) {
            color = ((skill.getType() == SkillType.PASSIVE) ? SkillColorInfo.COOLDOWN_PASSIVE : SkillColorInfo.COOLDOWN_ACTIVE);
        }
        else {
            color = ((skill.getType() == SkillType.PASSIVE) ? SkillColorInfo.PASSIVE : SkillColorInfo.ACTIVE);
        }
        if (nextChangeMillis < 0L) {
            nextChangeMillis = 0L;
        }
        nextChangeMillis += System.currentTimeMillis();
        return new SlotClientData(slot, skill.getRequiredLevel(), skill.getId(), skill.getName(player), skill.getFormattedDescription(player, skill.getPersonalValue(pet)), new ResourceLocation("palapet:textures/ui/skill/" + skill.getIcon() + ".png"), nextChangeMillis, color);
    }
    
    public static SlotClientData none(final EntityPlayer player, final int slot) {
        return new SlotClientData(slot, 0, "", PetTranslateEnum.GUI_SLOT_NOT_CONFIGURED.text(player), PetTranslateEnum.GUI_SLOT_CLICK_TO_SELECT.text(player), SlotClientData.UNKNOWN_LOGO, 0L, SkillColorInfo.NONE);
    }
    
    public static SlotClientData locked(final EntityPlayer player, final int slot, final int requiredLevel) {
        return new SlotClientData(slot, requiredLevel, "", PetTranslateEnum.GUI_SLOT_LOCKED.text(player), PetTranslateEnum.GUI_SLOT_LOCKED_LEVEL.text(player, requiredLevel), SlotClientData.LOCKED_LOGO, 0L, SkillColorInfo.LOCKED);
    }
    
    @Override
    public String toString() {
        return "SlotClientData(slot=" + this.getSlot() + ", requiredLevel=" + this.getRequiredLevel() + ", id=" + this.getId() + ", name=" + this.getName() + ", description=" + this.getDescription() + ", logo=" + this.getLogo() + ", nextChangeMillis=" + this.getNextChangeMillis() + ", colorInfo=" + this.getColorInfo() + ")";
    }
    
    public int getSlot() {
        return this.slot;
    }
    
    public int getRequiredLevel() {
        return this.requiredLevel;
    }
    
    public String getId() {
        return this.id;
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public ResourceLocation getLogo() {
        return this.logo;
    }
    
    public long getNextChangeMillis() {
        return this.nextChangeMillis;
    }
    
    public SkillColorInfo getColorInfo() {
        return this.colorInfo;
    }
    
    public SlotClientData(final int slot, final int requiredLevel, final String id, final String name, final String description, final ResourceLocation logo, final long nextChangeMillis, final SkillColorInfo colorInfo) {
        this.slot = slot;
        this.requiredLevel = requiredLevel;
        this.id = id;
        this.name = name;
        this.description = description;
        this.logo = logo;
        this.nextChangeMillis = nextChangeMillis;
        this.colorInfo = colorInfo;
    }
    
    static {
        UNKNOWN_LOGO = new ResourceLocation("palapet:textures/ui/home/unknown_logo.png");
        LOCKED_LOGO = new ResourceLocation("palapet:textures/ui/home/slot_locked.png");
    }
    
    public enum SkillColorInfo
    {
        PASSIVE(Color.decode("#2DC7FF"), Color.decode("#112E38")), 
        ACTIVE(Color.decode("#5ED42A"), Color.decode("#212A23")), 
        COOLDOWN_ACTIVE(Color.decode("#DF611A"), Color.decode("#2A221F")), 
        COOLDOWN_PASSIVE(SkillColorInfo.COOLDOWN_ACTIVE.borderColor, SkillColorInfo.COOLDOWN_ACTIVE.backgroundColor), 
        LOCKED(Color.decode("#FFFFFF"), new Color(68, 68, 68, 30)), 
        NONE(Color.decode("#FFFFFF"), new Color(68, 68, 68, 30));
        
        private final Color borderColor;
        private final Color backgroundColor;
        
        private SkillColorInfo(final Color borderColor, final Color backgroundColor) {
            this.borderColor = borderColor;
            this.backgroundColor = backgroundColor;
        }
        
        public boolean isActive() {
            return this == SkillColorInfo.ACTIVE || this == SkillColorInfo.COOLDOWN_ACTIVE;
        }
        
        public boolean isPassive() {
            return this == SkillColorInfo.PASSIVE || this == SkillColorInfo.COOLDOWN_PASSIVE;
        }
        
        public boolean isCooldown() {
            return this == SkillColorInfo.COOLDOWN_ACTIVE || this == SkillColorInfo.COOLDOWN_PASSIVE;
        }
        
        public Color getBorderColor() {
            return this.borderColor;
        }
        
        public Color getBackgroundColor() {
            return this.backgroundColor;
        }
    }
}
