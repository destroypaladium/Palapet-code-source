//Decompiled by Procyon!

package fr.paladium.pet.client.ui.utils.data;

import fr.paladium.pet.server.config.assignment.fields.*;
import net.minecraft.util.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.server.config.assignment.*;
import fr.paladium.pet.common.network.data.additional.assignment.*;
import fr.paladium.pet.client.ui.utils.*;

public class AssignmentClientData
{
    private final String name;
    private final String description;
    private final AssignmentType type;
    private final ResourceLocation logo;
    private final double progress;
    private final double maxProgress;
    
    public static AssignmentClientData from(final EntityPlayer player, final Assignment assignment, final AssignmentData data) {
        final ResourceLocation logo = PetUIUtils.getResourceFromTexturePath(assignment.getLogo());
        return new AssignmentClientData(assignment.getName(player), assignment.getDescription(player), assignment.getType(), logo, data.getProgress(), assignment.getAmount());
    }
    
    public boolean isFinish() {
        return this.progress >= this.maxProgress;
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public AssignmentType getType() {
        return this.type;
    }
    
    public ResourceLocation getLogo() {
        return this.logo;
    }
    
    public double getProgress() {
        return this.progress;
    }
    
    public double getMaxProgress() {
        return this.maxProgress;
    }
    
    public AssignmentClientData(final String name, final String description, final AssignmentType type, final ResourceLocation logo, final double progress, final double maxProgress) {
        this.name = name;
        this.description = description;
        this.type = type;
        this.logo = logo;
        this.progress = progress;
        this.maxProgress = maxProgress;
    }
}
