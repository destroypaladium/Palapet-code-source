//Decompiled by Procyon!

package fr.paladium.pet.client.listener;

import fr.paladium.pet.client.ui.skill.*;
import net.minecraftforge.client.event.*;
import net.minecraft.client.*;
import fr.paladium.pet.client.*;
import fr.paladium.pet.common.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import org.lwjgl.input.*;
import fr.paladium.pet.common.network.packet.skill.*;
import net.minecraft.client.settings.*;
import cpw.mods.fml.common.eventhandler.*;

public class SkillRollListener
{
    private final SkillSelector overlay;
    private boolean locked;
    
    public SkillRollListener() {
        this.locked = false;
        this.overlay = new SkillSelector();
    }
    
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onOverlay(final RenderGameOverlayEvent event) {
        if (event.type != RenderGameOverlayEvent.ElementType.HOTBAR) {
            return;
        }
        final Minecraft mc = Minecraft.func_71410_x();
        if (mc.field_71462_r != null) {
            if (this.locked) {
                this.locked = false;
                mc.func_71381_h();
            }
            return;
        }
        final KeyBinding binding = PetClientProxy.getInstance().getKeySkillRoll();
        if (binding.func_151470_d()) {
            if (!this.locked) {
                PetCommonProxy.getInstance().getNetwork().sendToServer((IMessage)new BBRequestSkillRollPacket());
                this.locked = true;
            }
            if (Mouse.isGrabbed()) {
                mc.field_71417_B.func_74373_b();
                mc.field_71415_G = false;
            }
            this.overlay.draw(event.mouseX, event.mouseY, event.partialTicks, event);
        }
        else if (this.locked) {
            for (int i = 0; i < this.overlay.getIsHover().size(); ++i) {
                final boolean isHover = this.overlay.getIsHover().get(i);
                if (isHover) {
                    PetCommonProxy.getInstance().getNetwork().sendToServer((IMessage)new CSActiveSpellPacket(i));
                    break;
                }
            }
            mc.func_71381_h();
            this.locked = false;
        }
    }
}
