//Decompiled by Procyon!

package fr.paladium.pet.client.listener;

import net.minecraftforge.event.entity.player.*;
import fr.paladium.pet.client.data.*;
import net.minecraft.init.*;
import net.minecraft.block.*;
import cpw.mods.fml.common.eventhandler.*;

public class ClientBreakSpeedListener
{
    public static ClientBreakSpeedListener INSTANCE;
    
    @SubscribeEvent
    public void onBreakSpeed(final PlayerEvent.BreakSpeed event) {
        final Block block = event.block;
        final long now = System.currentTimeMillis();
        final ClientBreakSpeedData data = ClientBreakSpeedData.get();
        if (block.equals(Blocks.field_150343_Z) && !data.isExpired(now, data.getObsidianExpirationMillis())) {
            event.newSpeed = event.originalSpeed * (float)data.getObsidianBreakSpeed();
            return;
        }
        if (!data.isExpired(now, data.getGlobalExpirationMillis())) {
            event.newSpeed = event.originalSpeed * (float)data.getGlobalBreakSpeed();
        }
    }
}
