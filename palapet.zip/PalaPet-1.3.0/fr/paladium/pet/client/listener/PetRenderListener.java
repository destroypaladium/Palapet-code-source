//Decompiled by Procyon!

package fr.paladium.pet.client.listener;

import cpw.mods.fml.relauncher.*;
import fr.paladium.pet.common.entity.*;
import net.minecraftforge.client.event.*;
import fr.paladium.common.*;
import net.minecraft.client.*;
import net.minecraft.potion.*;
import fr.paladium.pet.common.network.data.*;
import java.util.*;
import fr.paladium.pet.common.*;
import net.minecraft.world.*;
import fr.paladium.shop.client.utils.tick.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.pet.*;
import cpw.mods.fml.common.eventhandler.*;

@SideOnly(Side.CLIENT)
public class PetRenderListener
{
    public static HashMap<String, EntityDummyPet> cachedRenderer;
    private static final double MAX_WIDTH = 3.0;
    private static final double MAX_HEIGHT = 2.5;
    private static final double DEFAULT_SCALE = 0.6;
    
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onRenderPlayerSpecialPre(final RenderPlayerEvent.Specials.Pre event) {
        final EntityPlayer player = event.entityPlayer;
        if (CommonModule.getInstance().getCombatTag().inFight() && player != Minecraft.func_71410_x().field_71439_g) {
            return;
        }
        if (player.func_70644_a(Potion.field_76441_p)) {
            return;
        }
        final String username = player.func_70005_c_();
        final PetPlayer eep = PetPlayer.get(player);
        Label_0213: {
            if (eep.has() && eep.isVisible()) {
                if (PetRenderListener.cachedRenderer.containsKey(username)) {
                    if (PetRenderListener.cachedRenderer.get(username) != null) {
                        final EntityDummyPet pet = PetRenderListener.cachedRenderer.get(username);
                        if (!Objects.equals(pet.getSkinId(), eep.getCurrentSkin()) && !PetCommonProxy.APRIL_FOOL) {
                            PetRenderListener.cachedRenderer.put(username, null);
                        }
                        break Label_0213;
                    }
                }
                try {
                    final String skinId = eep.getCurrentSkin();
                    final EntityDummyPet pet2 = EntityDummyPet.class.getConstructor(World.class).newInstance(Minecraft.func_71410_x().field_71441_e);
                    pet2.setSkinId(skinId);
                    PetRenderListener.cachedRenderer.put(username, pet2);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
            else {
                PetRenderListener.cachedRenderer.put(username, null);
            }
        }
        if (PetRenderListener.cachedRenderer.containsKey(username)) {
            final EntityDummyPet entity = PetRenderListener.cachedRenderer.get(username);
            if (entity == null) {
                return;
            }
            if (entity.getSkinId().equals("none")) {
                return;
            }
            final PetAdditionalData data = PetCommonProxy.getInstance().findPet(entity.getSkinId());
            if (data == null) {
                return;
            }
            final ElementPosition scaleFactor = data.getScaleFactor();
            final ElementPosition shoulderPosition = data.getShoulderPosition();
            final double defaultX = shoulderPosition.getX();
            final double defaultY = shoulderPosition.getY();
            final double defaultZ = shoulderPosition.getZ();
            entity.field_70173_aa = ClientTicksData.TICKS;
            entity.field_70177_z = 0.0f;
            GL11.glPushMatrix();
            GL11.glScaled(scaleFactor.getX(), scaleFactor.getY(), scaleFactor.getZ());
            GL11.glRotated(180.0, 1.0, 0.0, 0.0);
            GL11.glTranslated(defaultX, defaultY, defaultZ);
            RenderManager.field_78727_a.func_147940_a((Entity)entity, 4.0, 1.0, 0.0, entity.field_70125_A, entity.field_70177_z + 58.5f);
            GL11.glPopMatrix();
        }
    }
    
    static {
        PetRenderListener.cachedRenderer = new HashMap<String, EntityDummyPet>();
    }
}
