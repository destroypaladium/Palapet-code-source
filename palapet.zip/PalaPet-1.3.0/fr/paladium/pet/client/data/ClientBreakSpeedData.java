//Decompiled by Procyon!

package fr.paladium.pet.client.data;

public class ClientBreakSpeedData
{
    public static final double DEFAULT_BREAK_SPEED = 1.0;
    public static ClientBreakSpeedData INSTANCE;
    private double obsidianBreakSpeed;
    private long obsidianExpirationMillis;
    private double globalBreakSpeed;
    private long globalExpirationMillis;
    
    public ClientBreakSpeedData() {
        ClientBreakSpeedData.INSTANCE = this;
        this.obsidianBreakSpeed = 1.0;
        this.obsidianExpirationMillis = 0L;
        this.globalBreakSpeed = 1.0;
        this.globalExpirationMillis = 0L;
    }
    
    public static ClientBreakSpeedData get() {
        if (ClientBreakSpeedData.INSTANCE == null) {
            ClientBreakSpeedData.INSTANCE = new ClientBreakSpeedData();
        }
        return ClientBreakSpeedData.INSTANCE;
    }
    
    public void updateObsidianBreakSpeed(final double value, final long duration) {
        this.obsidianBreakSpeed = value;
        this.obsidianExpirationMillis = System.currentTimeMillis() + duration;
    }
    
    public void updateGlobalBreakSpeed(final double value, final long duration) {
        this.globalBreakSpeed = value;
        this.globalExpirationMillis = System.currentTimeMillis() + duration;
    }
    
    public boolean isExpired(final long now, final long expirationMillis) {
        return System.currentTimeMillis() >= expirationMillis;
    }
    
    public double getObsidianBreakSpeed() {
        return this.obsidianBreakSpeed;
    }
    
    public long getObsidianExpirationMillis() {
        return this.obsidianExpirationMillis;
    }
    
    public double getGlobalBreakSpeed() {
        return this.globalBreakSpeed;
    }
    
    public long getGlobalExpirationMillis() {
        return this.globalExpirationMillis;
    }
}
