//Decompiled by Procyon!

package fr.paladium.pet.client.renderer;

import software.bernie.geckolib3.renderers.geo.*;
import fr.paladium.pet.common.entity.*;
import net.minecraft.client.renderer.entity.*;
import fr.paladium.pet.client.models.entities.*;
import software.bernie.geckolib3.model.*;
import software.bernie.geckolib3.geo.render.built.*;
import net.minecraft.entity.*;

public class PetGeoRenderer extends GeoEntityRenderer<EntityDummyPet>
{
    public PetGeoRenderer() {
        super(RenderManager.field_78727_a, (AnimatedGeoModel)new PetModel());
    }
    
    public void render(final GeoModel geo, final Entity entity, final float ticks, final float red, final float green, final float blue, final float alpha) {
        super.render(geo, entity, ticks, red, green, blue, alpha);
    }
}
