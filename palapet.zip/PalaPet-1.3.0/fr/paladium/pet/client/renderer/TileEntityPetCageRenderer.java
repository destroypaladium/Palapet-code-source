//Decompiled by Procyon!

package fr.paladium.pet.client.renderer;

import net.minecraft.client.renderer.tileentity.*;
import java.util.*;
import net.minecraft.tileentity.*;
import net.minecraft.client.*;
import fr.paladium.pet.common.tile.cage.*;
import fr.paladium.shop.client.utils.tick.*;
import fr.paladium.pet.client.renderer.data.*;
import net.minecraft.client.entity.*;
import fr.paladium.pet.common.entity.*;
import net.minecraft.entity.item.*;
import fr.paladium.pet.common.network.packet.capture.*;
import fr.paladium.pet.common.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import fr.paladium.pet.common.registry.impl.*;
import net.minecraft.item.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.entity.*;

public class TileEntityPetCageRenderer extends TileEntitySpecialRenderer
{
    public static final HashMap<IntLocation, CageRenderData> DATAS;
    public static final int CLEAR_CACHE_DISTANCE = 100;
    
    public void func_147500_a(final TileEntity tile, final double x, final double y, final double z, final float ticks) {
        final Minecraft mc = Minecraft.func_71410_x();
        final EntityPlayerSP player = (EntityPlayerSP)mc.field_71439_g;
        if (!(tile instanceof TileEntityPetCage)) {
            return;
        }
        final int metadata = tile.field_145847_g;
        final TileEntityPetCage cage = (TileEntityPetCage)tile;
        final IntLocation location = new IntLocation((double)tile.field_145851_c, (double)tile.field_145848_d, (double)tile.field_145849_e);
        final CageRenderData data = this.get(cage, location);
        if (data == null) {
            return;
        }
        final CageRenderState state = data.getState();
        final EntityDummyPet entityPet = data.getEntityPet();
        final EntityPetCage entityCage = data.getEntityCage();
        final EntityItem entityBait = data.getItemBait();
        entityPet.field_70173_aa = ClientTicksData.TICKS;
        entityCage.field_70173_aa = ClientTicksData.TICKS;
        entityBait.field_70173_aa = ClientTicksData.TICKS;
        if (data.requestUpdate(System.currentTimeMillis())) {
            this.requestUpdate(cage, location);
        }
        this.renderCageInto((float)(x + 0.5), (float)y, (float)(z + 0.5), metadata, entityCage);
        if (state == CageRenderState.PET) {
            this.renderPetInto((float)(x + 0.5), (float)(y + 0.20000000298023224), (float)(z + 0.5), entityPet);
        }
        if (state == CageRenderState.FOOD) {
            this.renderItemStackInto((float)(x + 0.5), (float)(y + 0.20000000298023224), (float)(z + 0.5), entityBait);
        }
    }
    
    private CageRenderData get(final TileEntityPetCage cage, final IntLocation location) {
        if (!TileEntityPetCageRenderer.DATAS.containsKey(location)) {
            TileEntityPetCageRenderer.DATAS.put(location, CageRenderData.of(cage));
            this.requestUpdate(cage, location);
        }
        return TileEntityPetCageRenderer.DATAS.get(location);
    }
    
    public void requestUpdate(final TileEntityPetCage cage, final IntLocation location) {
        final BBPacketRequestCageData packet = new BBPacketRequestCageData(location);
        PetCommonProxy.getInstance().getNetwork().sendToServer((IMessage)packet);
    }
    
    private void renderItemStackInto(final float x, final float y, final float z, final EntityItem item) {
        item.func_92058_a(new ItemStack((Item)PetItemRegistry.BAIT));
        final float scale = 1.0f;
        GL11.glPushMatrix();
        GL11.glTranslatef(x, y, z);
        GL11.glScalef(scale, scale, scale);
        GL11.glRotatef(-RenderManager.field_78727_a.field_78735_i, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
        RenderManager.field_78727_a.func_147940_a((Entity)item, 0.0, 0.0, 0.0, 0.0f, 0.0f);
        GL11.glPopMatrix();
    }
    
    public void renderCageInto(final float x, final float y, final float z, final int metadata, final EntityPetCage cage) {
        final float scale = 0.85f;
        GL11.glPushMatrix();
        GL11.glScaled((double)scale, (double)scale, (double)scale);
        GL11.glTranslated((double)(x / scale), (double)(y / scale), (double)(z / scale));
        GL11.glRotatef(getRotation(metadata), 0.0f, 1.0f, 0.0f);
        RenderManager.field_78727_a.func_147940_a((Entity)cage, 0.0, 0.0, 0.0, 0.0f, 0.0f);
        GL11.glPopMatrix();
    }
    
    private void renderPetInto(final float x, final float y, final float z, final EntityDummyPet pet) {
        final float scale = 0.4f;
        GL11.glPushMatrix();
        GL11.glScaled((double)scale, (double)scale, (double)scale);
        GL11.glTranslated((double)(x / scale), (double)(y / scale), (double)(z / scale));
        GL11.glRotatef(-RenderManager.field_78727_a.field_78735_i, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
        RenderManager.field_78727_a.func_147940_a((Entity)pet, 0.0, 0.0, 0.0, 0.0f, 0.0f);
        GL11.glPopMatrix();
    }
    
    public static float getRotation(final int metadata) {
        switch (metadata) {
            case 2: {
                return 180.0f;
            }
            case 3: {
                return 0.0f;
            }
            case 4: {
                return 270.0f;
            }
            case 5: {
                return 90.0f;
            }
            default: {
                return 180.0f;
            }
        }
    }
    
    static {
        DATAS = new HashMap<IntLocation, CageRenderData>();
    }
}
