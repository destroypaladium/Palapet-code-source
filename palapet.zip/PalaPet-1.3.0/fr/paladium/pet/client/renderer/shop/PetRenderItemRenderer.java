//Decompiled by Procyon!

package fr.paladium.pet.client.renderer.shop;

import fr.paladium.shop.common.provider.render.*;
import net.minecraft.util.*;
import fr.paladium.shop.client.ui.home.utils.*;
import fr.paladium.shop.client.utils.entity.*;
import fr.paladium.lib.apollon.ui.*;
import fr.paladium.lib.apollon.nodes.abstracts.*;
import net.minecraft.client.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.lib.apollon.ui.event.subscriber.*;
import fr.paladium.lib.apollon.ui.event.event.*;
import fr.paladium.lib.apollon.nodes.event.subscriber.*;
import fr.paladium.lib.apollon.nodes.event.event.*;
import net.minecraftforge.common.*;
import fr.paladium.shop.client.utils.constant.*;
import fr.paladium.lib.apollon.utils.*;
import org.lwjgl.opengl.*;
import net.minecraft.entity.*;

@ShopItemRenderType({ ShopItemRenderType.Type.RENDER })
public class PetRenderItemRenderer extends ShopItemRenderer
{
    private static final ResourceLocation SKIN_TEXTURE;
    private ShopItemRenderData data;
    private boolean loaded;
    private boolean render;
    private FakeEntityPlayerMP fakePlayer;
    private float yaw;
    private float pitch;
    private float targetYaw;
    private float targetPitch;
    private float zoom;
    private float targetZoom;
    private boolean dragged;
    private int draggedMouseX;
    private int draggedMouseY;
    
    public PetRenderItemRenderer() {
        super(true);
    }
    
    public void initPage(final UI ui, final ShopItemRenderData data) {
    }
    
    public void init(final ANode node, final ShopItemRenderData data) {
        this.data = data;
        final String skinId = this.data.getData().id;
        this.fakePlayer = new FakeEntityPlayerMP(Minecraft.func_71410_x().field_71439_g.field_70170_p);
        if (this.fakePlayer.getExtendedProperties("palapet_PetPlayer") == null) {
            this.fakePlayer.registerExtendedProperties("palapet_PetPlayer", (IExtendedEntityProperties)new PetPlayer());
        }
        this.fakePlayer.setCustomSkin(PetRenderItemRenderer.SKIN_TEXTURE);
        final PetPlayer eep = PetPlayer.get((EntityPlayer)this.fakePlayer);
        eep.setCurrentSkin(skinId);
        eep.setUnlockedSkin(skinId);
        final float n = 1.0f;
        this.targetZoom = n;
        this.zoom = n;
        final float n2 = -45.0f;
        this.targetYaw = n2;
        this.yaw = n2;
        final float n3 = 15.0f;
        this.targetPitch = n3;
        this.pitch = n3;
        final UI nodeUI = (UI)node.ui;
        final UIBridgeSubscriber uiEvent = new UIBridgeSubscriber(nodeUI) {
            public void onScroll(final UIScrollEvent e) {
                PetRenderItemRenderer.this.zoom(e.getValue() / 3000.0f);
            }
        };
        final NodeBridgeSubscriber nodeEvent = new NodeBridgeSubscriber(node) {
            public void onClick(final NodeClickEvent e) {
                if (!node.isHovered(e.getMouseX(), e.getMouseY())) {
                    return;
                }
                PetRenderItemRenderer.this.dragged = true;
                PetRenderItemRenderer.this.draggedMouseX = e.getMouseX();
                PetRenderItemRenderer.this.draggedMouseY = e.getMouseY();
            }
            
            public void onRelease(final NodeReleaseEvent e) {
                if (!PetRenderItemRenderer.this.dragged) {
                    return;
                }
                PetRenderItemRenderer.this.dragged = false;
            }
        };
        MinecraftForge.EVENT_BUS.register((Object)uiEvent);
        MinecraftForge.EVENT_BUS.register((Object)nodeEvent);
        nodeUI.eventSubscriberList.add(uiEvent);
        node.eventSubscriberList.add(nodeEvent);
    }
    
    public boolean draw(final ANode node, final int mouseX, final int mouseY) {
        if (!this.loaded) {
            this.loaded = true;
            this.render = true;
        }
        GuiUtils.drawImageTransparent(node.x + node.width(85.0f), node.y + node.height(5.0f), (ResourceLocation)RarityConstants.ICONS.get(this.data.getData().rarity), (double)node.width(10.0f), (double)node.height(10.0f));
        if (this.render) {
            GuiUtils.drawStringWithCustomFont(Minecraft.func_71410_x(), "3D", node.x + node.width(4.5f), node.y + node.height(4.0f), Color.WHITE, Fonts.MINECRAFT_DUNGEONS_REGULAR.getFont(), 50);
            if (this.dragged) {
                this.targetYaw += (mouseX - this.draggedMouseX) / 5.0f;
                this.draggedMouseX = mouseX;
                this.targetPitch += (mouseY - this.draggedMouseY) / 5.0f;
                this.draggedMouseY = mouseY;
                this.targetPitch = Math.min(30.0f, this.targetPitch);
                this.targetPitch = Math.max(-30.0f, this.targetPitch);
            }
            if (this.yaw != this.targetYaw) {
                this.yaw = (float)this.smoothLocalValue(this.yaw, this.targetYaw, 0.1, 0.1, true);
            }
            if (this.pitch != this.targetPitch) {
                this.pitch = (float)this.smoothLocalValue(this.pitch, this.targetPitch, 0.1, 0.1, true);
            }
            if (this.zoom != this.targetZoom) {
                this.zoom = (float)this.smoothLocalValue(this.zoom, this.targetZoom, 0.1, 0.0, true);
            }
            GL11.glPushMatrix();
            GL11.glEnable(3089);
            GuiUtils.scissor(Minecraft.func_71410_x(), node.x + node.width(3.0f), node.y + node.height(3.0f), (double)node.width(94.0f), (double)node.height(94.0f));
            GuiUtils.renderEntity(node.x + node.width(50.0f), node.y + node.height(88.5f) + node.height(40.0f * (this.zoom - 1.0f)) + node.height((float)Float.valueOf(this.data.getData().getRenderData("renderOffset", "0"))), (double)node.width(40.0f * this.zoom), this.yaw, this.pitch, (EntityLivingBase)this.fakePlayer, 500);
            GL11.glDisable(3089);
            GL11.glPopMatrix();
        }
        if (!this.render) {
            final Color color = new Color(Color.WHITE.getRGB());
            final long now = System.currentTimeMillis();
            color.a = (float)((Math.sin(6.283185307179586 * (now % 3000L) / 1500.0) + 1.0) / 2.0) + 0.3f;
            GuiUtils.drawCenteredStringWithCustomFont(Minecraft.func_71410_x(), "chargement" + ((now % 1333L < 333L) ? "" : ((now % 1333L < 666L) ? "." : ((now % 1333L < 999L) ? ".." : "..."))), node.x + node.width(50.0f), node.y + node.height(48.0f), color, Fonts.MONTSERRAT_BOLD.getFont(), 150);
        }
        return !this.render;
    }
    
    private double smoothLocalValue(double value, final double target, final double speed, final double snapDiff, final boolean snap) {
        final int fps = Integer.parseInt(Minecraft.func_71410_x().field_71426_K.split(" fps")[0]);
        final double diff = target - value;
        final double absDiff = Math.abs(diff);
        final double offset = speed / (((fps == 0) ? 1 : fps) / 60.0f) * absDiff / 3.0;
        if (absDiff > snapDiff) {
            value += ((diff > 0.0) ? offset : (-offset));
        }
        else if (snap) {
            value = target;
        }
        return value;
    }
    
    public void zoom(final float delta) {
        this.targetZoom += delta;
        this.targetZoom = Math.max(0.5f, Math.min(this.targetZoom, 1.5f));
    }
    
    static {
        SKIN_TEXTURE = new ResourceLocation("shop", "textures/skin/template.png");
    }
}
