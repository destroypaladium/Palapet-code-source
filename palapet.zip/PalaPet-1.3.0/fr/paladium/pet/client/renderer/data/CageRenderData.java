//Decompiled by Procyon!

package fr.paladium.pet.client.renderer.data;

import fr.paladium.pet.common.entity.*;
import net.minecraft.entity.item.*;
import fr.paladium.pet.common.tile.cage.*;
import fr.paladium.pet.client.ui.utils.*;

public class CageRenderData
{
    private static final long REQUEST_DELAY = 500L;
    private IntLocation location;
    private EntityPetCage entityCage;
    private EntityDummyPet entityPet;
    private EntityItem itemBait;
    private CageRenderState state;
    private long lastRequestMillis;
    
    public boolean requestUpdate(final long now) {
        if (now - this.lastRequestMillis < 500L) {
            return false;
        }
        this.lastRequestMillis = now;
        return true;
    }
    
    public static CageRenderData of(final TileEntityPetCage cage) {
        if (cage.getPet() == null) {
            return null;
        }
        return new CageRenderData(IntLocation.of(cage.field_145851_c, cage.field_145848_d, cage.field_145849_e), PetRenderUtils.getCageFromEnum(), PetRenderUtils.getPetFromEnum(cage.getPet()), new EntityItem(cage.func_145831_w()), CageRenderState.of(cage.getStatus()), System.currentTimeMillis());
    }
    
    public void setLocation(final IntLocation location) {
        this.location = location;
    }
    
    public void setEntityCage(final EntityPetCage entityCage) {
        this.entityCage = entityCage;
    }
    
    public void setEntityPet(final EntityDummyPet entityPet) {
        this.entityPet = entityPet;
    }
    
    public void setItemBait(final EntityItem itemBait) {
        this.itemBait = itemBait;
    }
    
    public void setState(final CageRenderState state) {
        this.state = state;
    }
    
    public void setLastRequestMillis(final long lastRequestMillis) {
        this.lastRequestMillis = lastRequestMillis;
    }
    
    public IntLocation getLocation() {
        return this.location;
    }
    
    public EntityPetCage getEntityCage() {
        return this.entityCage;
    }
    
    public EntityDummyPet getEntityPet() {
        return this.entityPet;
    }
    
    public EntityItem getItemBait() {
        return this.itemBait;
    }
    
    public CageRenderState getState() {
        return this.state;
    }
    
    public long getLastRequestMillis() {
        return this.lastRequestMillis;
    }
    
    public CageRenderData(final IntLocation location, final EntityPetCage entityCage, final EntityDummyPet entityPet, final EntityItem itemBait, final CageRenderState state, final long lastRequestMillis) {
        this.location = location;
        this.entityCage = entityCage;
        this.entityPet = entityPet;
        this.itemBait = itemBait;
        this.state = state;
        this.lastRequestMillis = lastRequestMillis;
    }
}
