//Decompiled by Procyon!

package fr.paladium.pet.client.renderer.data;

import java.util.*;

public class IntLocation
{
    private final int x;
    private final int y;
    private final int z;
    
    public IntLocation(final double x, final double y, final double z) {
        this.x = (int)Math.floor(x);
        this.y = (int)Math.floor(y);
        this.z = (int)Math.floor(z);
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (!(obj instanceof IntLocation)) {
            return false;
        }
        final IntLocation other = (IntLocation)obj;
        return other.x == this.x && other.y == this.y && other.z == this.z;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.x, this.y, this.z);
    }
    
    public int distance(final double x, final double y, final double z) {
        return this.distance(new IntLocation(x, y, z));
    }
    
    public int distance(final IntLocation other) {
        return (int)Math.sqrt(Math.pow(other.x - this.x, 2.0) + Math.pow(other.y - this.y, 2.0) + Math.pow(other.z - this.z, 2.0));
    }
    
    public static IntLocation of(final double x, final double y, final double z) {
        return new IntLocation(x, y, z);
    }
    
    @Override
    public String toString() {
        return "IntLocation(x=" + this.getX() + ", y=" + this.getY() + ", z=" + this.getZ() + ")";
    }
    
    public int getX() {
        return this.x;
    }
    
    public int getY() {
        return this.y;
    }
    
    public int getZ() {
        return this.z;
    }
}
