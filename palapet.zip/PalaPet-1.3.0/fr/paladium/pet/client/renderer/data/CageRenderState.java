//Decompiled by Procyon!

package fr.paladium.pet.client.renderer.data;

import fr.paladium.pet.common.tile.cage.*;

public enum CageRenderState
{
    IDLE, 
    FOOD, 
    PET;
    
    public static CageRenderState of(final CageStatus status) {
        switch (status) {
            case UNFILLED: {
                return CageRenderState.IDLE;
            }
            case FILLED: {
                return CageRenderState.FOOD;
            }
            default: {
                return CageRenderState.PET;
            }
        }
    }
}
