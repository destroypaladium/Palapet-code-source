//Decompiled by Procyon!

package fr.paladium.pet.client.renderer;

import cpw.mods.fml.client.registry.*;
import net.minecraft.block.*;
import net.minecraft.client.renderer.*;
import fr.paladium.pet.common.registry.impl.*;
import fr.paladium.pet.client.ui.utils.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.entity.*;
import fr.paladium.pet.common.entity.*;
import net.minecraft.world.*;
import fr.paladium.pet.client.*;

public class PetCageRenderInventory implements ISimpleBlockRenderingHandler
{
    public void renderInventoryBlock(final Block block, final int meta, final int modelId, final RenderBlocks renderer) {
        if (block == PetBlockRegistry.PET_CAGE) {
            final EntityPetCage cage = PetRenderUtils.getCageFromEnum();
            if (cage == null) {
                return;
            }
            GL11.glPushMatrix();
            GL11.glTranslatef(0.0f, -0.55f, 0.0f);
            RenderManager.field_78727_a.func_147940_a((Entity)cage, 0.0, 0.0, 0.0, 0.0f, 0.0f);
            GL11.glPopMatrix();
        }
    }
    
    public boolean renderWorldBlock(final IBlockAccess world, final int x, final int y, final int z, final Block block, final int modelId, final RenderBlocks renderer) {
        return false;
    }
    
    public boolean shouldRender3DInInventory(final int modelId) {
        return true;
    }
    
    public int getRenderId() {
        return PetClientProxy.cageRenderId;
    }
}
