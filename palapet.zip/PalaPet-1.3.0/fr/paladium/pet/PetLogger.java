//Decompiled by Procyon!

package fr.paladium.pet;

import java.util.logging.*;

public class PetLogger
{
    public static final Logger LOGGER;
    private static final String PREFIX = "[Pet] ";
    
    public static void warn(final String message) {
        PetLogger.LOGGER.log(Level.WARNING, "[Pet] " + message);
    }
    
    public static void info(final String message) {
        PetLogger.LOGGER.log(Level.INFO, "[Pet] " + message);
    }
    
    public static void error(final String message) {
        PetLogger.LOGGER.log(Level.SEVERE, "[Pet] " + message);
    }
    
    static {
        (LOGGER = Logger.getLogger("pet")).setLevel(Level.ALL);
    }
}
