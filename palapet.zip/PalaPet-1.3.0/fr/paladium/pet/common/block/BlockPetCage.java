//Decompiled by Procyon!

package fr.paladium.pet.common.block;

import net.minecraft.block.*;
import net.minecraft.block.material.*;
import fr.paladium.pet.client.tab.*;
import net.minecraft.creativetab.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.item.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.command.*;
import fr.paladium.pet.common.tile.cage.*;
import fr.paladium.pet.common.*;
import fr.paladium.pet.common.network.packet.capture.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import fr.paladium.pet.common.registry.impl.*;
import fr.paladium.pet.common.utils.*;
import net.minecraft.tileentity.*;
import fr.paladium.pet.client.*;
import cpw.mods.fml.relauncher.*;
import net.minecraft.entity.*;
import net.minecraft.util.*;

public class BlockPetCage extends Block implements ITileEntityProvider
{
    public static final String NAME = "pet_cage";
    
    public BlockPetCage() {
        super(Material.field_151576_e);
        this.func_149647_a((CreativeTabs)TabPet.INSTANCE);
        this.func_149663_c("pet_cage");
        this.func_149658_d("palapet:cage");
        this.func_149711_c(0.6f);
    }
    
    public boolean func_149727_a(final World world, final int x, final int y, final int z, final EntityPlayer globalPlayer, final int side, final float hitX, final float hitY, final float hitZ) {
        if (world.field_72995_K) {
            return true;
        }
        final TileEntityPetCage cage = this.getCage(world, x, y, z);
        final long now = System.currentTimeMillis();
        final EntityPlayerMP player = (EntityPlayerMP)globalPlayer;
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        if (!PetUtils.canUseCraft((EntityPlayer)player, new ItemStack((Block)this))) {
            PetTranslateEnum.MESSAGE_NOT_OWNER.message((ICommandSender)player);
            return false;
        }
        if (cage == null || pet == null || pet.has()) {
            PetTranslateEnum.MESSAGE_ALREADY_HAS_FAMILIAR.message((ICommandSender)player);
            return false;
        }
        if (!cage.isOwner(player)) {
            PetTranslateEnum.MESSAGE_NOT_OWNER.message((ICommandSender)player);
            return false;
        }
        if (CageStatus.isPlaying(cage.getStatus())) {
            if (cage.canPlayNextStep(player, now)) {
                this.openUI(player, cage);
            }
            return true;
        }
        if (cage.isFilled()) {
            PetTranslateEnum.MESSAGE_WAITING_FOR_FAMILIAR.message((ICommandSender)player);
            return true;
        }
        if (cage.isFilled()) {
            return true;
        }
        if (this.fill(player, cage)) {
            PetTranslateEnum.MESSAGE_WAITING_FOR_FAMILIAR.message((ICommandSender)player);
            return true;
        }
        PetTranslateEnum.MESSAGE_CAGE_NOT_FILLED.message((ICommandSender)player);
        return true;
    }
    
    public void openUI(final EntityPlayerMP player, final TileEntityPetCage cage) {
        PetCommonProxy.getInstance().getNetwork().sendTo((IMessage)new SCPacketTrapOpen(cage.getStatus(), cage.field_145851_c, cage.field_145848_d, cage.field_145849_e), player);
    }
    
    public void handlePacket(final EntityPlayerMP player, final int score, final World world, final int x, final int y, final int z) {
        final TileEntityPetCage cage = this.getCage(world, x, y, z);
        if (cage == null) {
            return;
        }
        if (!cage.isOwner(player)) {
            return;
        }
        if (!CageStatus.isPlaying(cage.getStatus())) {
            return;
        }
        cage.updateScore(player, score);
    }
    
    private boolean fill(final EntityPlayerMP player, final TileEntityPetCage cage) {
        final ItemStack hand = player.func_70694_bm();
        if (hand == null || !hand.func_77973_b().equals(PetItemRegistry.BAIT)) {
            return false;
        }
        cage.fill(player);
        ItemUtils.decrementCurrentItem((EntityPlayer)player, hand);
        return true;
    }
    
    private TileEntityPetCage getCage(final World world, final int x, final int y, final int z) {
        final TileEntity tileEntity = world.func_147438_o(x, y, z);
        if (!(tileEntity instanceof TileEntityPetCage)) {
            return null;
        }
        return (TileEntityPetCage)tileEntity;
    }
    
    public TileEntity func_149915_a(final World world, final int meta) {
        return new TileEntityPetCage();
    }
    
    public boolean hasTileEntity(final int metadata) {
        return true;
    }
    
    @SideOnly(Side.CLIENT)
    public int func_149645_b() {
        return PetClientProxy.cageRenderId;
    }
    
    public boolean func_149686_d() {
        return false;
    }
    
    public boolean func_149662_c() {
        return false;
    }
    
    public void func_149726_b(final World world, final int x, final int y, final int z) {
        super.func_149726_b(world, x, y, z);
        this.setDefaultDirection(world, x, y, z);
    }
    
    public void func_149689_a(final World world, final int x, final int y, final int z, final EntityLivingBase entity, final ItemStack stack) {
        super.func_149689_a(world, x, y, z, entity, stack);
        this.onBlockPlacedBy(world, x, y, z, entity);
    }
    
    public void onBlockPlacedBy(final World world, final int x, final int y, final int z, final EntityLivingBase entity) {
        final int l = MathHelper.func_76128_c(entity.field_70177_z * 4.0f / 360.0f + 0.5) & 0x3;
        if (l == 0) {
            world.func_72921_c(x, y, z, 2, 2);
        }
        if (l == 1) {
            world.func_72921_c(x, y, z, 5, 2);
        }
        if (l == 2) {
            world.func_72921_c(x, y, z, 3, 2);
        }
        if (l == 3) {
            world.func_72921_c(x, y, z, 4, 2);
        }
    }
    
    public void setDefaultDirection(final World world, final int x, final int y, final int z) {
        if (!world.field_72995_K) {
            final Block block = world.func_147439_a(x, y, z - 1);
            final Block block2 = world.func_147439_a(x, y, z + 1);
            final Block block3 = world.func_147439_a(x - 1, y, z);
            final Block block4 = world.func_147439_a(x + 1, y, z);
            byte b0 = 3;
            if (block.func_149730_j() && !block2.func_149730_j()) {
                b0 = 3;
            }
            if (block2.func_149730_j() && !block.func_149730_j()) {
                b0 = 2;
            }
            if (block3.func_149730_j() && !block4.func_149730_j()) {
                b0 = 5;
            }
            if (block4.func_149730_j() && !block3.func_149730_j()) {
                b0 = 4;
            }
            world.func_72921_c(x, y, z, (int)b0, 2);
        }
    }
}
