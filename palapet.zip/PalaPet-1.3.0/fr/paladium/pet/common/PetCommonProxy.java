//Decompiled by Procyon!

package fr.paladium.pet.common;

import fr.paladium.palaforgeutils.lib.proxy.*;
import fr.paladium.pet.common.capture.*;
import fr.paladium.pet.common.pet.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.palaforgeutils.lib.extended.*;
import cpw.mods.fml.common.network.*;
import fr.paladium.pet.common.handler.*;
import fr.paladium.palaforgeutils.lib.guihandler.*;
import fr.paladium.palaforgeutils.lib.packet.*;
import fr.paladium.pet.common.network.packet.skill.breakspeed.*;
import fr.paladium.pet.common.network.packet.skill.*;
import fr.paladium.pet.common.network.packet.capture.*;
import fr.paladium.pet.common.network.packet.pet.*;
import fr.paladium.pet.common.skill.listener.passive.*;
import fr.paladium.pet.*;
import fr.paladium.palaforgeutils.lib.registry.*;
import java.awt.*;
import fr.paladium.pet.common.entity.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import cpw.mods.fml.common.event.*;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import fr.paladium.pet.common.registry.*;
import java.util.*;

public abstract class PetCommonProxy extends AModProxy
{
    public static final List<String> DEFAULT_PETS;
    public static final boolean APRIL_FOOL;
    private static final String GEO_FOLDER = "/assets/palapet/geo/pets/";
    private static final String GEO_EXTENSION = ".geo.json";
    public static final String ADDITIONAL_DATA_FOLDER = "/assets/palapet/data/";
    public static final String ADDITIONAL_DATA_EXTENSION = ".json";
    private static PetCommonProxy instance;
    private final RegistryManager registryManager;
    private final CaptureManager captureManager;
    private CustomGuiHandler guiHandler;
    private int feedPetHandler;
    private final List<PetAdditionalData> pets;
    
    public PetCommonProxy() {
        this.pets = Arrays.asList(PetAdditionalData.of("kapio_koi"), PetAdditionalData.of("cat"), PetAdditionalData.of("rabbit"), PetAdditionalData.of("dog"), PetAdditionalData.of("dragon"), PetAdditionalData.of("feng_uang"), PetAdditionalData.of("pet_mini_golem"), PetAdditionalData.of("pet_ufo"), PetAdditionalData.of("pet_blobfish"));
        PetCommonProxy.instance = this;
        this.registryManager = RegistryManager.getInstance();
        this.captureManager = new CaptureManager();
    }
    
    public void onPreInit(final FMLPreInitializationEvent event) {
        super.onPreInit(event);
        this.registryManager.getRegistries().forEach(registry -> registry.onPreInit(event));
        ExtendedUtils.registerExtended((Class)EntityPlayer.class, (Class)PetPlayer.class, "palapet_PetPlayer", new ExtendedProperty[] { ExtendedProperty.SELF_CONSTRUCT, ExtendedProperty.PERSISTANT, ExtendedProperty.SYNCHRONIZED, ExtendedProperty.SYNCHRONIZED_TRACKER });
        NetworkRegistry.INSTANCE.registerGuiHandler((Object)"palapet", (IGuiHandler)(this.guiHandler = new CustomGuiHandler()));
        this.feedPetHandler = this.guiHandler.registerHandler((GHandler)new FeedPetGuiHandler());
        this.initNetwork("palapet");
        final SimpleNetworkWrapper network = this.getNetwork();
        PacketUtils.registerPacket(network, (Class)CSActiveSpellPacket.class);
        PacketUtils.registerPacket(network, (Class)CSAssignSkillPacket.class);
        PacketUtils.registerPacket(network, (Class)CSPacketTrapInteraction.class);
        PacketUtils.registerPacket(network, (Class)SCPacketTrapOpen.class);
        PacketUtils.registerPacket(network, (Class)SCObsidianBreakSpeedPacket.class);
        PacketUtils.registerPacket(network, (Class)SCGlobalBreakSpeedPacket.class);
        PacketUtils.registerPacket(network, (Class)BBOpenUIPacket.class);
        PacketUtils.registerPacket(network, (Class)CSPOpenFeedContainerPacket.class);
        PacketUtils.registerPacket(network, (Class)CSAssignRollPacket.class);
        PacketUtils.registerPacket(network, (Class)BBOpenSkillRollUIPacket.class);
        PacketUtils.registerPacket(network, (Class)BBOpenEditPetUIPacket.class);
        PacketUtils.registerPacket(network, (Class)CSChangePetSkinPacket.class);
        PacketUtils.registerPacket(network, (Class)BBRequestSkillRollPacket.class);
        PacketUtils.registerPacket(network, (Class)BBUpdateClientConfigPacket.class);
        PacketUtils.registerPacket(network, (Class)BBUpdateClientSkillValuesPacket.class);
        PacketUtils.registerPacket(network, (Class)SCOpenDebugUIPacket.class);
        PacketUtils.registerPacket(network, (Class)BBPacketRequestCageData.class);
        PacketUtils.registerPacket(network, (Class)CSChangeSkinVisibilityPacket.class);
        this.addListener(new Class[] { SpeedWalkCommonListener.class });
        RegistryUtils.entity((Class)EntityDummyPet.class, (Color)null, 40, (Object)PalaPetMod.getInstance());
        RegistryUtils.entity((Class)EntityPetCage.class, (Color)null, 40, (Object)PalaPetMod.getInstance());
    }
    
    public void onInit(final FMLInitializationEvent event) {
        super.onInit(event);
        this.registryManager.getRegistries().forEach(registry -> registry.onInit(event));
    }
    
    public void onPostInit(final FMLPostInitializationEvent event) {
        super.onPostInit(event);
        this.registryManager.getRegistries().forEach(registry -> registry.onPostInit(event));
    }
    
    public PetAdditionalData findPet(final String name) {
        return this.pets.stream().filter(pet -> pet.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }
    
    public String findRandomDefaultPet() {
        final Random random = new Random();
        return PetCommonProxy.DEFAULT_PETS.get(random.nextInt(PetCommonProxy.DEFAULT_PETS.size()));
    }
    
    public List<File> getFiles(final String folderPath, final String extension) {
        final List<File> files = new ArrayList<File>();
        try {
            final URL url = PetCommonProxy.class.getResource(folderPath);
            final URI uri = url.toURI();
            if (uri.getScheme().equals("jar")) {
                final FileSystem fileSystem = FileSystems.newFileSystem(uri, Collections.emptyMap());
                final Path path = fileSystem.getPath(folderPath, new String[0]);
                final List<File> list;
                Files.walk(path, new FileVisitOption[0]).forEach(p -> {
                    if (p.toString().endsWith(extension)) {
                        list.add(p.toFile());
                    }
                    return;
                });
                fileSystem.close();
            }
            else if (uri.getScheme().equals("file")) {
                final File folder = new File(url.toURI());
                for (final File listFile : folder.listFiles()) {
                    final String name = listFile.getName();
                    if (name.endsWith(extension)) {
                        files.add(listFile);
                    }
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
        return files;
    }
    
    public RegistryManager getRegistryManager() {
        return this.registryManager;
    }
    
    public CaptureManager getCaptureManager() {
        return this.captureManager;
    }
    
    public CustomGuiHandler getGuiHandler() {
        return this.guiHandler;
    }
    
    public int getFeedPetHandler() {
        return this.feedPetHandler;
    }
    
    public List<PetAdditionalData> getPets() {
        return this.pets;
    }
    
    public static PetCommonProxy getInstance() {
        return PetCommonProxy.instance;
    }
    
    static {
        DEFAULT_PETS = Arrays.asList("cat", "rabbit", "dog");
        final Calendar calendar = Calendar.getInstance();
        APRIL_FOOL = (calendar.get(2) == 3 && calendar.get(5) == 1);
    }
}
