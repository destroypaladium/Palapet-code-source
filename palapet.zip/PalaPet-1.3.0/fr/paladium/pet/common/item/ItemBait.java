//Decompiled by Procyon!

package fr.paladium.pet.common.item;

import net.minecraft.item.*;
import fr.paladium.pet.client.tab.*;
import net.minecraft.creativetab.*;

public class ItemBait extends Item
{
    public static final String NAME = "bait";
    
    public ItemBait() {
        this.func_77655_b("bait");
        this.func_111206_d("palapet:bait");
        this.func_77637_a((CreativeTabs)TabPet.INSTANCE);
        this.func_77625_d(1);
    }
}
