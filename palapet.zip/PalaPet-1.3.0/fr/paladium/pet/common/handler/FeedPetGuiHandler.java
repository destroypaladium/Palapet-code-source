//Decompiled by Procyon!

package fr.paladium.pet.common.handler;

import fr.paladium.palaforgeutils.lib.guihandler.*;
import fr.paladium.pet.*;
import fr.paladium.pet.common.*;
import cpw.mods.fml.relauncher.*;
import net.minecraft.entity.player.*;
import net.minecraft.world.*;
import net.minecraft.client.gui.*;
import fr.paladium.pet.common.container.*;
import fr.paladium.pet.client.ui.feed.*;
import net.minecraft.inventory.*;

public class FeedPetGuiHandler extends GHandler
{
    @SideOnly(Side.SERVER)
    public static void open(final EntityPlayerMP player) {
        player.openGui((Object)PalaPetMod.getInstance(), PetCommonProxy.getInstance().getFeedPetHandler(), player.field_70170_p, (int)player.field_70165_t, (int)player.field_70163_u, (int)player.field_70161_v);
    }
    
    @SideOnly(Side.CLIENT)
    public GuiScreen getClientGuiElement(final EntityPlayer player, final World world, final int x, final int y, final int z) {
        return (GuiScreen)new UIFeedPetContainer(new ContainerFeedPet(player));
    }
    
    @SideOnly(Side.SERVER)
    public Container getServerGuiElement(final EntityPlayer player, final World world, final int x, final int y, final int z) {
        return (Container)new ContainerFeedPet(player);
    }
}
