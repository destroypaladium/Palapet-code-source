//Decompiled by Procyon!

package fr.paladium.pet.common.capture;

import java.util.*;

public class CaptureCategory
{
    private final long duration;
    private final List<CaptureSection> sections;
    
    public CaptureCategory(final long duration) {
        this.duration = duration;
        this.sections = new LinkedList<CaptureSection>();
    }
    
    public CaptureCategory addSection(final CaptureSection section) {
        this.sections.add(section);
        return this;
    }
    
    public long getDuration() {
        return this.duration;
    }
    
    public List<CaptureSection> getSections() {
        return this.sections;
    }
}
