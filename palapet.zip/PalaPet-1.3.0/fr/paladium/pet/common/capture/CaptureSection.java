//Decompiled by Procyon!

package fr.paladium.pet.common.capture;

import fr.paladium.lib.apollon.utils.*;

public class CaptureSection
{
    private final int value;
    private final Color color;
    private final float percentage;
    
    public CaptureSection(final int value, final Color color, final float percentage) {
        this.value = value;
        this.color = color;
        this.percentage = percentage;
    }
    
    public int getValue() {
        return this.value;
    }
    
    public Color getColor() {
        return this.color;
    }
    
    public float getPercentage() {
        return this.percentage;
    }
}
