//Decompiled by Procyon!

package fr.paladium.pet.common.capture;

import fr.paladium.lib.apollon.utils.*;
import java.util.*;

public class CaptureManager
{
    public static final int WORST_SCORE = -150;
    private static final Color COLOR_N_50;
    private static final Color COLOR_P_25;
    private static final Color COLOR_P_50;
    private static CaptureManager instance;
    private CaptureCategory category;
    
    public CaptureManager() {
        (CaptureManager.instance = this).registerCategory();
    }
    
    public static CaptureManager getInstance() {
        if (CaptureManager.instance == null) {
            CaptureManager.instance = new CaptureManager();
        }
        return CaptureManager.instance;
    }
    
    public void registerCategory() {
        final CaptureCategory category = new CaptureCategory(1500L);
        final CaptureSection redPositive = new CaptureSection(25, CaptureManager.COLOR_P_25, 10.0f);
        final CaptureSection greenNegative = new CaptureSection(-50, CaptureManager.COLOR_N_50, 15.0f);
        final CaptureSection purplePositive = new CaptureSection(50, CaptureManager.COLOR_P_50, 5.0f);
        category.addSection(greenNegative);
        category.addSection(redPositive);
        category.addSection(purplePositive);
        this.category = category;
    }
    
    public boolean isValidScore(final int score) {
        if (score == -150) {
            return true;
        }
        for (final CaptureSection section : this.category.getSections()) {
            if (score == section.getValue()) {
                return true;
            }
        }
        return false;
    }
    
    public CaptureCategory getCategory() {
        return this.category;
    }
    
    static {
        COLOR_N_50 = Color.decode("#FF3939");
        COLOR_P_25 = Color.decode("#FFEB36");
        COLOR_P_50 = Color.decode("#5ED42A");
    }
}
