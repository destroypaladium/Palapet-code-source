//Decompiled by Procyon!

package fr.paladium.pet.common.skill.listener.passive;

import cpw.mods.fml.common.gameevent.*;
import fr.paladium.pet.client.*;
import fr.paladium.pet.common.utils.*;
import net.minecraft.entity.player.*;
import cpw.mods.fml.relauncher.*;
import cpw.mods.fml.common.eventhandler.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.server.skill.handler.*;

public class SpeedWalkCommonListener
{
    public static final double MIN_SPEED = 0.1;
    public static final double DEFAULT_MULTIPLIER = 1.0;
    
    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public void onPlayerTickClient(final TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.END || !event.player.field_70122_E) {
            return;
        }
        double speedMultiplier = 1.0;
        double boostValue = 1.0;
        final boolean isMoving = event.player.field_70701_bs != 0.0f || event.player.field_70702_br != 0.0f;
        final PassiveSkillEnum skill = PassiveSkillEnum.SPEED_WALK;
        final double value = PetClientProxy.getInstance().getSkillValue(skill.getId());
        boostValue = PetUtils.getValueAsPercent(value);
        speedMultiplier += boostValue;
        if (isMoving) {
            final double currentSpeed = Math.sqrt(event.player.field_70159_w * event.player.field_70159_w + event.player.field_70179_y * event.player.field_70179_y);
            if (currentSpeed < 0.1 * speedMultiplier) {
                final EntityPlayer player = event.player;
                player.field_70159_w *= speedMultiplier;
                final EntityPlayer player2 = event.player;
                player2.field_70179_y *= speedMultiplier;
            }
            return;
        }
        final EntityPlayer player3 = event.player;
        player3.field_70159_w /= speedMultiplier;
        final EntityPlayer player4 = event.player;
        player4.field_70179_y /= speedMultiplier;
    }
    
    @SideOnly(Side.SERVER)
    @SubscribeEvent
    public void onPlayerTickSrver(final TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.END || !event.player.field_70122_E) {
            return;
        }
        final EntityPlayer player = event.player;
        double speedMultiplier = 1.0;
        double boostValue = 1.0;
        final boolean isMoving = event.player.field_70701_bs != 0.0f || event.player.field_70702_br != 0.0f;
        final PassiveSkillEnum skill = PassiveSkillEnum.SPEED_WALK;
        final PetPlayer pet = PetPlayer.get(player);
        final PassiveResponse response = skill.getResponse(pet);
        final double value = response.getPersonalValue(pet);
        boostValue = PetUtils.getValueAsPercent(value);
        speedMultiplier += boostValue;
        if (isMoving) {
            final double currentSpeed = Math.sqrt(event.player.field_70159_w * event.player.field_70159_w + event.player.field_70179_y * event.player.field_70179_y);
            if (currentSpeed < 0.1 * speedMultiplier) {
                final EntityPlayer player2 = event.player;
                player2.field_70159_w *= speedMultiplier;
                final EntityPlayer player3 = event.player;
                player3.field_70179_y *= speedMultiplier;
            }
            return;
        }
        final EntityPlayer player4 = event.player;
        player4.field_70159_w /= speedMultiplier;
        final EntityPlayer player5 = event.player;
        player5.field_70179_y /= speedMultiplier;
    }
}
