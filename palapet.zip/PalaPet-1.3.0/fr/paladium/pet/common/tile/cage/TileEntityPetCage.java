//Decompiled by Procyon!

package fr.paladium.pet.common.tile.cage;

import net.minecraft.tileentity.*;
import fr.paladium.pet.common.utils.*;
import fr.paladium.pet.common.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.command.*;
import net.minecraft.nbt.*;
import fr.paladium.palaforgeutils.lib.uuid.*;
import net.minecraft.network.play.server.*;
import net.minecraft.network.*;
import fr.paladium.palaforgeutils.lib.player.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.palaforgeutils.lib.location.*;
import fr.paladium.pet.common.event.capture.*;
import net.minecraftforge.common.*;
import cpw.mods.fml.common.eventhandler.*;
import fr.paladium.palaforgeutils.lib.task.*;
import net.minecraft.util.*;
import java.util.*;
import java.util.concurrent.*;

public class TileEntityPetCage extends TileEntity
{
    public static final String OWNER_ID_TAG = "ownerId";
    public static final String SCORE_TAG = "score";
    public static final String STATUS_TAG = "status";
    public static final String LAST_INTERACTION_MILLIS_TAG = "lastInteractionMillis";
    public static final String LAST_TRAP_MILLIS_TAG = "lastTrapMillis";
    public static final String ACTIVE_SINCE_MILLIS_TAG = "activeSinceMillis";
    public static final String NEXT_STEP_MILLIS_TAG = "nextStepMillis";
    public static final String PET_TAG = "pet";
    private static final float MINIMUM_CATCH_CHANCE = 15.0f;
    private static final Interval CATCH_CHANCE_INTERVAL;
    private static final long DEFAULT_MILLIS_VALUE = 0L;
    private static final long MINIMUM_CHECK_MILLIS;
    private static final long MINIMUM_ACTIVE_TIME_MILLIS;
    private static final long EXPIRATION_TIME_MILLIS;
    private static final long NEXT_STEP_MILLIS;
    private UUID ownerId;
    private int score;
    private CageStatus status;
    private long nextStepMillis;
    private long lastInteractionMillis;
    private long lastTrapMillis;
    private long activeSinceMillis;
    private String pet;
    private boolean notified;
    private EntityPlayerMP player;
    
    public TileEntityPetCage() {
        this.ownerId = null;
        this.status = CageStatus.UNFILLED;
        this.score = 0;
        this.nextStepMillis = 0L;
        this.lastInteractionMillis = 0L;
        this.lastTrapMillis = 0L;
        this.activeSinceMillis = 0L;
        this.pet = PetCommonProxy.getInstance().findRandomDefaultPet();
        this.notified = false;
    }
    
    public void func_145845_h() {
        super.func_145845_h();
        if (this.field_145850_b.field_72995_K || this.status == CageStatus.UNFILLED) {
            return;
        }
        final long now = System.currentTimeMillis();
        if (CageStatus.isPlaying(this.status)) {
            this.notifyPlay(this.getPlayer(), now);
            this.handleExpiration(now);
            return;
        }
        if (!this.isActive(now)) {
            return;
        }
        if (!this.canCatch(now)) {
            return;
        }
        final EntityPlayerMP player = this.getPlayer();
        if (this.trap(now) && player != null) {
            this.lastInteractionMillis = now;
            final PetTranslateEnum trapped = PetTranslateEnum.MESSAGE_TRAPPED_SUCCESSFULLY;
            trapped.message((ICommandSender)player);
            trapped.notification(player);
            updateClientSide(this);
        }
    }
    
    public void func_145839_a(final NBTTagCompound compound) {
        super.func_145839_a(compound);
        if (!compound.func_74764_b("ownerId") || !compound.func_74764_b("status")) {
            return;
        }
        this.ownerId = UUIDUtils.parseUUID((CharSequence)compound.func_74779_i("ownerId"));
        this.score = compound.func_74762_e("score");
        this.status = CageStatus.values()[compound.func_74762_e("status")];
        this.nextStepMillis = compound.func_74763_f("nextStepMillis");
        this.lastInteractionMillis = compound.func_74763_f("lastInteractionMillis");
        this.lastTrapMillis = compound.func_74763_f("lastTrapMillis");
        this.activeSinceMillis = compound.func_74763_f("activeSinceMillis");
        this.pet = compound.func_74779_i("pet");
    }
    
    public void func_145841_b(final NBTTagCompound compound) {
        super.func_145841_b(compound);
        if (this.ownerId == null || this.status == null || this.pet == null) {
            return;
        }
        compound.func_74778_a("ownerId", UUIDUtils.toString(this.ownerId));
        compound.func_74768_a("score", this.score);
        compound.func_74768_a("status", this.status.ordinal());
        compound.func_74772_a("nextStepMillis", this.nextStepMillis);
        compound.func_74772_a("lastInteractionMillis", this.lastInteractionMillis);
        compound.func_74772_a("lastTrapMillis", this.lastTrapMillis);
        compound.func_74772_a("activeSinceMillis", this.activeSinceMillis);
        compound.func_74778_a("pet", this.pet);
    }
    
    public Packet func_145844_m() {
        final NBTTagCompound nbttagcompound = new NBTTagCompound();
        this.func_145841_b(nbttagcompound);
        return (Packet)new S35PacketUpdateTileEntity(this.field_145851_c, this.field_145848_d, this.field_145849_e, 0, nbttagcompound);
    }
    
    public void onDataPacket(final NetworkManager net, final S35PacketUpdateTileEntity pkt) {
        this.func_145839_a(pkt.func_148857_g());
        this.field_145850_b.func_147458_c(this.field_145851_c, this.field_145848_d, this.field_145849_e, this.field_145851_c, this.field_145848_d, this.field_145849_e);
    }
    
    public void handleExpiration(final long now) {
        if (!this.isExpired(now)) {
            return;
        }
        final EntityPlayerMP player = PlayerUtils.getPlayer(this.ownerId);
        this.field_145850_b.func_147468_f(this.field_145851_c, this.field_145848_d, this.field_145849_e);
        if (player != null) {
            final PetTranslateEnum expired = PetTranslateEnum.MESSAGE_FAMILIAR_ESCAPED;
            expired.message((ICommandSender)player);
            expired.notification(player);
        }
    }
    
    public boolean trap(final long now) {
        this.lastInteractionMillis = now;
        this.lastTrapMillis = now;
        if (TileEntityPetCage.CATCH_CHANCE_INTERVAL.isInferiorOrEquals(15.0f)) {
            this.status = CageStatus.STEP_1;
            return true;
        }
        return false;
    }
    
    public void fill(final EntityPlayerMP player) {
        this.ownerId = player.func_110124_au();
        this.status = CageStatus.FILLED;
        this.activeSinceMillis = System.currentTimeMillis();
    }
    
    public void updateScore(final EntityPlayerMP player, final int score) {
        final long now = System.currentTimeMillis();
        this.lastInteractionMillis = now;
        this.score += score;
        PetTranslateEnum.MESSAGE_CURRENT_SCORE.message((ICommandSender)player, new Object[] { this.score, this.status.getScore() });
        if (score < 0) {
            final CageStatus status = CageStatus.getStep(this.score);
            if (status != null && status != this.status) {
                this.status = status;
                PetTranslateEnum.MESSAGE_DERANK.message((ICommandSender)player, new Object[] { this.status.getTranslate().text() });
            }
        }
        if (this.score <= 0) {
            this.onFail(player);
            return;
        }
        if (this.score < this.status.getScore()) {
            return;
        }
        if (this.status == CageStatus.STEP_3) {
            this.onWin(player);
            return;
        }
        this.onSuccess(player, now);
    }
    
    private void onWin(final EntityPlayerMP player) {
        this.field_145850_b.func_147468_f(this.field_145851_c, this.field_145848_d, this.field_145849_e);
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        final DoubleLocation location = new DoubleLocation((double)this.field_145851_c, (double)this.field_145848_d, (double)this.field_145849_e);
        final PetCaptureEvent event = new PetCaptureEvent((EntityPlayer)player, pet, location);
        if (pet == null || pet.has() || MinecraftForge.EVENT_BUS.post((Event)event)) {
            return;
        }
        PetTranslateEnum.MESSAGE_WIN.message((ICommandSender)player);
        pet.unlock(player, this.pet);
    }
    
    private void onSuccess(final EntityPlayerMP player, final long now) {
        final CageStatus oldStatus = this.status;
        this.status = CageStatus.getNextStep(this.status);
        this.nextStepMillis = now + TileEntityPetCage.NEXT_STEP_MILLIS;
        this.notified = false;
        final PetTranslateEnum success = PetTranslateEnum.MESSAGE_STEP_SUCCESSFULLY;
        final String duration = DurationConverter.fromMillisToString(TileEntityPetCage.NEXT_STEP_MILLIS);
        success.message((ICommandSender)player, new Object[] { oldStatus.getTranslate().text(), duration });
        success.notification(player, new Object[] { oldStatus.getTranslate().text(), duration });
    }
    
    private void onFail(final EntityPlayerMP player) {
        player.func_70097_a(DamageSource.field_76376_m, 2.0f);
        this.field_145850_b.func_147468_f(this.field_145851_c, this.field_145848_d, this.field_145849_e);
        PetTranslateEnum.MESSAGE_FAMILIAR_ESCAPED.message((ICommandSender)player);
    }
    
    public void notifyPlay(final EntityPlayerMP player, final long now) {
        if (player == null) {
            return;
        }
        final boolean result = this.canPlayNextStep(now);
        if (result && !this.notified) {
            this.notified = true;
            final PetTranslateEnum wait = PetTranslateEnum.MESSAGE_CAN_REPLAY;
            wait.message((ICommandSender)player);
            wait.notification(player);
            updateClientSide(this);
        }
    }
    
    public boolean canPlayNextStep(final long now) {
        return this.nextStepMillis <= now;
    }
    
    public boolean canPlayNextStep(final EntityPlayerMP player, final long now) {
        final boolean result = this.canPlayNextStep(now);
        if (!result && player != null) {
            final PetTranslateEnum wait = PetTranslateEnum.MESSAGE_WAIT;
            final String duration = DurationConverter.fromMillisToString(this.nextStepMillis - now);
            wait.message((ICommandSender)player, new Object[] { duration });
            wait.notification(player, new Object[] { duration });
        }
        return result;
    }
    
    public boolean isOwner(final EntityPlayerMP player) {
        return this.ownerId == null || this.ownerId.equals(player.func_110124_au());
    }
    
    private boolean isExpired(final long now) {
        return this.activeSinceMillis + TileEntityPetCage.EXPIRATION_TIME_MILLIS <= now && this.lastInteractionMillis + TileEntityPetCage.EXPIRATION_TIME_MILLIS <= now;
    }
    
    private boolean canCatch(final long now) {
        if (this.lastTrapMillis == 0L) {
            this.lastTrapMillis = now;
            return false;
        }
        return this.lastTrapMillis + TileEntityPetCage.MINIMUM_CHECK_MILLIS <= now;
    }
    
    private boolean isActive(final long now) {
        return this.activeSinceMillis + TileEntityPetCage.MINIMUM_ACTIVE_TIME_MILLIS <= now;
    }
    
    public boolean isFilled() {
        return this.status == CageStatus.FILLED;
    }
    
    public EntityPlayerMP getPlayer() {
        if (this.player == null) {
            this.player = PlayerUtils.getPlayer(this.ownerId);
        }
        if (this.player != null && this.player.field_70128_L) {
            this.player = null;
        }
        return this.player;
    }
    
    public static void updateClientSide(final TileEntityPetCage cage) {
        final double radius = 32.0;
        final Packet packet = cage.func_145844_m();
        final List<EntityPlayerMP> players = (List<EntityPlayerMP>)cage.func_145831_w().func_72872_a((Class)EntityPlayerMP.class, AxisAlignedBB.func_72330_a(cage.field_145851_c - radius, cage.field_145848_d - radius, cage.field_145849_e - radius, cage.field_145851_c + radius, cage.field_145848_d + radius, cage.field_145849_e + radius));
        for (final EntityPlayerMP playerMPArround : players) {
            final EntityPlayerMP playerArround = playerMPArround;
            playerMPArround.field_71135_a.func_147359_a(packet);
        }
    }
    
    public UUID getOwnerId() {
        return this.ownerId;
    }
    
    public int getScore() {
        return this.score;
    }
    
    public CageStatus getStatus() {
        return this.status;
    }
    
    public long getNextStepMillis() {
        return this.nextStepMillis;
    }
    
    public long getLastInteractionMillis() {
        return this.lastInteractionMillis;
    }
    
    public long getLastTrapMillis() {
        return this.lastTrapMillis;
    }
    
    public long getActiveSinceMillis() {
        return this.activeSinceMillis;
    }
    
    public String getPet() {
        return this.pet;
    }
    
    public boolean isNotified() {
        return this.notified;
    }
    
    public void setOwnerId(final UUID ownerId) {
        this.ownerId = ownerId;
    }
    
    public void setScore(final int score) {
        this.score = score;
    }
    
    public void setStatus(final CageStatus status) {
        this.status = status;
    }
    
    public void setNextStepMillis(final long nextStepMillis) {
        this.nextStepMillis = nextStepMillis;
    }
    
    public void setLastInteractionMillis(final long lastInteractionMillis) {
        this.lastInteractionMillis = lastInteractionMillis;
    }
    
    public void setLastTrapMillis(final long lastTrapMillis) {
        this.lastTrapMillis = lastTrapMillis;
    }
    
    public void setActiveSinceMillis(final long activeSinceMillis) {
        this.activeSinceMillis = activeSinceMillis;
    }
    
    public void setPet(final String pet) {
        this.pet = pet;
    }
    
    public void setNotified(final boolean notified) {
        this.notified = notified;
    }
    
    public void setPlayer(final EntityPlayerMP player) {
        this.player = player;
    }
    
    static {
        CATCH_CHANCE_INTERVAL = Interval.of(0.0f, 50.0f);
        MINIMUM_CHECK_MILLIS = TimeUnit.MINUTES.toMillis(2L);
        MINIMUM_ACTIVE_TIME_MILLIS = TimeUnit.MINUTES.toMillis(2L);
        EXPIRATION_TIME_MILLIS = TimeUnit.MINUTES.toMillis(5L);
        NEXT_STEP_MILLIS = TimeUnit.MINUTES.toMillis(2L);
    }
}
