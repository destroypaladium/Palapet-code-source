//Decompiled by Procyon!

package fr.paladium.pet.common.tile.cage;

import fr.paladium.pet.common.constant.*;

public enum CageStatus
{
    UNFILLED, 
    FILLED, 
    STEP_1(PetTranslateEnum.TEXT_CAPTURE_STEP_1, 100), 
    STEP_2(PetTranslateEnum.TEXT_CAPTURE_STEP_2, 200), 
    STEP_3(PetTranslateEnum.TEXT_CAPTURE_STEP_3, 400);
    
    private PetTranslateEnum translate;
    private final int score;
    
    private CageStatus() {
        this.translate = PetTranslateEnum.TEXT_CAPTURE_STEP_1;
        this.score = 0;
    }
    
    private CageStatus(final PetTranslateEnum translate, final int score) {
        this.translate = translate;
        this.score = score;
    }
    
    public static CageStatus getNextStep(final CageStatus status) {
        if (status == null) {
            return null;
        }
        if (status == CageStatus.STEP_1) {
            return CageStatus.STEP_2;
        }
        if (status == CageStatus.STEP_2) {
            return CageStatus.STEP_3;
        }
        return null;
    }
    
    public static CageStatus getStep(final int score) {
        if (score < CageStatus.STEP_1.score) {
            return CageStatus.STEP_1;
        }
        if (score < CageStatus.STEP_2.score) {
            return CageStatus.STEP_2;
        }
        if (score < CageStatus.STEP_3.score) {
            return CageStatus.STEP_3;
        }
        return null;
    }
    
    public static boolean isPlaying(final CageStatus status) {
        return status != null && (status == CageStatus.STEP_1 || status == CageStatus.STEP_2 || status == CageStatus.STEP_3);
    }
    
    public PetTranslateEnum getTranslate() {
        return this.translate;
    }
    
    public int getScore() {
        return this.score;
    }
}
