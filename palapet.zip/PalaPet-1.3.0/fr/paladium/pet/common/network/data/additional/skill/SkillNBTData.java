//Decompiled by Procyon!

package fr.paladium.pet.common.network.data.additional.skill;

import fr.paladium.pet.common.network.data.*;
import net.minecraft.nbt.*;
import java.util.*;
import net.minecraft.entity.player.*;

public class SkillNBTData
{
    public static final String NO_SKILL = "no_skill";
    public static final String TAG_ID = "id";
    public static final String TAG_LAST_CHANGE = "lastChange";
    public static final String TAG_NEXT_USE = "nextUse";
    private static final String TAG_SKILLS = "skills";
    private HashMap<Integer, SkillData> skills;
    
    public SkillNBTData() {
        this.skills = new HashMap<Integer, SkillData>();
    }
    
    public void read(final PetPlayer pet, final NBTTagCompound compound) {
        this.skills.clear();
        final int slots = pet.getSlots(pet.getLevel());
        final NBTTagList tagList = compound.func_150295_c("skills", 10);
        for (int i = 0; i < tagList.func_74745_c() && i < slots; ++i) {
            final NBTTagCompound assignmentCompound = tagList.func_150305_b(i);
            final String id = assignmentCompound.func_74779_i("id");
            final long lastChange = assignmentCompound.func_74763_f("lastChange");
            final long lastUse = assignmentCompound.func_74763_f("nextUse");
            final SkillData data = new SkillData(id, lastChange, lastUse);
            this.skills.put(i, data);
        }
    }
    
    public void write(final PetPlayer pet, final NBTTagCompound compound) {
        final NBTTagList tagList = new NBTTagList();
        for (int slots = pet.getSlots(pet.getLevel()), i = 0; i < slots; ++i) {
            SkillData data = null;
            if (!this.skills.containsKey(i)) {
                data = new SkillData("no_skill");
            }
            else {
                data = this.skills.get(i);
            }
            final NBTTagCompound nbt = new NBTTagCompound();
            nbt.func_74778_a("id", data.getSkillId());
            nbt.func_74772_a("lastChange", data.getLastChangeMillis());
            nbt.func_74772_a("nextUse", data.getNextUseMillis());
            tagList.func_74742_a((NBTBase)nbt);
        }
        compound.func_74782_a("skills", (NBTBase)tagList);
    }
    
    public SkillData get(final String name) {
        for (final SkillData data : this.skills.values()) {
            if (data.getSkillId().equals(name)) {
                return data;
            }
        }
        return null;
    }
    
    public void refresh(final PetPlayer petPlayer, final EntityPlayer player) {
        final NBTTagCompound nbt = player.getEntityData();
        if (nbt == null) {
            return;
        }
        this.write(petPlayer, nbt);
        this.read(petPlayer, nbt);
    }
    
    public HashMap<Integer, SkillData> getSkills() {
        return this.skills;
    }
    
    public void setSkills(final HashMap<Integer, SkillData> skills) {
        this.skills = skills;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof SkillNBTData)) {
            return false;
        }
        final SkillNBTData other = (SkillNBTData)o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$skills = this.getSkills();
        final Object other$skills = other.getSkills();
        if (this$skills == null) {
            if (other$skills == null) {
                return true;
            }
        }
        else if (this$skills.equals(other$skills)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof SkillNBTData;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $skills = this.getSkills();
        result = result * 59 + (($skills == null) ? 43 : $skills.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "SkillNBTData(skills=" + this.getSkills() + ")";
    }
}
