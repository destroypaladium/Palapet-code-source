//Decompiled by Procyon!

package fr.paladium.pet.common.network.data.additional.assignment;

import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.common.event.experience.*;
import net.minecraft.entity.player.*;
import net.minecraftforge.common.*;
import cpw.mods.fml.common.eventhandler.*;
import fr.paladium.pet.server.config.assignment.*;
import fr.paladium.pet.common.event.assignment.*;
import java.util.*;

public class AssignmentData
{
    private String assignmentId;
    private double progress;
    private boolean completed;
    
    public AssignmentData(final String id) {
        this.assignmentId = id;
        this.progress = 0.0;
        this.completed = false;
    }
    
    public void complete(final EntityPlayerMP player, final PetPlayer pet, final Assignment assignment) {
        this.progress = assignment.getAmount();
        this.completed = true;
        pet.earnExperience((EntityPlayer)player, PetExperienceSource.ASSIGNMENT, assignment.getGivenExp());
        pet.earnHappiness(player, assignment.getGivenPoints());
        MinecraftForge.EVENT_BUS.post((Event)new AssignmentFinishEvent((EntityPlayer)player, assignment));
    }
    
    public void incrementProgress(final EntityPlayerMP player, final PetPlayer pet, final AssignmentConfig config, final double amount) {
        final Optional<Assignment> result = config.findAssignmentById(this.assignmentId);
        if (!result.isPresent()) {
            return;
        }
        final AssignmentIncrementEvent incrementEvent = new AssignmentIncrementEvent((EntityPlayer)player, (Assignment)result.get(), this.progress, amount);
        if (MinecraftForge.EVENT_BUS.post((Event)incrementEvent)) {
            return;
        }
        final Assignment assignment = result.get();
        final double maximumProgress = assignment.getAmount();
        this.progress += amount;
        if (this.progress >= maximumProgress) {
            this.progress = maximumProgress;
            this.complete(player, pet, assignment);
        }
    }
    
    public String getAssignmentId() {
        return this.assignmentId;
    }
    
    public double getProgress() {
        return this.progress;
    }
    
    public boolean isCompleted() {
        return this.completed;
    }
    
    public void setAssignmentId(final String assignmentId) {
        this.assignmentId = assignmentId;
    }
    
    public void setProgress(final double progress) {
        this.progress = progress;
    }
    
    public void setCompleted(final boolean completed) {
        this.completed = completed;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof AssignmentData)) {
            return false;
        }
        final AssignmentData other = (AssignmentData)o;
        if (!other.canEqual(this)) {
            return false;
        }
        if (Double.compare(this.getProgress(), other.getProgress()) != 0) {
            return false;
        }
        if (this.isCompleted() != other.isCompleted()) {
            return false;
        }
        final Object this$assignmentId = this.getAssignmentId();
        final Object other$assignmentId = other.getAssignmentId();
        if (this$assignmentId == null) {
            if (other$assignmentId == null) {
                return true;
            }
        }
        else if (this$assignmentId.equals(other$assignmentId)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof AssignmentData;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final long $progress = Double.doubleToLongBits(this.getProgress());
        result = result * 59 + (int)($progress >>> 32 ^ $progress);
        result = result * 59 + (this.isCompleted() ? 79 : 97);
        final Object $assignmentId = this.getAssignmentId();
        result = result * 59 + (($assignmentId == null) ? 43 : $assignmentId.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "AssignmentData(assignmentId=" + this.getAssignmentId() + ", progress=" + this.getProgress() + ", completed=" + this.isCompleted() + ")";
    }
}
