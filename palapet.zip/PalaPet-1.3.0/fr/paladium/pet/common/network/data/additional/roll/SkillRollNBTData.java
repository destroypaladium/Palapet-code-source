//Decompiled by Procyon!

package fr.paladium.pet.common.network.data.additional.roll;

import fr.paladium.pet.common.network.data.additional.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.common.network.data.additional.skill.*;
import java.util.*;
import net.minecraft.nbt.*;
import fr.paladium.pet.server.skill.skill.*;

public class SkillRollNBTData implements INbtData
{
    public static final String TAG_SLOT = "slot";
    public static final String TAG_ID = "id";
    private static final String TAG_ROLLS = "rolls";
    private List<SkillRollData> rolls;
    
    public SkillRollNBTData() {
        this.rolls = new ArrayList<SkillRollData>();
    }
    
    public List<SkillRollData> getRolls(final PetPlayer pet) {
        final Collection<SkillData> skills = pet.getSkillData().getSkills().values();
        boolean found;
        final Collection<SkillData> collection;
        final Iterator<SkillData> iterator;
        SkillData skill;
        this.rolls.removeIf(roll -> {
            if (roll.getSlot() < 0 || roll.getSlot() > 5) {
                return true;
            }
            else {
                found = false;
                collection.iterator();
                while (iterator.hasNext()) {
                    skill = iterator.next();
                    if (skill.getSkillId().equals(roll.getSkillId())) {
                        found = true;
                        break;
                    }
                }
                return !found;
            }
        });
        return this.rolls;
    }
    
    public SkillRollData get(final PetPlayer pet, final int slot) {
        for (final SkillRollData roll : this.getRolls(pet)) {
            if (roll.getSlot() == slot) {
                return roll;
            }
        }
        return null;
    }
    
    public void read(final NBTTagCompound compound) {
        this.rolls.clear();
        final NBTTagList tagList = compound.func_150295_c("rolls", 10);
        for (int i = 0; i < tagList.func_74745_c(); ++i) {
            final NBTTagCompound nbt = tagList.func_150305_b(i);
            final int slot = nbt.func_74762_e("slot");
            final String id = nbt.func_74779_i("id");
            this.rolls.add(new SkillRollData(slot, id));
        }
    }
    
    public void write(final NBTTagCompound compound) {
        final NBTTagList tagList = new NBTTagList();
        for (final SkillRollData roll : this.rolls) {
            final NBTTagCompound nbt = new NBTTagCompound();
            nbt.func_74768_a("slot", roll.getSlot());
            nbt.func_74778_a("id", roll.getSkillId());
            tagList.func_74742_a((NBTBase)nbt);
        }
        compound.func_74782_a("rolls", (NBTBase)tagList);
    }
    
    public boolean removeSkillRoll(final int slot) {
        return this.rolls.removeIf(roll -> roll.getSlot() == slot);
    }
    
    public void setSkillRoll(final int slot, final Skill skill) {
        this.rolls.removeIf(roll -> roll.getSlot() == slot);
        this.rolls.add(new SkillRollData(slot, skill.getId()));
    }
}
