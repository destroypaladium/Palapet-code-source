//Decompiled by Procyon!

package fr.paladium.pet.common.network.data.additional.skill;

import net.minecraft.entity.player.*;
import fr.paladium.pet.server.config.skill.*;
import fr.paladium.pet.server.skill.skill.*;
import fr.paladium.pet.common.network.data.*;

public class SkillData
{
    private String skillId;
    private long lastChangeMillis;
    private long nextUseMillis;
    
    public SkillData(final String id) {
        this.skillId = id;
        this.nextUseMillis = 0L;
        this.lastChangeMillis = 0L;
    }
    
    public long getChangeCooldown(final EntityPlayerMP player, final long now) {
        final long cooldown = SkillConfig.get().getChangeSkillCooldown() - (now - this.lastChangeMillis);
        if (cooldown <= 0L) {
            return 0L;
        }
        return cooldown;
    }
    
    public boolean canChangeSlot(final long cooldown) {
        return cooldown <= 0L;
    }
    
    public void changeSlot(final Skill skill, final long nextUseMillis) {
        this.skillId = skill.getId();
        this.nextUseMillis = nextUseMillis;
        this.lastChangeMillis = System.currentTimeMillis();
        this.nextUseMillis = nextUseMillis;
    }
    
    public void changeSlotBypass(final Skill skill) {
        this.skillId = skill.getId();
        this.nextUseMillis = 0L;
        this.lastChangeMillis = 0L;
    }
    
    public void use(final PetPlayer petPlayer, final long usageMillis) {
        this.nextUseMillis = usageMillis;
        petPlayer.putNextSkillUsage(this.skillId, usageMillis);
    }
    
    public String getSkillId() {
        return this.skillId;
    }
    
    public long getLastChangeMillis() {
        return this.lastChangeMillis;
    }
    
    public long getNextUseMillis() {
        return this.nextUseMillis;
    }
    
    public void setSkillId(final String skillId) {
        this.skillId = skillId;
    }
    
    public void setLastChangeMillis(final long lastChangeMillis) {
        this.lastChangeMillis = lastChangeMillis;
    }
    
    public void setNextUseMillis(final long nextUseMillis) {
        this.nextUseMillis = nextUseMillis;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof SkillData)) {
            return false;
        }
        final SkillData other = (SkillData)o;
        if (!other.canEqual(this)) {
            return false;
        }
        if (this.getLastChangeMillis() != other.getLastChangeMillis()) {
            return false;
        }
        if (this.getNextUseMillis() != other.getNextUseMillis()) {
            return false;
        }
        final Object this$skillId = this.getSkillId();
        final Object other$skillId = other.getSkillId();
        if (this$skillId == null) {
            if (other$skillId == null) {
                return true;
            }
        }
        else if (this$skillId.equals(other$skillId)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof SkillData;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final long $lastChangeMillis = this.getLastChangeMillis();
        result = result * 59 + (int)($lastChangeMillis >>> 32 ^ $lastChangeMillis);
        final long $nextUseMillis = this.getNextUseMillis();
        result = result * 59 + (int)($nextUseMillis >>> 32 ^ $nextUseMillis);
        final Object $skillId = this.getSkillId();
        result = result * 59 + (($skillId == null) ? 43 : $skillId.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "SkillData(skillId=" + this.getSkillId() + ", lastChangeMillis=" + this.getLastChangeMillis() + ", nextUseMillis=" + this.getNextUseMillis() + ")";
    }
    
    public SkillData(final String skillId, final long lastChangeMillis, final long nextUseMillis) {
        this.skillId = skillId;
        this.lastChangeMillis = lastChangeMillis;
        this.nextUseMillis = nextUseMillis;
    }
}
