//Decompiled by Procyon!

package fr.paladium.pet.common.network.data.additional.roll;

public class SkillRollData
{
    private int slot;
    private String skillId;
    
    public int getSlot() {
        return this.slot;
    }
    
    public String getSkillId() {
        return this.skillId;
    }
    
    public void setSlot(final int slot) {
        this.slot = slot;
    }
    
    public void setSkillId(final String skillId) {
        this.skillId = skillId;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof SkillRollData)) {
            return false;
        }
        final SkillRollData other = (SkillRollData)o;
        if (!other.canEqual(this)) {
            return false;
        }
        if (this.getSlot() != other.getSlot()) {
            return false;
        }
        final Object this$skillId = this.getSkillId();
        final Object other$skillId = other.getSkillId();
        if (this$skillId == null) {
            if (other$skillId == null) {
                return true;
            }
        }
        else if (this$skillId.equals(other$skillId)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof SkillRollData;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        result = result * 59 + this.getSlot();
        final Object $skillId = this.getSkillId();
        result = result * 59 + (($skillId == null) ? 43 : $skillId.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "SkillRollData(slot=" + this.getSlot() + ", skillId=" + this.getSkillId() + ")";
    }
    
    public SkillRollData(final int slot, final String skillId) {
        this.slot = slot;
        this.skillId = skillId;
    }
}
