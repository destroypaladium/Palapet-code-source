//Decompiled by Procyon!

package fr.paladium.pet.common.network.data.additional.assignment;

import fr.paladium.pet.common.network.data.additional.*;
import java.util.*;
import net.minecraft.nbt.*;

public class AssignmentNBTData implements INbtData
{
    public static final double NO_PROGRESS = -1.0;
    public static final String TAG_ASSIGNMENT_ID = "assignmentId";
    public static final String TAG_PROGRESS = "progress";
    public static final String TAG_COMPLETED = "completed";
    private static final String TAG_ASSIGNMENTS = "assignments";
    private HashMap<String, AssignmentData> assignments;
    
    public AssignmentNBTData() {
        this.assignments = new HashMap<String, AssignmentData>();
    }
    
    @Override
    public void read(final NBTTagCompound compound) {
        this.assignments.clear();
        final NBTTagList tagList = compound.func_150295_c("assignments", 10);
        for (int i = 0; i < tagList.func_74745_c(); ++i) {
            final NBTTagCompound assignmentCompound = tagList.func_150305_b(i);
            final String id = assignmentCompound.func_74779_i("assignmentId");
            final double progress = assignmentCompound.func_74769_h("progress");
            final boolean completed = assignmentCompound.func_74767_n("completed");
            final AssignmentData data = new AssignmentData(id);
            data.setProgress(progress);
            data.setCompleted(completed);
            this.assignments.put(id, data);
        }
    }
    
    @Override
    public void write(final NBTTagCompound compound) {
        final NBTTagList tagList = new NBTTagList();
        final NBTTagCompound assignmentCompound;
        final NBTTagList list;
        this.assignments.forEach((id, data) -> {
            assignmentCompound = new NBTTagCompound();
            assignmentCompound.func_74778_a("assignmentId", data.getAssignmentId());
            assignmentCompound.func_74780_a("progress", data.getProgress());
            assignmentCompound.func_74757_a("completed", data.isCompleted());
            list.func_74742_a((NBTBase)assignmentCompound);
            return;
        });
        compound.func_74782_a("assignments", (NBTBase)tagList);
    }
    
    public HashMap<String, AssignmentData> getAssignments() {
        return this.assignments;
    }
    
    public void setAssignments(final HashMap<String, AssignmentData> assignments) {
        this.assignments = assignments;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof AssignmentNBTData)) {
            return false;
        }
        final AssignmentNBTData other = (AssignmentNBTData)o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$assignments = this.getAssignments();
        final Object other$assignments = other.getAssignments();
        if (this$assignments == null) {
            if (other$assignments == null) {
                return true;
            }
        }
        else if (this$assignments.equals(other$assignments)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof AssignmentNBTData;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $assignments = this.getAssignments();
        result = result * 59 + (($assignments == null) ? 43 : $assignments.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "AssignmentNBTData(assignments=" + this.getAssignments() + ")";
    }
}
