//Decompiled by Procyon!

package fr.paladium.pet.common.network.data.additional;

import net.minecraft.nbt.*;

public interface INbtData
{
    void read(final NBTTagCompound p0);
    
    void write(final NBTTagCompound p0);
}
