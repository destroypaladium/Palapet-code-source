//Decompiled by Procyon!

package fr.paladium.pet.common.network.data;

import fr.paladium.palaforgeutils.lib.extended.*;
import fr.paladium.palaforgeutils.lib.time.*;
import net.minecraft.nbt.*;
import fr.paladium.pet.server.skill.skill.*;
import net.minecraft.entity.player.*;
import fr.paladium.helios.utils.*;
import java.time.*;
import fr.paladium.pet.server.config.global.*;
import fr.paladium.pet.common.network.data.additional.assignment.*;
import java.util.stream.*;
import fr.paladium.pet.server.config.assignment.*;
import fr.paladium.pet.server.skill.handler.*;
import fr.paladium.pet.server.config.assignment.fields.*;
import java.util.*;
import fr.paladium.pet.common.event.global.*;
import fr.paladium.pet.*;
import fr.paladium.pet.common.event.happiness.*;
import net.minecraftforge.common.*;
import cpw.mods.fml.common.eventhandler.*;
import fr.paladium.pet.common.event.experience.*;
import fr.paladium.pet.common.event.level.*;
import fr.paladium.pet.common.network.data.additional.skill.*;
import fr.paladium.pet.common.network.data.additional.roll.*;
import org.apache.commons.lang3.*;
import joptsimple.internal.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.command.*;
import fr.paladium.pet.common.provider.*;

public class PetPlayer extends ExtendedEntityProperties
{
    public static final String PROP_NAME = "palapet_PetPlayer";
    public static final String TAG_NAME = "PetPlayer";
    public static final int MAX_SLOTS = 20;
    public static final int MAX_LEVEL = 100;
    public static final int MAX_ASSIGNMENTS_TRY = 1000;
    private static final String TAG_LAST_CONNECTION_INCREMENT = "lastConnectionIncrement";
    private static final String TAG_EXPERIENCE = "experience";
    private static final String TAG_ASSIGNMENT_RESET_MILLIS = "assignmentResetMillis";
    private static final String TAG_HAPPINESS = "happiness";
    private static final String TAG_UNLOCKED_SKIN = "unlockedSkin";
    private static final String TAG_CURRENT_SKIN = "currentSkin";
    private static final String TAG_LAST_SKILL_USAGE = "lastSkillUsage";
    private static final String TAG_VISIBLE = "visible";
    private static final String TAG_SKILL_USES = "skillUses";
    private static final String TAG_SKILL_USES_ID = "skillUsesId";
    private static final String TAG_SKILL_USES_MILLIS = "skillUsesMillis";
    private long lastConnectionIncrement;
    private double experience;
    private long assignmentResetMillis;
    private int happiness;
    private long lastSkillUsage;
    private String unlockedSkin;
    private String currentSkin;
    private boolean visible;
    private AssignmentNBTData assignmentData;
    private SkillNBTData skillData;
    private SkillRollNBTData skillRollData;
    private final HashMap<String, Long> skillUsesMap;
    
    public PetPlayer() {
        final long now = TimeUtils.now();
        this.lastConnectionIncrement = now;
        this.experience = 0.0;
        this.happiness = 0;
        this.assignmentResetMillis = now;
        this.visible = true;
        this.currentSkin = null;
        this.unlockedSkin = null;
        this.skillUsesMap = new HashMap<String, Long>();
    }
    
    public static PetPlayer get(final EntityPlayer player) {
        return (PetPlayer)player.getExtendedProperties("palapet_PetPlayer");
    }
    
    public void saveNBTData(final NBTTagCompound compound) {
        final NBTTagCompound nbt = new NBTTagCompound();
        nbt.func_74772_a("lastConnectionIncrement", this.lastConnectionIncrement);
        nbt.func_74780_a("experience", this.experience);
        nbt.func_74772_a("assignmentResetMillis", this.assignmentResetMillis);
        nbt.func_74772_a("lastSkillUsage", this.lastSkillUsage);
        nbt.func_74768_a("happiness", this.happiness);
        nbt.func_74757_a("visible", this.visible);
        final NBTTagList skillUses = new NBTTagList();
        final NBTTagCompound skillUse;
        final NBTTagList list;
        this.skillUsesMap.forEach((skillId, millis) -> {
            skillUse = new NBTTagCompound();
            skillUse.func_74778_a("skillUsesId", skillId);
            skillUse.func_74772_a("skillUsesMillis", (long)millis);
            list.func_74742_a((NBTBase)skillUse);
            return;
        });
        nbt.func_74782_a("skillUses", (NBTBase)skillUses);
        this.getAssignmentData().write(nbt);
        this.getSkillData().write(this, nbt);
        this.getSkillRollData().write(nbt);
        if (this.currentSkin != null) {
            nbt.func_74778_a("currentSkin", this.currentSkin);
        }
        if (this.unlockedSkin != null) {
            nbt.func_74778_a("unlockedSkin", this.unlockedSkin);
        }
        compound.func_74782_a("PetPlayer", (NBTBase)nbt);
    }
    
    public void loadNBTData(final NBTTagCompound compound) {
        if (!compound.func_74764_b("PetPlayer")) {
            return;
        }
        final NBTTagCompound nbt = compound.func_74775_l("PetPlayer");
        this.lastConnectionIncrement = nbt.func_74763_f("lastConnectionIncrement");
        this.experience = nbt.func_74769_h("experience");
        this.assignmentResetMillis = nbt.func_74763_f("assignmentResetMillis");
        this.lastSkillUsage = nbt.func_74763_f("lastSkillUsage");
        this.happiness = nbt.func_74762_e("happiness");
        this.visible = nbt.func_74767_n("visible");
        final NBTTagList skillUses = nbt.func_150295_c("skillUses", 10);
        for (int i = 0; i < skillUses.func_74745_c(); ++i) {
            final NBTTagCompound skillUse = skillUses.func_150305_b(i);
            final String skillId = skillUse.func_74779_i("skillUsesId");
            final long millis = skillUse.func_74763_f("skillUsesMillis");
            this.skillUsesMap.put(skillId, millis);
        }
        this.getAssignmentData().read(nbt);
        this.getSkillData().read(this, nbt);
        this.getSkillRollData().read(nbt);
        if (nbt.func_74764_b("currentSkin")) {
            this.currentSkin = nbt.func_74779_i("currentSkin");
        }
        if (nbt.func_74764_b("unlockedSkin")) {
            this.unlockedSkin = nbt.func_74779_i("unlockedSkin");
        }
    }
    
    public void putNextSkillUsage(final String skillId, final long millis) {
        this.skillUsesMap.put(skillId, millis);
    }
    
    public long getNextSkillUsage(final Skill skill) {
        final long now = System.currentTimeMillis();
        this.skillUsesMap.entrySet().removeIf(entry -> entry.getValue() < now);
        return this.skillUsesMap.getOrDefault(skill.getId(), 0L);
    }
    
    public void tryResetAssignment(final EntityPlayerMP player, final long now) {
        final ZonedDateTime nowDate = TimeUtil.nowZoned();
        final ZonedDateTime lastResetDate = TimeUtil.fromLong(this.assignmentResetMillis);
        final boolean isSameDay = nowDate.getDayOfYear() == lastResetDate.getDayOfYear();
        if (this.getAssignmentData().getAssignments().isEmpty() || !isSameDay) {
            this.pickupAssignments(player, now);
        }
    }
    
    public void reduceHappinessFromAssignments(final EntityPlayerMP player) {
        final Random random = new Random();
        final HashMap<String, AssignmentData> assignments = (HashMap<String, AssignmentData>)this.getAssignmentData().getAssignments();
        final int happinessLoss = GlobalConfig.get().getHappinessLoss();
        final PassiveResponse response = PassiveSkillEnum.PET_HAPPINESS.getResponse(this);
        final double value = response.getPersonalValue(this);
        final List<AssignmentData> uncompletedAssignments = assignments.values().stream().filter(data -> !data.isCompleted()).collect((Collector<? super AssignmentData, ?, List<AssignmentData>>)Collectors.toList());
        if (uncompletedAssignments.isEmpty()) {
            return;
        }
        if (response.has(value)) {
            for (int amount = (int)Math.floor(value), i = 0; i < amount; ++i) {
                if (uncompletedAssignments.isEmpty()) {
                    break;
                }
                final AssignmentData randomAssignment = uncompletedAssignments.get(random.nextInt(uncompletedAssignments.size()));
                final Optional<Assignment> result = AssignmentConfig.get().findAssignmentById(randomAssignment.getAssignmentId());
                if (result.isPresent()) {
                    uncompletedAssignments.remove(randomAssignment);
                    randomAssignment.complete(player, this, (Assignment)result.get());
                }
            }
        }
        for (int j = 0; j < uncompletedAssignments.size(); ++j) {
            this.happiness -= happinessLoss;
        }
        if (this.happiness < 0) {
            this.happiness = 0;
        }
    }
    
    public void pickupAssignments(final EntityPlayerMP player, final long now) {
        final HashMap<String, AssignmentData> assignments = (HashMap<String, AssignmentData>)this.getAssignmentData().getAssignments();
        this.reduceHappinessFromAssignments(player);
        this.getAssignmentData().getAssignments().clear();
        this.assignmentResetMillis = now;
        final Random random = new Random(now);
        final AssignmentConfig config = AssignmentConfig.get();
        final int maxAssignments = config.getMaxAssignmentsPerDay();
        int i = assignments.size();
        while (i < maxAssignments) {
            final Assignment assignment = config.getRandomAssignment(random, this.getLevel());
            if (assignment == null) {
                continue;
            }
            if (!this.isAssignmentInList(assignment.getType(), config)) {
                assignments.put(assignment.getId(), new AssignmentData(assignment.getId()));
            }
            i = assignments.size();
        }
    }
    
    private boolean isAssignmentInList(final AssignmentType type, final AssignmentConfig config) {
        final HashMap<String, AssignmentData> assignments = (HashMap<String, AssignmentData>)this.getAssignmentData().getAssignments();
        for (final Map.Entry<String, AssignmentData> entry : assignments.entrySet()) {
            final AssignmentData data = entry.getValue();
            final Optional<Assignment> result = config.findAssignmentById(data.getAssignmentId());
            if (!result.isPresent()) {
                continue;
            }
            final Assignment assignment = result.get();
            if (assignment.getType() == type) {
                return true;
            }
        }
        return false;
    }
    
    public Optional<Assignment> findAssignmentById(final String id) {
        return AssignmentConfig.get().findAssignmentById(id);
    }
    
    public int setHappiness(final EntityPlayer player, final int happiness) {
        PetStatChangeEvent.call(player, UpdateStatType.HAPPINESS);
        if (happiness <= 0) {
            return this.happiness = 0;
        }
        final int maxHappiness = this.getMaxHappiness();
        if (happiness > this.getMaxHappiness()) {
            return this.happiness = maxHappiness;
        }
        return this.happiness = happiness;
    }
    
    public void earnHappiness(final EntityPlayerMP player, final int amount) {
        if (amount <= 0) {
            PetLogger.error("Tried to earn negative happiness: " + amount);
            return;
        }
        final int maxHappiness = this.getMaxHappiness();
        if (this.happiness >= maxHappiness) {
            return;
        }
        final PetEarnHappinessEvent event = new PetEarnHappinessEvent((EntityPlayer)player, amount);
        if (MinecraftForge.EVENT_BUS.post((Event)event)) {
            return;
        }
        this.happiness += event.getAmount();
        if (this.happiness > maxHappiness) {
            this.happiness = maxHappiness;
        }
    }
    
    public void earnExperience(final EntityPlayer player, final PetExperienceSource source, final double amount) {
        if (amount <= 0.0) {
            PetLogger.error("Tried to earn negative experience: " + amount + " from source: " + source.name());
            return;
        }
        final PetEarnExperienceEvent event = new PetEarnExperienceEvent(player, source, amount);
        if (MinecraftForge.EVENT_BUS.post((Event)event)) {
            return;
        }
        final int currentLevel = this.getLevel();
        final int oldSlots = this.getSlots(currentLevel);
        this.experience += event.getAmount();
        final int newLevel = this.getLevel();
        final int newSlots = this.getSlots(newLevel);
        if (!this.hasLevelUp(currentLevel, newLevel)) {
            return;
        }
        MinecraftForge.EVENT_BUS.post((Event)new PetLevelUpEvent(player, source, currentLevel, newLevel, oldSlots, newSlots));
        this.getSkillData().refresh(this, player);
    }
    
    private boolean hasLevelUp(final int currentLevel, final int newLevel) {
        return newLevel > currentLevel;
    }
    
    public double getMaxExperience() {
        return this.getRequiredExperience(this.getMaxLevel());
    }
    
    public double getRequiredExperience(final int level) {
        if (level <= 0) {
            return 0.0;
        }
        return (level * level - 1) * (90.0 / level) + 300.0 + this.getRequiredExperience(level - 1);
    }
    
    public int getLevel() {
        int level = 0;
        while (this.getRequiredExperience(level) <= this.experience) {
            if (++level >= 100) {
                return 100;
            }
        }
        return level;
    }
    
    public int getMaxLevel() {
        return 100;
    }
    
    public double getSkillValue(final Skill skill) {
        if (skill == null) {
            return 0.0;
        }
        return skill.getValue() * this.getSkillMultiplier();
    }
    
    public double getSkillMultiplier() {
        return GlobalConfig.get().getHappinessMultiplier(this.getHappiness());
    }
    
    public int getMaxHappiness() {
        return GlobalConfig.get().getMaxHappiness(this.getLevel());
    }
    
    public double getExperienceByJobLevelUp(final int level) {
        if (level <= 0) {
            return 0.0;
        }
        return level / 2.0 * 50.0;
    }
    
    public int getSlots(final int level) {
        if (level < 5) {
            return 0;
        }
        final int slots = level / 5;
        return Math.min(slots, 20);
    }
    
    public int getRequiredLevelForSlot(final int index) {
        return (index + 1) * 5;
    }
    
    public boolean slotExist(final int level, final int slot) {
        return slot >= 0 && slot <= this.getSlots(level);
    }
    
    public void onPlayerLoggedIn(final EntityPlayerMP player) {
        final GlobalConfig config = GlobalConfig.get();
        final ZonedDateTime nowDate = TimeUtil.nowZoned();
        final ZonedDateTime lastResetDate = TimeUtil.fromLong(this.lastConnectionIncrement);
        final boolean isSameDay = nowDate.getDayOfYear() == lastResetDate.getDayOfYear();
        if (isSameDay) {
            return;
        }
        this.earnExperience((EntityPlayer)player, PetExperienceSource.CONNECTION, config.getExperiencePerConnection());
        this.lastConnectionIncrement = TimeUtils.now();
    }
    
    public SkillData getSkill(final int slot) {
        final Map<Integer, SkillData> skills = (Map<Integer, SkillData>)this.getSkillData().getSkills();
        if (skills == null) {
            return null;
        }
        return skills.get(slot);
    }
    
    public SkillRollData getSkillFromRoll(final int slot) {
        return this.getSkillRollData().get(this, slot);
    }
    
    public SkillData getSkill(final String id) {
        final HashMap<Integer, SkillData> skills = (HashMap<Integer, SkillData>)this.getSkillData().getSkills();
        if (skills == null) {
            return null;
        }
        for (final Map.Entry<Integer, SkillData> entry : skills.entrySet()) {
            final SkillData data = entry.getValue();
            if (data.getSkillId().equals(id)) {
                return data;
            }
        }
        return null;
    }
    
    public boolean isSkillSelected(final String skillName) {
        return skillName != null && this.getSkill(skillName) != null;
    }
    
    public boolean isSkillSelected(final Skill skill) {
        return skill != null && this.isSkillSelected(skill.getId());
    }
    
    public int getHappiness() {
        final int level = this.getLevel();
        final int maxHappiness = this.getMaxHappiness();
        final int maxLevel = this.getMaxLevel();
        if (level >= maxLevel) {
            return maxHappiness;
        }
        return Math.min(this.happiness, maxHappiness);
    }
    
    public boolean has() {
        return !StringUtils.isEmpty((CharSequence)this.unlockedSkin);
    }
    
    public void changePetName(final EntityPlayerMP player, final String name) {
        final int maxLen = GlobalConfig.get().getMaxPetNameLength();
        if (Strings.isNullOrEmpty(name) || name.length() > maxLen) {
            PetTranslateEnum.MESSAGE_PET_NAME_TOO_LONG.message((ICommandSender)player, new Object[] { maxLen });
            return;
        }
        PetTranslateEnum.MESSAGE_PET_NAME_CHANGED.message((ICommandSender)player, new Object[] { name });
        this.sync();
    }
    
    public void changePetSkin(final EntityPlayerMP player, final String skinId) {
        if (Strings.isNullOrEmpty(skinId) || !this.hasSkin((EntityPlayer)player, skinId)) {
            PetTranslateEnum.MESSAGE_PET_SKIN_CHANGED.message((ICommandSender)player, new Object[] { skinId });
            return;
        }
        this.currentSkin = skinId;
        PetTranslateEnum.MESSAGE_PET_SKIN_CHANGED.message((ICommandSender)player, new Object[] { PetSkinShopProvider.getInstance().getTranslatedSkinName((EntityPlayer)player, skinId) });
        this.sync();
    }
    
    public boolean hasSkin(final EntityPlayer player, final String skinId) {
        return PetSkinShopProvider.getInstance().getSkins(player, this).contains(skinId);
    }
    
    public void unlock(final EntityPlayerMP player, final String id) {
        if (Strings.isNullOrEmpty(id)) {
            return;
        }
        this.currentSkin = id;
        this.unlockedSkin = id;
        this.sync();
    }
    
    public AssignmentNBTData getAssignmentData() {
        if (this.assignmentData == null) {
            this.assignmentData = new AssignmentNBTData();
        }
        return this.assignmentData;
    }
    
    public SkillNBTData getSkillData() {
        if (this.skillData == null) {
            this.skillData = new SkillNBTData();
        }
        return this.skillData;
    }
    
    public SkillRollNBTData getSkillRollData() {
        if (this.skillRollData == null) {
            this.skillRollData = new SkillRollNBTData();
        }
        return this.skillRollData;
    }
    
    public void addExperience(final EntityPlayer player, final double value) {
        this.setExperience(player, this.experience + value);
    }
    
    public void setExperience(final EntityPlayer player, double value) {
        if (value <= 0.0) {
            value = 0.0;
        }
        final double maxExperience = this.getMaxExperience();
        value = Math.min(value, maxExperience);
        final int oldLevel = this.getLevel();
        final int oldSLots = this.getSlots(oldLevel);
        this.experience = value;
        final int newLevel = this.getLevel();
        final int newSlots = this.getSlots(newLevel);
        if (this.hasLevelUp(oldLevel, newLevel)) {
            this.getSkillData().refresh(this, player);
            MinecraftForge.EVENT_BUS.post((Event)new PetLevelUpEvent(player, PetExperienceSource.ADMIN, oldLevel, newLevel, oldSLots, newSlots));
        }
    }
    
    public void setLevel(final EntityPlayer player, final int value) {
        final double experience = this.getRequiredExperience(value - 1);
        final int oldLevel = this.getLevel();
        final int oldSlots = this.getSlots(oldLevel);
        this.experience = experience;
        final int newLevel = this.getLevel();
        final int newSlots = this.getSlots(newLevel);
        this.getSkillData().refresh(this, player);
        MinecraftForge.EVENT_BUS.post((Event)new PetLevelUpEvent(player, PetExperienceSource.ADMIN, oldLevel, newLevel, oldSlots, newSlots));
    }
    
    public boolean changeVisibility() {
        this.visible = !this.visible;
        this.sync();
        return this.visible;
    }
    
    public void reset() {
        this.experience = 0.0;
        this.happiness = 0;
        this.assignmentResetMillis = System.currentTimeMillis();
        this.currentSkin = null;
        this.unlockedSkin = null;
        this.getSkillData().getSkills().clear();
        this.getSkillRollData().getRolls(this).clear();
        this.sync();
    }
    
    public long getLastConnectionIncrement() {
        return this.lastConnectionIncrement;
    }
    
    public double getExperience() {
        return this.experience;
    }
    
    public long getAssignmentResetMillis() {
        return this.assignmentResetMillis;
    }
    
    public long getLastSkillUsage() {
        return this.lastSkillUsage;
    }
    
    public String getUnlockedSkin() {
        return this.unlockedSkin;
    }
    
    public String getCurrentSkin() {
        return this.currentSkin;
    }
    
    public boolean isVisible() {
        return this.visible;
    }
    
    public HashMap<String, Long> getSkillUsesMap() {
        return this.skillUsesMap;
    }
    
    public void setLastConnectionIncrement(final long lastConnectionIncrement) {
        this.lastConnectionIncrement = lastConnectionIncrement;
    }
    
    public void setExperience(final double experience) {
        this.experience = experience;
    }
    
    public void setAssignmentResetMillis(final long assignmentResetMillis) {
        this.assignmentResetMillis = assignmentResetMillis;
    }
    
    public void setHappiness(final int happiness) {
        this.happiness = happiness;
    }
    
    public void setLastSkillUsage(final long lastSkillUsage) {
        this.lastSkillUsage = lastSkillUsage;
    }
    
    public void setUnlockedSkin(final String unlockedSkin) {
        this.unlockedSkin = unlockedSkin;
    }
    
    public void setCurrentSkin(final String currentSkin) {
        this.currentSkin = currentSkin;
    }
    
    public void setVisible(final boolean visible) {
        this.visible = visible;
    }
    
    public void setAssignmentData(final AssignmentNBTData assignmentData) {
        this.assignmentData = assignmentData;
    }
    
    public void setSkillData(final SkillNBTData skillData) {
        this.skillData = skillData;
    }
    
    public void setSkillRollData(final SkillRollNBTData skillRollData) {
        this.skillRollData = skillRollData;
    }
}
