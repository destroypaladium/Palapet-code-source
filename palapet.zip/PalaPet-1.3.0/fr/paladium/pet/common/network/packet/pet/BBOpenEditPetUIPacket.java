//Decompiled by Procyon!

package fr.paladium.pet.common.network.packet.pet;

import fr.paladium.palaforgeutils.lib.packet.*;
import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.palaforgeutils.lib.packet.utils.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import cpw.mods.fml.relauncher.*;
import net.minecraft.client.*;
import fr.paladium.pet.client.ui.home.*;
import net.minecraft.client.gui.*;

public class BBOpenEditPetUIPacket extends ForgePacket
{
    @PacketData(PacketSide.SERVER)
    private HomeData data;
    
    public BBOpenEditPetUIPacket(final EntityPlayerMP player, final PetPlayer pet) {
        this.data = new HomeData(player, pet);
    }
    
    @SideOnly(Side.SERVER)
    public void processServer(final EntityPlayerMP player) {
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        if (pet == null || !pet.has()) {
            return;
        }
        PetCommonProxy.getInstance().getNetwork().sendTo((IMessage)new BBOpenEditPetUIPacket(player, pet), player);
    }
    
    @SideOnly(Side.CLIENT)
    public void processClient() {
        final Minecraft mc = Minecraft.func_71410_x();
        mc.func_147108_a((GuiScreen)new UIPetHome(this.data));
        if (mc.field_71462_r instanceof UIPetHome) {
            final UIPetHome ui = (UIPetHome)mc.field_71462_r;
            ui.openEditPetUI();
        }
    }
    
    public BBOpenEditPetUIPacket() {
    }
}
