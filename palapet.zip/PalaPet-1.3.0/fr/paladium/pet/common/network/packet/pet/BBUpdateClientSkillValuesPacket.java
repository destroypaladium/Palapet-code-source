//Decompiled by Procyon!

package fr.paladium.pet.common.network.packet.pet;

import fr.paladium.palaforgeutils.lib.packet.*;
import fr.paladium.palaforgeutils.lib.packet.utils.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.server.config.skill.*;
import fr.paladium.pet.common.network.data.additional.skill.*;
import fr.paladium.pet.server.skill.skill.*;
import java.util.*;
import fr.paladium.pet.common.*;
import net.minecraft.entity.player.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import cpw.mods.fml.relauncher.*;
import fr.paladium.pet.client.*;
import fr.paladium.pet.*;

public class BBUpdateClientSkillValuesPacket extends ForgePacket
{
    @PacketData(PacketSide.SERVER)
    private HashMap<String, Double> data;
    
    public BBUpdateClientSkillValuesPacket(final PetPlayer pet) {
        this.data = new HashMap<String, Double>();
        if (pet == null) {
            return;
        }
        final SkillConfig config = SkillConfig.get();
        for (final SkillData value : pet.getSkillData().getSkills().values()) {
            if (value.getSkillId().equals("no_skill")) {
                continue;
            }
            final Optional<Skill> result = config.findSkillById(value.getSkillId());
            if (!result.isPresent()) {
                continue;
            }
            final Skill skill = result.get();
            this.data.put(skill.getId(), skill.getPersonalValue(pet));
        }
    }
    
    @SideOnly(Side.SERVER)
    public void processServer(final EntityPlayerMP player) {
        PetCommonProxy.getInstance().getNetwork().sendTo((IMessage)new BBUpdateClientSkillValuesPacket(PetPlayer.get((EntityPlayer)player)), player);
    }
    
    @SideOnly(Side.CLIENT)
    public void processClient() {
        PetClientProxy.getInstance().setSkillValues((HashMap)this.data);
        PetLogger.info("Skill values updated" + this.data);
    }
    
    public BBUpdateClientSkillValuesPacket() {
    }
}
