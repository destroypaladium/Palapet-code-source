//Decompiled by Procyon!

package fr.paladium.pet.common.network.packet.skill;

import fr.paladium.palaforgeutils.lib.packet.*;
import fr.paladium.palaforgeutils.lib.packet.utils.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.command.*;
import fr.paladium.pet.server.config.skill.*;
import fr.paladium.pet.server.skill.skill.*;
import fr.paladium.pet.common.network.data.additional.roll.*;
import fr.paladium.pet.common.network.data.additional.skill.*;
import java.util.*;

public class CSActiveSpellPacket extends ForgePacket
{
    @PacketData
    private int slot;
    
    public void processServer(final EntityPlayerMP player) {
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        if (pet == null || !pet.has()) {
            PetTranslateEnum.MESSAGE_NO_FAMILIAR.message((ICommandSender)player);
            PetTranslateEnum.MESSAGE_NO_FAMILIAR.notification(player);
            return;
        }
        final SkillRollData rollData = pet.getSkillFromRoll(this.slot);
        if (rollData == null) {
            PetTranslateEnum.MESSAGE_NO_ACTIVE_SKILL_AT_SLOT.message((ICommandSender)player);
            PetTranslateEnum.MESSAGE_NO_ACTIVE_SKILL_AT_SLOT.notification(player);
            return;
        }
        final SkillData data = pet.getSkillData().get(rollData.getSkillId());
        final SkillConfig config = SkillConfig.get();
        final Optional<Skill> result = config.findSkillById(data.getSkillId());
        if (!result.isPresent()) {
            PetTranslateEnum.MESSAGE_NO_ACTIVE_SKILL_AT_SLOT.message((ICommandSender)player);
            PetTranslateEnum.MESSAGE_NO_ACTIVE_SKILL_AT_SLOT.notification(player);
            return;
        }
        final Skill skill = result.get();
        if (skill.getType() != SkillType.ACTIVE) {
            PetTranslateEnum.MESSAGE_NO_ACTIVE_SKILL_AT_SLOT.message((ICommandSender)player);
            PetTranslateEnum.MESSAGE_NO_ACTIVE_SKILL_AT_SLOT.notification(player);
            return;
        }
        skill.handle(player, pet, data);
        pet.sync();
    }
    
    public void processClient() {
    }
    
    public CSActiveSpellPacket(final int slot) {
        this.slot = slot;
    }
    
    public CSActiveSpellPacket() {
    }
}
