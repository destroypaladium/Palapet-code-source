//Decompiled by Procyon!

package fr.paladium.pet.common.network.packet.pet;

import fr.paladium.palaforgeutils.lib.packet.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.*;
import cpw.mods.fml.common.network.simpleimpl.*;

public class CSChangeSkinVisibilityPacket extends ForgePacket
{
    public void processServer(final EntityPlayerMP player) {
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        if (pet == null || !pet.has()) {
            return;
        }
        pet.changeVisibility();
        PetCommonProxy.getInstance().getNetwork().sendTo((IMessage)new BBOpenUIPacket(player, pet), player);
    }
    
    public void processClient() {
    }
}
