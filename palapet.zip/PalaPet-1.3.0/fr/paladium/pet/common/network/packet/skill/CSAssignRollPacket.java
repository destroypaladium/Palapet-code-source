//Decompiled by Procyon!

package fr.paladium.pet.common.network.packet.skill;

import fr.paladium.palaforgeutils.lib.packet.*;
import fr.paladium.palaforgeutils.lib.packet.utils.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.command.*;
import fr.paladium.pet.server.config.skill.*;
import fr.paladium.pet.server.skill.skill.*;
import java.util.*;

public class CSAssignRollPacket extends ForgePacket
{
    public static final String REMOVE_ID = "remove";
    @PacketData
    private int slot;
    @PacketData
    private String skillId;
    
    public void processServer(final EntityPlayerMP player) {
        if (this.slot < 0 || this.slot > 5) {
            return;
        }
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        if (pet == null || !pet.has()) {
            PetTranslateEnum.MESSAGE_NO_FAMILIAR.message((ICommandSender)player);
            PetTranslateEnum.MESSAGE_NO_FAMILIAR.notification(player);
            return;
        }
        if (this.skillId.equals("remove")) {
            if (pet.getSkillRollData().removeSkillRoll(this.slot)) {
                PetTranslateEnum.MESSAGE_SKILL_ROLL_REMOVED.message((ICommandSender)player, new Object[] { this.slot + 1 });
                PetTranslateEnum.MESSAGE_SKILL_ROLL_REMOVED.notification(player, new Object[] { this.slot + 1 });
            }
            return;
        }
        final SkillConfig config = SkillConfig.get();
        final Optional<Skill> result = config.findSkillById(this.skillId);
        if (!result.isPresent()) {
            PetTranslateEnum.MESSAGE_NO_SKILL.message((ICommandSender)player);
            PetTranslateEnum.MESSAGE_NO_SKILL.notification(player);
            return;
        }
        final Skill skill = result.get();
        if (!pet.isSkillSelected(skill)) {
            PetTranslateEnum.MESSAGE_SKILL_NOT_SELECTED.message((ICommandSender)player);
            PetTranslateEnum.MESSAGE_SKILL_NOT_SELECTED.notification(player);
            return;
        }
        pet.getSkillRollData().setSkillRoll(this.slot, skill);
        PetTranslateEnum.MESSAGE_SKILL_ROLL_SET_SUCCESS.message((ICommandSender)player, new Object[] { this.slot + 1, skill.getName((EntityPlayer)player) });
        PetTranslateEnum.MESSAGE_SKILL_ROLL_SET_SUCCESS.notification(player, new Object[] { this.slot + 1, skill.getName((EntityPlayer)player) });
    }
    
    public void processClient() {
    }
    
    public CSAssignRollPacket(final int slot, final String skillId) {
        this.slot = slot;
        this.skillId = skillId;
    }
    
    public CSAssignRollPacket() {
    }
}
