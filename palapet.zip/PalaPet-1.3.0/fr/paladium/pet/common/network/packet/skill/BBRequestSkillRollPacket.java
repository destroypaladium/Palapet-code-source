//Decompiled by Procyon!

package fr.paladium.pet.common.network.packet.skill;

import fr.paladium.palaforgeutils.lib.packet.*;
import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.palaforgeutils.lib.packet.utils.*;
import fr.paladium.pet.client.*;
import cpw.mods.fml.relauncher.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.server.config.skill.*;
import fr.paladium.pet.common.network.data.additional.roll.*;
import fr.paladium.pet.server.skill.skill.*;
import fr.paladium.pet.common.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import java.util.*;
import fr.paladium.pet.common.network.data.additional.skill.*;

public class BBRequestSkillRollPacket extends ForgePacket
{
    @PacketData
    private List<SkillRollSlotData> data;
    
    @SideOnly(Side.CLIENT)
    public void processClient() {
        if (this.data == null || this.data.isEmpty()) {
            this.data = new ArrayList<SkillRollSlotData>();
        }
        PetClientProxy.getInstance().setSkillRollSlots((List)this.data);
    }
    
    @SideOnly(Side.SERVER)
    public void processServer(final EntityPlayerMP player) {
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        if (pet == null || !pet.has()) {
            return;
        }
        final List<SkillRollData> rolls = (List<SkillRollData>)pet.getSkillRollData().getRolls(pet);
        final List<SkillRollSlotData> skillRollSlots = new ArrayList<SkillRollSlotData>();
        for (int i = 0; i < 6; ++i) {
            skillRollSlots.add(SkillRollSlotData.none(i));
        }
        int index = 0;
        final long now = System.currentTimeMillis();
        final SkillConfig config = SkillConfig.get();
        for (final SkillRollData roll : rolls) {
            if (index >= 6) {
                break;
            }
            final Optional<Skill> result = config.findSkillById(roll.getSkillId());
            if (result.isPresent()) {
                final Skill skill = result.get();
                final int slot = roll.getSlot();
                final SkillRollData skillRollData = pet.getSkillFromRoll(slot);
                if (skillRollData == null) {
                    continue;
                }
                final SkillData skillData = pet.getSkill(skillRollData.getSkillId());
                if (skillData == null) {
                    continue;
                }
                final boolean usageCooldown = skill.isOnCooldown(skill.getCooldown(now, skillData.getNextUseMillis()));
                skillRollSlots.set(index, SkillRollSlotData.from(roll.getSlot(), skill, usageCooldown));
            }
            ++index;
        }
        PetCommonProxy.getInstance().getNetwork().sendTo((IMessage)new BBRequestSkillRollPacket(skillRollSlots), player);
    }
    
    public BBRequestSkillRollPacket() {
    }
    
    public BBRequestSkillRollPacket(final List<SkillRollSlotData> data) {
        this.data = data;
    }
}
