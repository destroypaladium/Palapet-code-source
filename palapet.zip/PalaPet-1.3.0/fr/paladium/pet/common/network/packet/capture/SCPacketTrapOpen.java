//Decompiled by Procyon!

package fr.paladium.pet.common.network.packet.capture;

import fr.paladium.palaforgeutils.lib.packet.*;
import fr.paladium.pet.common.tile.cage.*;
import fr.paladium.palaforgeutils.lib.packet.utils.*;
import net.minecraft.client.*;
import fr.paladium.pet.common.capture.*;
import fr.paladium.pet.client.ui.capture.*;
import net.minecraft.client.gui.*;
import cpw.mods.fml.relauncher.*;
import net.minecraft.entity.player.*;

public class SCPacketTrapOpen extends ForgePacket
{
    @PacketData
    CageStatus status;
    @PacketData
    int x;
    @PacketData
    int y;
    @PacketData
    int z;
    
    @SideOnly(Side.CLIENT)
    public void processClient() {
        Minecraft.func_71410_x().func_147108_a((GuiScreen)new UICapture(CaptureManager.getInstance().getCategory(), this.status, this.x, this.y, this.z));
    }
    
    public void processServer(final EntityPlayerMP player) {
        super.processServer(player);
    }
    
    public SCPacketTrapOpen() {
    }
    
    public SCPacketTrapOpen(final CageStatus status, final int x, final int y, final int z) {
        this.status = status;
        this.x = x;
        this.y = y;
        this.z = z;
    }
}
