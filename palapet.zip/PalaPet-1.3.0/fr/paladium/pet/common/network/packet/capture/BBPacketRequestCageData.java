//Decompiled by Procyon!

package fr.paladium.pet.common.network.packet.capture;

import fr.paladium.palaforgeutils.lib.packet.*;
import fr.paladium.palaforgeutils.lib.packet.utils.*;
import fr.paladium.pet.client.renderer.*;
import fr.paladium.pet.client.renderer.data.*;
import fr.paladium.pet.client.ui.utils.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.tile.cage.*;
import fr.paladium.pet.common.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import net.minecraft.world.*;
import net.minecraft.tileentity.*;

public class BBPacketRequestCageData extends ForgePacket
{
    @PacketData
    private IntLocation location;
    @PacketData
    private String skinId;
    @PacketData
    private CageRenderState state;
    
    public BBPacketRequestCageData(final IntLocation location) {
        this.location = location;
    }
    
    public void processClient() {
        if (TileEntityPetCageRenderer.DATAS.get(this.location) == null) {
            return;
        }
        final CageRenderData data = TileEntityPetCageRenderer.DATAS.get(this.location);
        if (data.getEntityPet() == null) {
            data.setEntityPet(PetRenderUtils.getPetFromEnum(this.skinId));
        }
        else {
            data.getEntityPet().setSkinId(this.skinId);
        }
        data.setState(this.state);
    }
    
    public void processServer(final EntityPlayerMP player) {
        if (this.location == null) {
            return;
        }
        final World world = player.field_70170_p;
        if (!world.func_72899_e(this.location.getX(), this.location.getY(), this.location.getZ())) {
            return;
        }
        final TileEntity tileEntity = world.func_147438_o(this.location.getX(), this.location.getY(), this.location.getZ());
        if (!(tileEntity instanceof TileEntityPetCage)) {
            return;
        }
        final TileEntityPetCage cage = (TileEntityPetCage)tileEntity;
        PetCommonProxy.getInstance().getNetwork().sendTo((IMessage)new BBPacketRequestCageData(this.location, cage.getPet(), CageRenderState.of(cage.getStatus())), player);
    }
    
    public BBPacketRequestCageData() {
    }
    
    public BBPacketRequestCageData(final IntLocation location, final String skinId, final CageRenderState state) {
        this.location = location;
        this.skinId = skinId;
        this.state = state;
    }
}
