//Decompiled by Procyon!

package fr.paladium.pet.common.network.packet.skill.breakspeed;

import fr.paladium.palaforgeutils.lib.packet.*;
import fr.paladium.palaforgeutils.lib.packet.utils.*;
import fr.paladium.pet.client.data.*;

public class SCGlobalBreakSpeedPacket extends ForgePacket
{
    @PacketData
    double value;
    @PacketData
    long duration;
    
    public void processClient() {
        ClientBreakSpeedData.get().updateGlobalBreakSpeed(this.value, this.duration);
    }
    
    public SCGlobalBreakSpeedPacket() {
    }
    
    public SCGlobalBreakSpeedPacket(final double value, final long duration) {
        this.value = value;
        this.duration = duration;
    }
}
