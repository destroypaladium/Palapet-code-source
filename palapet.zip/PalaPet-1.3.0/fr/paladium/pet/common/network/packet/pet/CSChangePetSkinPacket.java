//Decompiled by Procyon!

package fr.paladium.pet.common.network.packet.pet;

import fr.paladium.palaforgeutils.lib.packet.*;
import fr.paladium.palaforgeutils.lib.packet.utils.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;

public class CSChangePetSkinPacket extends ForgePacket
{
    @PacketData
    private String id;
    
    public void processServer(final EntityPlayerMP player) {
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        if (pet == null || !pet.has()) {
            return;
        }
        pet.changePetSkin(player, this.id);
    }
    
    public void processClient() {
    }
    
    public CSChangePetSkinPacket() {
    }
    
    public CSChangePetSkinPacket(final String id) {
        this.id = id;
    }
}
