//Decompiled by Procyon!

package fr.paladium.pet.common.network.packet.pet;

import fr.paladium.palaforgeutils.lib.packet.*;
import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.palaforgeutils.lib.packet.utils.*;
import fr.paladium.pet.server.config.global.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import cpw.mods.fml.relauncher.*;

public class BBUpdateClientConfigPacket extends ForgePacket
{
    @PacketData(PacketSide.SERVER)
    private ConfigClientData data;
    
    public BBUpdateClientConfigPacket(final GlobalConfig config) {
        this.data = ConfigClientData.of(config);
    }
    
    @SideOnly(Side.SERVER)
    public void processServer(final EntityPlayerMP player) {
        PetCommonProxy.getInstance().getNetwork().sendTo((IMessage)new BBUpdateClientConfigPacket(GlobalConfig.get()), player);
    }
    
    @SideOnly(Side.CLIENT)
    public void processClient() {
        ConfigClientData.set(this.data);
    }
    
    public BBUpdateClientConfigPacket() {
    }
}
