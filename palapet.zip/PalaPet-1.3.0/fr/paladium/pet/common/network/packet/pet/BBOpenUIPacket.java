//Decompiled by Procyon!

package fr.paladium.pet.common.network.packet.pet;

import fr.paladium.palaforgeutils.lib.packet.*;
import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.palaforgeutils.lib.packet.utils.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import cpw.mods.fml.relauncher.*;
import net.minecraft.client.*;
import fr.paladium.pet.client.ui.home.*;
import net.minecraft.client.gui.*;

public class BBOpenUIPacket extends ForgePacket
{
    @PacketData(PacketSide.SERVER)
    private HomeData data;
    
    public BBOpenUIPacket(final EntityPlayerMP player, final PetPlayer pet) {
        this.data = new HomeData(player, pet);
    }
    
    @SideOnly(Side.SERVER)
    public void processServer(final EntityPlayerMP player) {
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        if (pet == null || !pet.has()) {
            return;
        }
        PetCommonProxy.getInstance().getNetwork().sendTo((IMessage)new BBOpenUIPacket(player, pet), player);
    }
    
    @SideOnly(Side.CLIENT)
    public void processClient() {
        final Minecraft mc = Minecraft.func_71410_x();
        mc.func_147108_a((GuiScreen)new UIPetHome(this.data));
    }
    
    public BBOpenUIPacket() {
    }
}
