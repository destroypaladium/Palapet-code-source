//Decompiled by Procyon!

package fr.paladium.pet.common.network.packet.capture;

import fr.paladium.palaforgeutils.lib.packet.*;
import fr.paladium.palaforgeutils.lib.packet.utils.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.capture.*;
import fr.paladium.pet.common.block.*;
import net.minecraft.world.*;
import net.minecraft.block.*;

public class CSPacketTrapInteraction extends ForgePacket
{
    @PacketData
    int score;
    @PacketData
    int x;
    @PacketData
    int y;
    @PacketData
    int z;
    
    public void processServer(final EntityPlayerMP player) {
        final World world = player.field_70170_p;
        if (!CaptureManager.getInstance().isValidScore(this.score)) {
            return;
        }
        if (!world.func_72899_e(this.x, this.y, this.z)) {
            return;
        }
        final Block block = world.func_147439_a(this.x, this.y, this.z);
        if (!(block instanceof BlockPetCage)) {
            return;
        }
        final BlockPetCage cage = (BlockPetCage)block;
        cage.handlePacket(player, this.score, world, this.x, this.y, this.z);
    }
    
    public CSPacketTrapInteraction() {
    }
    
    public CSPacketTrapInteraction(final int score, final int x, final int y, final int z) {
        this.score = score;
        this.x = x;
        this.y = y;
        this.z = z;
    }
}
