//Decompiled by Procyon!

package fr.paladium.pet.common.network.packet.pet;

import fr.paladium.palaforgeutils.lib.packet.*;
import java.util.*;
import fr.paladium.pet.client.ui.utils.data.*;
import fr.paladium.palaforgeutils.lib.packet.utils.*;
import net.minecraft.entity.player.*;
import cpw.mods.fml.relauncher.*;
import net.minecraft.client.*;
import fr.paladium.pet.client.ui.debug.*;
import net.minecraft.client.gui.*;

public class SCOpenDebugUIPacket extends ForgePacket
{
    @PacketData(PacketSide.SERVER)
    private List<AssignmentClientData> assignments;
    
    @SideOnly(Side.SERVER)
    public void processServer(final EntityPlayerMP player) {
    }
    
    @SideOnly(Side.CLIENT)
    public void processClient() {
        final Minecraft mc = Minecraft.func_71410_x();
        mc.func_147108_a((GuiScreen)new UIDebugAssignment((List)this.assignments));
    }
    
    public SCOpenDebugUIPacket(final List<AssignmentClientData> assignments) {
        this.assignments = assignments;
    }
    
    public SCOpenDebugUIPacket() {
    }
}
