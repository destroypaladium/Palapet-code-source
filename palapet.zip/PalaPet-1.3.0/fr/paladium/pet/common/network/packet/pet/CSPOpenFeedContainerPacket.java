//Decompiled by Procyon!

package fr.paladium.pet.common.network.packet.pet;

import fr.paladium.palaforgeutils.lib.packet.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.handler.*;

public class CSPOpenFeedContainerPacket extends ForgePacket
{
    public void processClient() {
    }
    
    public void processServer(final EntityPlayerMP player) {
        FeedPetGuiHandler.open(player);
    }
}
