//Decompiled by Procyon!

package fr.paladium.pet.common.network.packet.skill;

import fr.paladium.palaforgeutils.lib.packet.*;
import fr.paladium.palaforgeutils.lib.packet.utils.*;
import fr.paladium.pet.common.network.data.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.constant.*;
import net.minecraft.command.*;
import fr.paladium.pet.server.skill.*;
import fr.paladium.palaforgeutils.lib.task.*;
import fr.paladium.pet.server.config.skill.*;
import fr.paladium.pet.server.skill.skill.*;
import fr.paladium.pet.common.event.skill.*;
import net.minecraftforge.common.*;
import cpw.mods.fml.common.eventhandler.*;
import fr.paladium.pet.common.network.data.additional.skill.*;
import java.util.*;

public class CSAssignSkillPacket extends ForgePacket
{
    @PacketData
    private int slot;
    @PacketData
    private String skillId;
    
    public void processServer(final EntityPlayerMP player) {
        final PetPlayer pet = PetPlayer.get((EntityPlayer)player);
        if (pet == null || !pet.has()) {
            PetTranslateEnum.MESSAGE_NO_FAMILIAR.message((ICommandSender)player);
            PetTranslateEnum.MESSAGE_NO_FAMILIAR.notification(player);
            return;
        }
        final long now = System.currentTimeMillis();
        final SkillData data = pet.getSkill(this.slot);
        if (data == null || this.skillId == null) {
            PetTranslateEnum.MESSAGE_NO_SLOT.message((ICommandSender)player);
            PetTranslateEnum.MESSAGE_NO_SLOT.notification(player);
            return;
        }
        final long changeCooldown = data.getChangeCooldown(player, now);
        if (!SkillManager.getInstance().isBypassed((EntityPlayer)player) && !data.canChangeSlot(changeCooldown)) {
            PetTranslateEnum.MESSAGE_CHANGE_SKILL_COOLDOWN.message((ICommandSender)player, new Object[] { DurationConverter.fromMillisToString(changeCooldown) });
            PetTranslateEnum.MESSAGE_CHANGE_SKILL_COOLDOWN.notification(player, new Object[] { DurationConverter.fromMillisToString(changeCooldown) });
            return;
        }
        final SkillConfig config = SkillConfig.get();
        final Optional<Skill> result = config.findSkillById(this.skillId);
        if (!result.isPresent()) {
            PetTranslateEnum.MESSAGE_NO_SKILL.message((ICommandSender)player);
            PetTranslateEnum.MESSAGE_NO_SKILL.notification(player);
            return;
        }
        final Skill skill = result.get();
        if (skill.getType() == SkillType.ACTIVE) {
            final Optional<Skill> oldSkill = config.findSkillById(data.getSkillId());
            if (!oldSkill.isPresent() || oldSkill.get().getType() != SkillType.ACTIVE) {
                final HashMap<SkillType, Integer> slots = config.getSkillCount(pet);
                final int activeCount = slots.getOrDefault(SkillType.ACTIVE, 0);
                if (activeCount >= config.getMaxActiveSkills()) {
                    PetTranslateEnum.MESSAGE_MAX_ACTIVE_SKILLS.message((ICommandSender)player, new Object[] { config.getMaxActiveSkills() });
                    PetTranslateEnum.MESSAGE_MAX_ACTIVE_SKILLS.notification(player, new Object[] { config.getMaxActiveSkills() });
                    return;
                }
            }
        }
        final int level = pet.getLevel();
        if (!skill.hasRequiredLevel(level)) {
            PetTranslateEnum.MESSAGE_SKILL_REQUIRED_LEVEL.message((ICommandSender)player, new Object[] { skill.getRequiredLevel() });
            PetTranslateEnum.MESSAGE_SKILL_REQUIRED_LEVEL.notification(player, new Object[] { skill.getRequiredLevel() });
            return;
        }
        if (pet.isSkillSelected(skill)) {
            PetTranslateEnum.MESSAGE_SKILL_ALREADY_SELECTED.message((ICommandSender)player);
            PetTranslateEnum.MESSAGE_SKILL_ALREADY_SELECTED.notification(player);
            return;
        }
        if (SkillManager.getInstance().isBypassed((EntityPlayer)player)) {
            data.changeSlotBypass(skill);
        }
        else {
            data.changeSlot(skill, pet.getNextSkillUsage(skill));
        }
        PetTranslateEnum.MESSAGE_CHANGE_SKILL.message((ICommandSender)player, new Object[] { this.slot + 1, skill.getName((EntityPlayer)player) });
        PetTranslateEnum.MESSAGE_CHANGE_SKILL.notification(player, new Object[] { this.slot + 1, skill.getName((EntityPlayer)player) });
        final AssignSkillEvent event = new AssignSkillEvent((EntityPlayer)player, pet, skill);
        MinecraftForge.EVENT_BUS.post((Event)event);
    }
    
    public void processClient() {
    }
    
    public CSAssignSkillPacket(final int slot, final String skillId) {
        this.slot = slot;
        this.skillId = skillId;
    }
    
    public CSAssignSkillPacket() {
    }
}
