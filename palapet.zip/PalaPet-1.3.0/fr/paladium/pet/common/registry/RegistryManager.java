//Decompiled by Procyon!

package fr.paladium.pet.common.registry;

import java.util.*;
import fr.paladium.pet.common.registry.impl.*;

public class RegistryManager
{
    private static RegistryManager instance;
    private final List<IRegistry> registries;
    
    public RegistryManager() {
        RegistryManager.instance = this;
        this.registries = new ArrayList<IRegistry>();
        this.register((IRegistry)new PetItemRegistry());
        this.register((IRegistry)new PetBlockRegistry());
    }
    
    public static RegistryManager getInstance() {
        if (RegistryManager.instance == null) {
            RegistryManager.instance = new RegistryManager();
        }
        return RegistryManager.instance;
    }
    
    public void register(final IRegistry registry) {
        if (this.registries.contains(registry)) {
            throw new IllegalArgumentException("Registry already registered");
        }
        this.registries.add(registry);
    }
    
    public List<IRegistry> getRegistries() {
        return this.registries;
    }
}
