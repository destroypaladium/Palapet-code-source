//Decompiled by Procyon!

package fr.paladium.pet.common.registry;

import cpw.mods.fml.common.event.*;

public interface IRegistry
{
    void onPreInit(final FMLPreInitializationEvent p0);
    
    void onInit(final FMLInitializationEvent p0);
    
    void onPostInit(final FMLPostInitializationEvent p0);
    
    void onServerStarting(final FMLServerStartingEvent p0);
    
    void onServerStarted(final FMLServerStartedEvent p0);
}
