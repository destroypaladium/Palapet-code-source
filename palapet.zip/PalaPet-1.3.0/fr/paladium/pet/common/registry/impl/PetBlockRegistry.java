//Decompiled by Procyon!

package fr.paladium.pet.common.registry.impl;

import fr.paladium.pet.common.registry.*;
import fr.paladium.pet.common.block.*;
import net.minecraft.block.*;
import fr.paladium.palaforgeutils.lib.registry.*;
import cpw.mods.fml.common.event.*;

public class PetBlockRegistry implements IRegistry
{
    public static BlockPetCage PET_CAGE;
    
    @Override
    public void onPreInit(final FMLPreInitializationEvent event) {
        RegistryUtils.block(new Block[] { (Block)(PetBlockRegistry.PET_CAGE = new BlockPetCage()) });
    }
    
    @Override
    public void onInit(final FMLInitializationEvent event) {
    }
    
    @Override
    public void onPostInit(final FMLPostInitializationEvent event) {
    }
    
    @Override
    public void onServerStarting(final FMLServerStartingEvent event) {
    }
    
    @Override
    public void onServerStarted(final FMLServerStartedEvent event) {
    }
}
