//Decompiled by Procyon!

package fr.paladium.pet.common.registry.impl;

import fr.paladium.pet.common.registry.*;
import fr.paladium.pet.common.item.*;
import net.minecraft.item.*;
import fr.paladium.palaforgeutils.lib.registry.*;
import cpw.mods.fml.common.event.*;

public class PetItemRegistry implements IRegistry
{
    public static ItemBait BAIT;
    
    @Override
    public void onPreInit(final FMLPreInitializationEvent event) {
        RegistryUtils.item(new Item[] { (Item)(PetItemRegistry.BAIT = new ItemBait()) });
    }
    
    @Override
    public void onInit(final FMLInitializationEvent event) {
    }
    
    @Override
    public void onPostInit(final FMLPostInitializationEvent event) {
    }
    
    @Override
    public void onServerStarting(final FMLServerStartingEvent event) {
    }
    
    @Override
    public void onServerStarted(final FMLServerStartedEvent event) {
    }
}
