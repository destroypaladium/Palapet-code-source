//Decompiled by Procyon!

package fr.paladium.pet.common.utils;

import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import net.minecraftforge.common.*;
import net.minecraftforge.event.entity.player.*;
import cpw.mods.fml.common.eventhandler.*;

public class ItemUtils
{
    public static ItemStack decrementCurrentItem(final EntityPlayer player, final ItemStack stack) {
        --stack.field_77994_a;
        if (stack.field_77994_a <= 0) {
            player.field_71071_by.field_70462_a[player.field_71071_by.field_70461_c] = null;
            MinecraftForge.EVENT_BUS.post((Event)new PlayerDestroyItemEvent(player, stack));
            return null;
        }
        return stack;
    }
}
