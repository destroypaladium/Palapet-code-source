//Decompiled by Procyon!

package fr.paladium.pet.common.utils;

import java.util.*;
import java.io.*;
import java.net.*;

public class ClassUtils
{
    public static List<Class<?>> getClasses(final String packageName) throws Exception {
        final ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        final String path = packageName.replace('.', '/');
        final List<Class<?>> classes = new ArrayList<Class<?>>();
        final URL resource = classLoader.getResource(path);
        if (resource == null) {
            throw new IllegalArgumentException("Package " + packageName + " not found");
        }
        final String resourcePath = resource.getPath();
        final File directory = new File(resourcePath);
        if (directory.exists()) {
            final String[] list;
            final String[] files = list = directory.list();
            for (final String file : list) {
                if (file.endsWith(".class")) {
                    final String className = packageName + '.' + file.substring(0, file.length() - 6);
                    classes.add(Class.forName(className));
                }
            }
        }
        return classes;
    }
}
