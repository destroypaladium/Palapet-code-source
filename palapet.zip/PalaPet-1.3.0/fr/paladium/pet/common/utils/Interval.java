//Decompiled by Procyon!

package fr.paladium.pet.common.utils;

public class Interval
{
    private float min;
    private float max;
    
    public Interval(final float min, final float max) {
        this.min = Math.min(min, max);
        this.max = Math.max(max, min);
    }
    
    public static Interval of(final float min, final float max) {
        return new Interval(min, max);
    }
    
    public boolean isInRange(final float value) {
        return value >= this.min && value <= this.max;
    }
    
    public float getRandom() {
        return (float)(Math.random() * (this.max - this.min + 1.0f) + this.min);
    }
    
    public boolean isInferiorOrEquals(final float target) {
        final float generated = this.getRandom();
        return generated <= target;
    }
    
    public Interval multiply(final float value) {
        this.min *= value;
        this.max *= value;
        return this;
    }
    
    public float getMin() {
        return this.min;
    }
    
    public float getMax() {
        return this.max;
    }
    
    public void setMin(final float min) {
        this.min = min;
    }
    
    public void setMax(final float max) {
        this.max = max;
    }
}
