//Decompiled by Procyon!

package fr.paladium.pet.common.utils;

import java.io.*;
import net.minecraft.util.*;
import java.util.*;
import java.util.function.*;

public class FileLoaderUtils
{
    public static List<ResourceLocation> getResources(final String domain, final String folder, final String extension, final File modDirectory) {
        final List<ResourceLocation> files = new ArrayList<ResourceLocation>();
        enumerateFiles(modDirectory, folder, name -> name.endsWith(extension), files, domain);
        return files;
    }
    
    private static void enumerateFiles(final File parent, final String folder, final Predicate<String> predicate, final List<ResourceLocation> locations, final String domain) {
        final File folderFile = new File(parent, folder);
        if (!folderFile.exists() || !folderFile.isDirectory()) {
            return;
        }
        final File[] files = folderFile.listFiles();
        if (files == null) {
            return;
        }
        for (final File file : files) {
            if (file.isFile() && predicate.test(file.getName())) {
                locations.add(new ResourceLocation(domain, folder + "/" + file.getName()));
            }
            else if (file.isDirectory()) {
                enumerateFiles(file, folder + "/" + file.getName(), predicate, locations, domain);
            }
        }
    }
}
