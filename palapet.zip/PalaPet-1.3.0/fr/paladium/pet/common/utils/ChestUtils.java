//Decompiled by Procyon!

package fr.paladium.pet.common.utils;

import net.minecraft.world.*;
import net.minecraft.item.*;
import net.minecraft.tileentity.*;

public class ChestUtils
{
    public static boolean fillChest(final World world, final int x, final int y, final int z, final ItemStack... items) {
        return fillChest(world, x, y, z, true, items);
    }
    
    public static boolean fillChest(final TileEntityChest chest, final ItemStack... items) {
        return fillChest(chest, true, items);
    }
    
    public static boolean fillChest(final World world, final int x, final int y, final int z, final boolean clear, final ItemStack... items) {
        final TileEntity tileEntity = world.func_147438_o(x, y, z);
        return tileEntity instanceof TileEntityChest && fillChest((TileEntityChest)tileEntity, clear, items);
    }
    
    public static boolean fillChest(final TileEntityChest chest, final boolean clear, final ItemStack... items) {
        if (clear) {
            for (int i = 0; i < chest.func_70302_i_(); ++i) {
                chest.func_70299_a(i, (ItemStack)null);
            }
        }
        for (int i = 0; i < items.length; ++i) {
            final ItemStack item = items[i];
            if (item != null) {
                chest.func_70299_a(i, item.func_77946_l());
            }
        }
        chest.func_70296_d();
        return true;
    }
}
