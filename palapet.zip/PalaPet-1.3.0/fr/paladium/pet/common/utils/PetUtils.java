//Decompiled by Procyon!

package fr.paladium.pet.common.utils;

import java.util.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import fr.paladium.palajobs.core.network.data.*;
import net.minecraft.entity.*;
import fr.paladium.palajobs.server.managers.*;
import fr.paladium.palajobs.core.jobs.*;
import net.minecraft.block.*;
import net.minecraft.init.*;
import net.minecraftforge.event.world.*;
import cpw.mods.fml.common.eventhandler.*;
import net.minecraftforge.common.*;
import net.minecraft.command.*;
import fr.paladium.pet.common.constant.*;
import fr.paladium.translate.common.texttotranslate.*;
import net.md_5.bungee.api.*;
import net.minecraft.util.*;

public class PetUtils
{
    public static final char COLOR_CHAR = '&';
    public static boolean aprilFool;
    
    public static void initAprilFool() {
        final Calendar calendar = Calendar.getInstance();
        PetUtils.aprilFool = (calendar.get(2) == 2 && calendar.get(5) == 26);
    }
    
    public static double getValueAsPercent(final double value) {
        if (value < 0.0) {
            return 0.0;
        }
        return value / 100.0;
    }
    
    public static boolean canUseCraft(final EntityPlayer player, final ItemStack stack) {
        final JobsPlayer data = JobsPlayer.get((Entity)player);
        if (data == null) {
            return false;
        }
        final BlackListedItem canUse = JobsManager.getInstance().canUseCraft(player, data, stack);
        return canUse == null;
    }
    
    public static boolean canInteract(final EntityPlayer player, final int x, final int y, final int z) {
        return canInteract(player, player.field_70170_p.func_147439_a(x, y, z), x, y, z);
    }
    
    public static boolean canInteract(final EntityPlayer player, final Block block, final int x, final int y, final int z) {
        if (y < 0 || y > 256) {
            return false;
        }
        if (block == Blocks.field_150357_h) {
            return false;
        }
        final BlockEvent.BreakEvent event = new BlockEvent.BreakEvent(x, y, z, player.field_70170_p, Blocks.field_150350_a, 0, player);
        event.setResult(Event.Result.DENY);
        MinecraftForge.EVENT_BUS.post((Event)event);
        return !event.isCanceled();
    }
    
    public static boolean canInteractBedrock(final EntityPlayer player, final int x, final int y, final int z) {
        if (y <= 0 || y > 256) {
            return false;
        }
        final BlockEvent.BreakEvent event = new BlockEvent.BreakEvent(x, y, z, player.field_70170_p, Blocks.field_150350_a, 0, player);
        event.setResult(Event.Result.DENY);
        MinecraftForge.EVENT_BUS.post((Event)event);
        return !event.isCanceled();
    }
    
    public static void sendPrefixedMessage(final ICommandSender sender, final String... messages) {
        if (sender == null || messages == null) {
            return;
        }
        if (messages.length == 0) {
            return;
        }
        sender.func_145747_a((IChatComponent)new ChatComponentText(TTT.format(PetTranslateEnum.MESSAGE_PREFIX.getId(), new Object[0]) + ChatColor.translateAlternateColorCodes('&', messages[0])));
        for (int i = 1; i < messages.length; ++i) {
            sender.func_145747_a((IChatComponent)new ChatComponentText(ChatColor.translateAlternateColorCodes('&', messages[i])));
        }
    }
    
    static {
        PetUtils.aprilFool = false;
    }
}
