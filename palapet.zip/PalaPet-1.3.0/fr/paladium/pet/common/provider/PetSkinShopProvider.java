//Decompiled by Procyon!

package fr.paladium.pet.common.provider;

import fr.paladium.shop.common.provider.*;
import net.minecraft.entity.player.*;
import fr.paladium.shop.server.api.pojo.usershop.*;
import fr.paladium.shop.*;
import fr.paladium.pet.client.renderer.shop.*;
import fr.paladium.shop.server.api.pojo.shop.*;
import net.minecraft.entity.*;
import org.bson.*;
import cpw.mods.fml.relauncher.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.common.*;
import java.util.*;
import fr.paladium.pet.common.utils.*;
import net.minecraft.command.*;
import fr.paladium.pet.*;
import fr.paladium.pet.common.pet.*;
import fr.paladium.palaforgeutils.lib.java.map.player.*;
import fr.paladium.pet.server.*;
import fr.paladium.translate.common.texttotranslate.*;

public class PetSkinShopProvider extends ShopProvider
{
    public static final String SKINS_TAG = "skins";
    private static PetSkinShopProvider instance;
    
    public void load(final EntityPlayer player, final UserShop user) {
        this.importData(player);
    }
    
    public void provide(final ShopMod mod, final Side side) {
        PetSkinShopProvider.instance = this;
        if (side == Side.CLIENT) {
            this.render(new Class[] { PetRenderItemRenderer.class });
        }
    }
    
    public void buy(final EntityPlayer player, final ShopItem item) {
    }
    
    @SideOnly(Side.SERVER)
    public void importData(final EntityPlayer player) {
        final Document data = this.getData(player);
        if (data.containsKey((Object)"skins")) {
            final List<String> skins = (List<String>)data.get((Object)"skins", (Class)List.class);
            this.getPlayerSkinsMap().put((Entity)player, (Object)new HashSet(skins));
        }
    }
    
    public HashSet<String> getSkins(final EntityPlayer player, final PetPlayer pet) {
        final UUID uniqueId = player.func_110124_au();
        if (!this.getPlayerSkinsMap().containsKey(uniqueId)) {
            return new HashSet<String>();
        }
        final HashSet<String> skins = new HashSet<String>((Collection<? extends String>)this.getPlayerSkinsMap().get(uniqueId));
        if (pet.getUnlockedSkin() != null) {
            skins.add(pet.getUnlockedSkin());
        }
        return skins;
    }
    
    @SideOnly(Side.SERVER)
    public void addSkin(final EntityPlayer player, final String id) {
        final PetAdditionalData petData = PetCommonProxy.getInstance().findPet(id);
        if (petData == null) {
            return;
        }
        final Document data = this.getData(player);
        List<String> skins;
        if (data.containsKey((Object)"skins")) {
            skins = (List<String>)data.get((Object)"skins", (Class)List.class);
        }
        else {
            skins = new ArrayList<String>();
        }
        skins.add(petData.getName());
        data.append("skins", (Object)skins);
        this.getPlayerSkinsMap().put((Entity)player, (Object)new HashSet(skins));
        final PetAdditionalData petAdditionalData;
        final Object obj;
        this.setData(player, data, user -> {
            PetUtils.sendPrefixedMessage((ICommandSender)player, "�7[�a+�7] �e" + this.getTranslatedSkinName(player, petAdditionalData.getName()));
            PetLogger.info("Skin " + petAdditionalData.getName() + " added to " + player.func_110124_au() + " currentSkins: " + obj);
        });
    }
    
    @SideOnly(Side.SERVER)
    public void clearSkins(final EntityPlayer player) {
        final Document data = this.getData(player);
        if (data.containsKey((Object)"skins")) {
            ((List)data.get((Object)"skins", (Class)List.class)).clear();
        }
        this.getPlayerSkinsMap().put((Entity)player, (Object)new HashSet());
        this.setData(player, data, user -> {
            PetUtils.sendPrefixedMessage((ICommandSender)player, "�7[�c-�7] �eALL");
            PetLogger.info("All skins removed from " + player.func_110124_au());
        });
    }
    
    @SideOnly(Side.SERVER)
    private SessionPlayerMap<HashSet<String>> getPlayerSkinsMap() {
        return PetServerProxy.getInstance().getPlayerSkinsMap();
    }
    
    public String getTranslatedSkinName(final String skinId) {
        return this.getTranslatedSkinName(null, skinId);
    }
    
    public String getTranslatedSkinName(final EntityPlayer player, final String skinId) {
        final PetAdditionalData petData = PetCommonProxy.getInstance().findPet(skinId);
        if (petData == null) {
            return skinId;
        }
        return TTT.format(player, this.getTTTSkinKey(skinId), new Object[0]);
    }
    
    private String getTTTSkinKey(final String skinId) {
        return "shop.pet." + skinId + ".name";
    }
    
    public static PetSkinShopProvider getInstance() {
        return PetSkinShopProvider.instance;
    }
}
