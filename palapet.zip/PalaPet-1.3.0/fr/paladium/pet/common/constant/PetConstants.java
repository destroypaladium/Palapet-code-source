//Decompiled by Procyon!

package fr.paladium.pet.common.constant;

public class PetConstants
{
    public static final String MOD_ID = "palapet";
    public static final String TEXTURE_PATH = "palapet:";
    public static final String VERSION = "1.0.0";
}
