//Decompiled by Procyon!

package fr.paladium.pet.common.pet;

public class ElementPosition
{
    private double x;
    private double y;
    private double z;
    
    public static ElementPosition of(final double x, final double y, final double z) {
        return new ElementPosition(x, y, z);
    }
    
    @Override
    public String toString() {
        return "ElementPosition(x=" + this.getX() + ", y=" + this.getY() + ", z=" + this.getZ() + ")";
    }
    
    public double getX() {
        return this.x;
    }
    
    public double getY() {
        return this.y;
    }
    
    public double getZ() {
        return this.z;
    }
    
    public ElementPosition(final double x, final double y, final double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
}
