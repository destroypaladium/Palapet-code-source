//Decompiled by Procyon!

package fr.paladium.pet.common.pet;

import java.io.*;
import com.google.gson.*;

public class PetAdditionalData
{
    private static final Gson GSON;
    public static final ElementPosition DEFAULT_SCALE_FACTOR;
    public static final ElementPosition DEFAULT_UI_POSITION;
    public static final ElementPosition DEFAULT_SHOULDER_POSITION;
    private final String name;
    private boolean fish;
    private ElementPosition uiPosition;
    private ElementPosition shoulderPosition;
    private ElementPosition scaleFactor;
    
    public PetAdditionalData(final String name) {
        this.name = name;
        this.uiPosition = PetAdditionalData.DEFAULT_UI_POSITION;
        this.shoulderPosition = PetAdditionalData.DEFAULT_SHOULDER_POSITION;
        this.scaleFactor = PetAdditionalData.DEFAULT_SCALE_FACTOR;
    }
    
    public boolean read(final InputStream inputStream) {
        final InputStreamReader reader = new InputStreamReader(inputStream);
        final PetAdditionalData data = (PetAdditionalData)PetAdditionalData.GSON.fromJson((Reader)reader, (Class)PetAdditionalData.class);
        if (data == null || !this.name.equalsIgnoreCase(data.getName())) {
            return false;
        }
        this.fish = data.isFish();
        this.uiPosition = ((data.getUiPosition() == null) ? PetAdditionalData.DEFAULT_UI_POSITION : data.getUiPosition());
        this.shoulderPosition = ((data.getShoulderPosition() == null) ? PetAdditionalData.DEFAULT_SHOULDER_POSITION : data.getShoulderPosition());
        this.scaleFactor = ((data.getScaleFactor() == null) ? PetAdditionalData.DEFAULT_SCALE_FACTOR : data.getScaleFactor());
        return true;
    }
    
    public PetAdditionalData(final String name, final PetAdditionalData fromFile) {
        this.name = name;
        if (fromFile == null) {
            this.uiPosition = PetAdditionalData.DEFAULT_UI_POSITION;
            this.shoulderPosition = PetAdditionalData.DEFAULT_SHOULDER_POSITION;
            this.scaleFactor = PetAdditionalData.DEFAULT_SCALE_FACTOR;
        }
        else {
            this.uiPosition = ((fromFile.getUiPosition() == null) ? PetAdditionalData.DEFAULT_UI_POSITION : fromFile.getUiPosition());
            this.shoulderPosition = ((fromFile.getShoulderPosition() == null) ? PetAdditionalData.DEFAULT_SHOULDER_POSITION : fromFile.getShoulderPosition());
            this.scaleFactor = ((fromFile.getScaleFactor() == null) ? PetAdditionalData.DEFAULT_SCALE_FACTOR : fromFile.getScaleFactor());
        }
    }
    
    public static PetAdditionalData of(final String name) {
        return new PetAdditionalData(name);
    }
    
    public String getName() {
        return this.name;
    }
    
    public boolean isFish() {
        return this.fish;
    }
    
    public ElementPosition getUiPosition() {
        return this.uiPosition;
    }
    
    public ElementPosition getShoulderPosition() {
        return this.shoulderPosition;
    }
    
    public ElementPosition getScaleFactor() {
        return this.scaleFactor;
    }
    
    public void setFish(final boolean fish) {
        this.fish = fish;
    }
    
    public void setUiPosition(final ElementPosition uiPosition) {
        this.uiPosition = uiPosition;
    }
    
    public void setShoulderPosition(final ElementPosition shoulderPosition) {
        this.shoulderPosition = shoulderPosition;
    }
    
    public void setScaleFactor(final ElementPosition scaleFactor) {
        this.scaleFactor = scaleFactor;
    }
    
    static {
        GSON = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
        DEFAULT_SCALE_FACTOR = ElementPosition.of(0.6, 0.6, 0.6);
        DEFAULT_UI_POSITION = ElementPosition.of(0.0, 0.0, 0.0);
        DEFAULT_SHOULDER_POSITION = ElementPosition.of(-3.0, -1.2, -0.25);
    }
}
