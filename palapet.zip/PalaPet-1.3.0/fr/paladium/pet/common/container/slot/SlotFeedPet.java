//Decompiled by Procyon!

package fr.paladium.pet.common.container.slot;

import net.minecraft.inventory.*;
import fr.paladium.pet.common.registry.impl.*;
import net.minecraft.item.*;
import fr.paladium.pet.server.assignement.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.server.config.assignment.fields.*;

public class SlotFeedPet extends Slot
{
    private final EntityPlayer player;
    
    public SlotFeedPet(final IInventory inv, final int slot, final EntityPlayer player) {
        super(inv, slot, 0, 0);
        this.player = player;
    }
    
    public boolean func_75214_a(final ItemStack itemStack) {
        if (itemStack == null) {
            return false;
        }
        final Item item = itemStack.func_77973_b();
        return item.equals(PetItemRegistry.BAIT) || item instanceof ItemFood;
    }
    
    public void func_75218_e() {
        final ItemStack itemStack = this.func_75211_c();
        if (itemStack == null || this.player == null) {
            return;
        }
        if (!this.func_75214_a(itemStack)) {
            super.func_75218_e();
            return;
        }
        if (this.player.field_70170_p.field_72995_K) {
            this.func_75215_d((ItemStack)null);
            super.func_75218_e();
            return;
        }
        AssignmentManager.getInstance().performAssignments((EntityPlayerMP)this.player, PetPlayer.get(this.player), itemStack, AssignmentType.ITEM);
        this.func_75215_d((ItemStack)null);
        super.func_75218_e();
    }
}
