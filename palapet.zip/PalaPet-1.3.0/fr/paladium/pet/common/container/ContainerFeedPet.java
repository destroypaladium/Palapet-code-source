//Decompiled by Procyon!

package fr.paladium.pet.common.container;

import fr.paladium.lib.apollon.container.abstracts.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.container.slot.*;
import net.minecraft.inventory.*;

public class ContainerFeedPet extends PaladiumContainer
{
    public ContainerFeedPet(final EntityPlayer player) {
        this.func_75146_a((Slot)new SlotFeedPet((IInventory)new InventoryFeedPet(), 0, player));
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.func_75146_a(new Slot((IInventory)player.field_71071_by, j + i * 9 + 9, 0, 0));
            }
        }
        for (int i = 0; i < 9; ++i) {
            this.func_75146_a(new Slot((IInventory)player.field_71071_by, i, 0, 0));
        }
    }
    
    public void func_75134_a(final EntityPlayer player) {
        super.func_75134_a(player);
    }
    
    public int getPlayerInventoryPosition() {
        return 1;
    }
}
