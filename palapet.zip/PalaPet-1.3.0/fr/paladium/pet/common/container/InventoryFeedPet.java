//Decompiled by Procyon!

package fr.paladium.pet.common.container;

import fr.paladium.lib.apollon.container.abstracts.*;

public class InventoryFeedPet extends PaladiumInventory
{
    public static final String NAME = "feed_pet";
    public static final int SIZE = 1;
    
    public InventoryFeedPet() {
        super("feed_pet", 1);
    }
    
    public boolean shouldDropOnClose() {
        return false;
    }
}
