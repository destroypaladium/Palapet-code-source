//Decompiled by Procyon!

package fr.paladium.pet.common.event.global;

import cpw.mods.fml.common.eventhandler.*;
import net.minecraft.entity.player.*;
import net.minecraftforge.common.*;

public class PetStatChangeEvent extends Event
{
    private final EntityPlayer player;
    private final UpdateStatType type;
    
    public PetStatChangeEvent(final EntityPlayer player, final UpdateStatType type) {
        this.player = player;
        this.type = type;
    }
    
    public static void call(final EntityPlayer player, final UpdateStatType type) {
        final PetStatChangeEvent event = new PetStatChangeEvent(player, type);
        MinecraftForge.EVENT_BUS.post((Event)event);
    }
    
    public EntityPlayer getPlayer() {
        return this.player;
    }
    
    public UpdateStatType getType() {
        return this.type;
    }
}
