//Decompiled by Procyon!

package fr.paladium.pet.common.event.global;

public enum UpdateStatType
{
    EXPERIENCE, 
    LEVEL, 
    HAPPINESS, 
    SKILL_USED, 
    SKILL_CHANGED, 
    ASSIGNMENT_FINISHED, 
    ASSIGNMENT_CHANGED;
    
    public boolean needUpdate() {
        return this == UpdateStatType.LEVEL || this == UpdateStatType.HAPPINESS || this == UpdateStatType.SKILL_CHANGED || this == UpdateStatType.ASSIGNMENT_FINISHED || this == UpdateStatType.SKILL_USED;
    }
}
