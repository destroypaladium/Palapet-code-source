//Decompiled by Procyon!

package fr.paladium.pet.common.event.level;

import cpw.mods.fml.common.eventhandler.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.event.experience.*;
import fr.paladium.pet.common.event.global.*;

public class PetLevelUpEvent extends Event
{
    private final EntityPlayer player;
    private final PetExperienceSource source;
    private final int currentLevel;
    private final int newLevel;
    private final int currentSlots;
    private final int newSlots;
    
    public PetLevelUpEvent(final EntityPlayer player, final PetExperienceSource source, final int currentLevel, final int newLevel, final int currentSlots, final int newSlots) {
        this.player = player;
        this.source = source;
        this.currentLevel = currentLevel;
        this.newLevel = newLevel;
        this.currentSlots = currentSlots;
        this.newSlots = newSlots;
        PetStatChangeEvent.call(player, UpdateStatType.LEVEL);
    }
    
    public EntityPlayer getPlayer() {
        return this.player;
    }
    
    public PetExperienceSource getSource() {
        return this.source;
    }
    
    public int getCurrentLevel() {
        return this.currentLevel;
    }
    
    public int getNewLevel() {
        return this.newLevel;
    }
    
    public int getCurrentSlots() {
        return this.currentSlots;
    }
    
    public int getNewSlots() {
        return this.newSlots;
    }
}
