//Decompiled by Procyon!

package fr.paladium.pet.common.event.capture;

import cpw.mods.fml.common.eventhandler.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.palaforgeutils.lib.location.*;

@Cancelable
public class PetCaptureEvent extends Event
{
    private final EntityPlayer player;
    private final PetPlayer pet;
    private final DoubleLocation location;
    
    public PetCaptureEvent(final EntityPlayer player, final PetPlayer pet, final DoubleLocation location) {
        this.player = player;
        this.pet = pet;
        this.location = location;
    }
    
    public EntityPlayer getPlayer() {
        return this.player;
    }
    
    public PetPlayer getPet() {
        return this.pet;
    }
    
    public DoubleLocation getLocation() {
        return this.location;
    }
}
