//Decompiled by Procyon!

package fr.paladium.pet.common.event.happiness;

import cpw.mods.fml.common.eventhandler.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.event.global.*;

@Cancelable
public class PetEarnHappinessEvent extends Event
{
    public static final int MINIMUM_AMOUNT = 0;
    private final EntityPlayer player;
    private int amount;
    
    public PetEarnHappinessEvent(final EntityPlayer player, int amount) {
        if (amount < 0) {
            amount = 0;
        }
        this.player = player;
        this.amount = amount;
        PetStatChangeEvent.call(player, UpdateStatType.HAPPINESS);
    }
    
    public EntityPlayer getPlayer() {
        return this.player;
    }
    
    public int getAmount() {
        return this.amount;
    }
    
    public void setAmount(final int amount) {
        this.amount = amount;
    }
}
