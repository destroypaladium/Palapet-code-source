//Decompiled by Procyon!

package fr.paladium.pet.common.event;

import cpw.mods.fml.common.eventhandler.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;

public class PlayerEnchantItemEvent extends Event
{
    private final EntityPlayer player;
    private final ItemStack stack;
    private final int cost;
    
    public PlayerEnchantItemEvent(final EntityPlayer player, final ItemStack stack, final int cost) {
        this.player = player;
        this.stack = stack;
        this.cost = cost;
    }
    
    public EntityPlayer getPlayer() {
        return this.player;
    }
    
    public ItemStack getStack() {
        return this.stack;
    }
    
    public int getCost() {
        return this.cost;
    }
}
