//Decompiled by Procyon!

package fr.paladium.pet.common.event;

import cpw.mods.fml.common.eventhandler.*;
import net.minecraft.entity.player.*;
import fr.paladium.palaforgeutils.lib.location.*;

@Cancelable
public class PlayerMoveEvent extends Event
{
    private final EntityPlayerMP player;
    private final DoubleLocation lastLocation;
    private final DoubleLocation currentLocation;
    
    public PlayerMoveEvent(final EntityPlayerMP player, final DoubleLocation lastLocation, final DoubleLocation currentLocation) {
        this.player = player;
        this.lastLocation = lastLocation;
        this.currentLocation = currentLocation;
    }
    
    public EntityPlayerMP getPlayer() {
        return this.player;
    }
    
    public DoubleLocation getLastLocation() {
        return this.lastLocation;
    }
    
    public DoubleLocation getCurrentLocation() {
        return this.currentLocation;
    }
}
