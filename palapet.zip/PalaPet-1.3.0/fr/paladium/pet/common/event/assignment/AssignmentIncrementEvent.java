//Decompiled by Procyon!

package fr.paladium.pet.common.event.assignment;

import cpw.mods.fml.common.eventhandler.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.server.config.assignment.*;
import fr.paladium.pet.common.event.global.*;

@Cancelable
public class AssignmentIncrementEvent extends Event
{
    private final EntityPlayer player;
    private final Assignment assignment;
    private final double currentProgress;
    private final double amount;
    
    public AssignmentIncrementEvent(final EntityPlayer player, final Assignment assignment, final double currentProgress, final double amount) {
        this.player = player;
        this.assignment = assignment;
        this.currentProgress = currentProgress;
        this.amount = amount;
        PetStatChangeEvent.call(player, UpdateStatType.ASSIGNMENT_CHANGED);
    }
    
    public EntityPlayer getPlayer() {
        return this.player;
    }
    
    public Assignment getAssignment() {
        return this.assignment;
    }
    
    public double getCurrentProgress() {
        return this.currentProgress;
    }
    
    public double getAmount() {
        return this.amount;
    }
}
