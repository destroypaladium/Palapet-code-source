//Decompiled by Procyon!

package fr.paladium.pet.common.event.experience;

import cpw.mods.fml.common.eventhandler.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.*;

@Cancelable
public class PetEarnExperienceEvent extends Event
{
    public static final double MINIMUM_AMOUNT = 0.0;
    private final EntityPlayer player;
    private final PetExperienceSource source;
    private double amount;
    
    public PetEarnExperienceEvent(final EntityPlayer player, final PetExperienceSource source, double amount) {
        if (amount < 0.0) {
            amount = 0.0;
            PetLogger.error("Tried to earn negative experience: " + amount + " from source: " + source.name());
        }
        this.player = player;
        this.source = source;
        this.amount = amount;
    }
    
    public EntityPlayer getPlayer() {
        return this.player;
    }
    
    public PetExperienceSource getSource() {
        return this.source;
    }
    
    public double getAmount() {
        return this.amount;
    }
    
    public void setAmount(final double amount) {
        this.amount = amount;
    }
}
