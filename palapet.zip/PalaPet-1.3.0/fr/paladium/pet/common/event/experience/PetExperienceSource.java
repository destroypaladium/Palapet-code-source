//Decompiled by Procyon!

package fr.paladium.pet.common.event.experience;

import fr.paladium.palajobs.core.jobs.*;

public enum PetExperienceSource
{
    MINER_LEVEL_UP, 
    HUNTER_LEVEL_UP, 
    FARMER_LEVEL_UP, 
    ALCHEMIST_LEVEL_UP, 
    CONNECTION, 
    ASSIGNMENT, 
    ADMIN;
    
    public static PetExperienceSource getByJobName(final String name) {
        final JobType type = JobType.getByName(name);
        if (type == null) {
            return null;
        }
        return getByJobType(type);
    }
    
    public static PetExperienceSource getByJobType(final JobType jobType) {
        switch (jobType) {
            case MINER: {
                return PetExperienceSource.MINER_LEVEL_UP;
            }
            case HUNTER: {
                return PetExperienceSource.HUNTER_LEVEL_UP;
            }
            case FARMER: {
                return PetExperienceSource.FARMER_LEVEL_UP;
            }
            case ALCHEMIST: {
                return PetExperienceSource.ALCHEMIST_LEVEL_UP;
            }
            default: {
                return null;
            }
        }
    }
}
