//Decompiled by Procyon!

package fr.paladium.pet.common.event.skill;

import cpw.mods.fml.common.eventhandler.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import fr.paladium.pet.server.skill.skill.*;
import fr.paladium.pet.common.event.global.*;

@Cancelable
public class ActiveSkillUsedEvent extends Event
{
    private final EntityPlayer player;
    private final PetPlayer pet;
    private final Skill skill;
    
    public ActiveSkillUsedEvent(final EntityPlayer player, final PetPlayer pet, final Skill skill) {
        this.player = player;
        this.pet = pet;
        this.skill = skill;
        PetStatChangeEvent.call(player, UpdateStatType.SKILL_USED);
    }
    
    public EntityPlayer getPlayer() {
        return this.player;
    }
    
    public PetPlayer getPet() {
        return this.pet;
    }
    
    public Skill getSkill() {
        return this.skill;
    }
}
