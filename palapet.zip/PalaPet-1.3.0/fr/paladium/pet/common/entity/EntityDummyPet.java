//Decompiled by Procyon!

package fr.paladium.pet.common.entity;

import net.minecraft.world.*;
import com.google.common.base.*;
import fr.paladium.pet.common.*;
import software.bernie.geckolib3.core.manager.*;
import software.bernie.geckolib3.core.controller.*;
import software.bernie.geckolib3.core.event.predicate.*;
import software.bernie.geckolib3.core.*;
import java.util.concurrent.atomic.*;
import fr.paladium.pet.client.listener.*;
import net.minecraft.client.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import fr.paladium.pet.common.network.data.*;
import software.bernie.geckolib3.core.builder.*;
import fr.paladium.pet.common.pet.*;
import java.util.*;

public class EntityDummyPet extends EntityLiving implements IAnimatable, IAnimationTickable
{
    public static final String NONE_SKIN_ID = "none";
    public static final String BLOBFISH_SKIN_ID = "pet_blobfish";
    private final AnimationFactory factory;
    private String skinId;
    
    public EntityDummyPet(final World world) {
        super(world);
        this.func_70105_a(1.4f, 1.6f);
        this.factory = new AnimationFactory((IAnimatable)this);
    }
    
    public EntityDummyPet(final World world, final String skinId) {
        this(world);
        this.func_70105_a(1.4f, 1.6f);
        this.skinId = skinId;
    }
    
    protected void func_70088_a() {
        super.func_70088_a();
    }
    
    public String getSkinId() {
        if (Strings.isNullOrEmpty(this.skinId)) {
            return "none";
        }
        if (PetCommonProxy.APRIL_FOOL) {
            return "pet_blobfish";
        }
        return this.skinId;
    }
    
    public void setSkinId(String id) {
        if (Strings.isNullOrEmpty(id)) {
            id = "none";
        }
        this.skinId = id;
    }
    
    public void registerControllers(final AnimationData data) {
        data.addAnimationController(new AnimationController((IAnimatable)this, "movementController", 0.0f, this::predicateMovement));
    }
    
    protected <E extends IAnimatable> PlayState predicateMovement(final AnimationEvent<E> event) {
        final AtomicBoolean modified = new AtomicBoolean(false);
        final String playerUUID;
        final EntityDummyPet targetedPet;
        final Iterator<Object> iterator;
        Object o;
        Entity e;
        EntityPlayer petOwner;
        PetPlayer eep;
        final AtomicBoolean atomicBoolean;
        PetAdditionalData additionalData;
        boolean shouldSwim;
        String animationType;
        PetRenderListener.cachedRenderer.entrySet().forEach(entry -> {
            playerUUID = entry.getKey();
            targetedPet = (EntityDummyPet)entry.getValue();
            if (targetedPet == null) {
                return;
            }
            else {
                Minecraft.func_71410_x().field_71441_e.field_72996_f.iterator();
                while (iterator.hasNext()) {
                    o = iterator.next();
                    e = (Entity)o;
                    if (e instanceof EntityPlayer) {
                        petOwner = (EntityPlayer)e;
                        if (!petOwner.func_70005_c_().equals(playerUUID)) {
                            continue;
                        }
                        else if (targetedPet.func_110124_au() == this.func_110124_au()) {
                            eep = PetPlayer.get(petOwner);
                            if (eep != null && System.currentTimeMillis() - eep.getLastSkillUsage() <= 1500L) {
                                event.getController().setAnimation(new AnimationBuilder().addAnimation("skill", Boolean.TRUE));
                                atomicBoolean.set(true);
                            }
                            else if (petOwner.func_70090_H()) {
                                additionalData = PetCommonProxy.getInstance().findPet(targetedPet.getSkinId());
                                shouldSwim = (additionalData == null || additionalData.isFish());
                                animationType = (shouldSwim ? "swim" : "walk");
                                event.getController().setAnimation(new AnimationBuilder().addAnimation(animationType, Boolean.TRUE));
                                atomicBoolean.set(true);
                            }
                            else if (petOwner.field_70137_T > petOwner.field_70163_u) {
                                event.getController().setAnimation(new AnimationBuilder().addAnimation("fall", Boolean.TRUE));
                                atomicBoolean.set(true);
                            }
                            else if (petOwner.field_70142_S != petOwner.field_70165_t || petOwner.field_70136_U != petOwner.field_70161_v) {
                                event.getController().setAnimation(new AnimationBuilder().addAnimation("walk", Boolean.TRUE));
                                atomicBoolean.set(true);
                            }
                            else {
                                continue;
                            }
                        }
                        else {
                            continue;
                        }
                    }
                }
                return;
            }
        });
        if (!modified.get()) {
            event.getController().setAnimation(new AnimationBuilder().addAnimation("idle", Boolean.valueOf(true)));
        }
        return PlayState.CONTINUE;
    }
    
    public AnimationFactory getFactory() {
        return this.factory;
    }
    
    public int tickTimer() {
        return this.field_70173_aa;
    }
    
    public void tick() {
        super.func_70071_h_();
    }
}
