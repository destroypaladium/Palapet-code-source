//Decompiled by Procyon!

package fr.paladium.pet.common.entity;

import net.minecraft.entity.*;
import net.minecraft.world.*;
import software.bernie.geckolib3.core.manager.*;
import software.bernie.geckolib3.core.controller.*;
import software.bernie.geckolib3.core.event.predicate.*;
import software.bernie.geckolib3.core.*;
import net.minecraft.client.*;
import fr.paladium.pet.client.renderer.*;
import fr.paladium.pet.common.registry.impl.*;
import fr.paladium.pet.client.renderer.data.*;
import software.bernie.geckolib3.core.builder.*;
import java.util.function.*;
import net.minecraft.entity.player.*;
import java.util.*;
import net.minecraft.block.*;

public class EntityPetCage extends EntityLiving implements IAnimatable, IAnimationTickable
{
    private final AnimationFactory factory;
    
    public EntityPetCage(final World world) {
        super(world);
        this.func_70105_a(1.4f, 1.6f);
        this.factory = new AnimationFactory((IAnimatable)this);
    }
    
    protected void func_70088_a() {
        super.func_70088_a();
    }
    
    public void registerControllers(final AnimationData data) {
        data.addAnimationController(new AnimationController((IAnimatable)this, "movementController", 0.0f, this::predicateMovement));
    }
    
    protected <E extends IAnimatable> PlayState predicateMovement(final AnimationEvent<E> event) {
        final EntityPlayer player = (EntityPlayer)Minecraft.func_71410_x().field_71439_g;
        final HashSet<IntLocation> removeList = new HashSet<IntLocation>();
        boolean modified = false;
        for (final Map.Entry<IntLocation, CageRenderData> entry : TileEntityPetCageRenderer.DATAS.entrySet()) {
            final IntLocation location = entry.getKey();
            final CageRenderData data = entry.getValue();
            if (data == null) {
                continue;
            }
            final int distance = location.distance(player.field_70165_t, player.field_70163_u, player.field_70161_v);
            final Block block = this.field_70170_p.func_147439_a(location.getX(), location.getY(), location.getZ());
            if (distance >= 100 || block == null || !block.equals(PetBlockRegistry.PET_CAGE)) {
                removeList.add(location);
            }
            else {
                final CageRenderState state = data.getState();
                if (state == CageRenderState.IDLE) {
                    event.getController().setAnimation(new AnimationBuilder().addAnimation("idle", Boolean.TRUE));
                    modified = true;
                }
                else if (state == CageRenderState.FOOD || state == CageRenderState.PET) {}
            }
        }
        if (modified) {
            event.getController().setAnimation(new AnimationBuilder().addAnimation("idle", Boolean.TRUE));
        }
        removeList.forEach(TileEntityPetCageRenderer.DATAS::remove);
        return PlayState.CONTINUE;
    }
    
    public AnimationFactory getFactory() {
        return this.factory;
    }
    
    public int tickTimer() {
        return this.field_70173_aa;
    }
    
    public void tick() {
        super.func_70071_h_();
    }
}
