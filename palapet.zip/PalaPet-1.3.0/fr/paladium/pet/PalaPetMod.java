//Decompiled by Procyon!

package fr.paladium.pet;

import fr.paladium.pet.common.*;
import cpw.mods.fml.common.*;
import cpw.mods.fml.common.event.*;

@Mod(modid = "palapet", version = "1.0.0", acceptableRemoteVersions = "*")
public class PalaPetMod
{
    @SidedProxy(clientSide = "fr.paladium.pet.client.PetClientProxy", serverSide = "fr.paladium.pet.server.PetServerProxy")
    public static PetCommonProxy proxy;
    @Mod.Instance("palapet")
    private static PalaPetMod instance;
    
    public static PalaPetMod getInstance() {
        return PalaPetMod.instance;
    }
    
    @Mod.EventHandler
    public void onPreInit(final FMLPreInitializationEvent event) {
        PalaPetMod.proxy.onPreInit(event);
    }
    
    @Mod.EventHandler
    public void onInit(final FMLInitializationEvent event) {
        PalaPetMod.proxy.onInit(event);
    }
    
    @Mod.EventHandler
    public void onPostInit(final FMLPostInitializationEvent event) {
        PalaPetMod.proxy.onPostInit(event);
    }
    
    @Mod.EventHandler
    public void onServerStarting(final FMLServerStartingEvent event) {
        PalaPetMod.proxy.onServerStarting(event);
    }
    
    @Mod.EventHandler
    public void onServerStarted(final FMLServerStartedEvent event) {
        PalaPetMod.proxy.onServerStarted(event);
    }
}
