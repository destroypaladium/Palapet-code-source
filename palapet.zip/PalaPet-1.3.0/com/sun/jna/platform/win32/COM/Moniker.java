//Decompiled by Procyon!

package com.sun.jna.platform.win32.COM;

import com.sun.jna.platform.win32.*;
import com.sun.jna.*;

public class Moniker extends Unknown implements IMoniker
{
    static final int vTableIdStart = 7;
    
    public Moniker() {
    }
    
    public Moniker(final Pointer pointer) {
        super(pointer);
    }
    
    public void BindToObject() {
        final int vTableId = 8;
        throw new UnsupportedOperationException();
    }
    
    public void BindToStorage() {
        final int vTableId = 9;
        throw new UnsupportedOperationException();
    }
    
    public void Reduce() {
        final int vTableId = 10;
        throw new UnsupportedOperationException();
    }
    
    public void ComposeWith() {
        final int vTableId = 11;
        throw new UnsupportedOperationException();
    }
    
    public void Enum() {
        final int vTableId = 12;
        throw new UnsupportedOperationException();
    }
    
    public void IsEqual() {
        final int vTableId = 13;
        throw new UnsupportedOperationException();
    }
    
    public void Hash() {
        final int vTableId = 14;
        throw new UnsupportedOperationException();
    }
    
    public void IsRunning() {
        final int vTableId = 15;
        throw new UnsupportedOperationException();
    }
    
    public void GetTimeOfLastChange() {
        final int vTableId = 16;
        throw new UnsupportedOperationException();
    }
    
    public void Inverse() {
        final int vTableId = 17;
        throw new UnsupportedOperationException();
    }
    
    public void CommonPrefixWith() {
        final int vTableId = 18;
        throw new UnsupportedOperationException();
    }
    
    public void RelativePathTo() {
        final int vTableId = 19;
        throw new UnsupportedOperationException();
    }
    
    public WinNT.HRESULT GetDisplayName(final Pointer pbc, final Pointer pmkToLeft, final WTypes.BSTRByReference ppszDisplayName) {
        final int vTableId = 20;
        final WinNT.HRESULT hr = (WinNT.HRESULT)this._invokeNativeObject(20, new Object[] { this.getPointer(), pbc, pmkToLeft, ppszDisplayName }, (Class)WinNT.HRESULT.class);
        return hr;
    }
    
    public void ParseDisplayName() {
        final int vTableId = 21;
        throw new UnsupportedOperationException();
    }
    
    public void IsSystemMoniker() {
        final int vTableId = 22;
        throw new UnsupportedOperationException();
    }
    
    public boolean IsDirty() {
        throw new UnsupportedOperationException();
    }
    
    public void Load(final IStream stm) {
        throw new UnsupportedOperationException();
    }
    
    public void Save(final IStream stm) {
        throw new UnsupportedOperationException();
    }
    
    public void GetSizeMax() {
        throw new UnsupportedOperationException();
    }
    
    public Guid.CLSID GetClassID() {
        throw new UnsupportedOperationException();
    }
    
    public static class ByReference extends Moniker implements Structure.ByReference
    {
    }
}
