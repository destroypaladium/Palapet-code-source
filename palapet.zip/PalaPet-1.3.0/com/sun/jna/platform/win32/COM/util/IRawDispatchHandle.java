//Decompiled by Procyon!

package com.sun.jna.platform.win32.COM.util;

import com.sun.jna.platform.win32.COM.*;

public interface IRawDispatchHandle
{
    IDispatch getRawDispatch();
}
