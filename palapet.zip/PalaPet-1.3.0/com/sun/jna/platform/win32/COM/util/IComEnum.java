//Decompiled by Procyon!

package com.sun.jna.platform.win32.COM.util;

public interface IComEnum
{
    long getValue();
}
