//Decompiled by Procyon!

package com.sun.jna.platform.win32.COM.util;

public interface IDispatch extends IUnknown
{
     <T> void setProperty(final String p0, final T p1);
    
     <T> T getProperty(final Class<T> p0, final String p1, final Object... p2);
    
     <T> T invokeMethod(final Class<T> p0, final String p1, final Object... p2);
}
