//Decompiled by Procyon!

package com.sun.jna.platform.win32.COM;

import com.sun.jna.*;

public interface IUnknownCallback extends IUnknown
{
    Pointer getPointer();
}
