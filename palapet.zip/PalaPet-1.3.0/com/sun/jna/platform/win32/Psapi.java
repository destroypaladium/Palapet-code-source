//Decompiled by Procyon!

package com.sun.jna.platform.win32;

import com.sun.jna.win32.*;
import com.sun.jna.*;

public interface Psapi extends StdCallLibrary
{
    public static final Psapi INSTANCE = (Psapi)Native.loadLibrary("psapi", (Class)Psapi.class, W32APIOptions.DEFAULT_OPTIONS);
    
    int GetModuleFileNameExA(final WinNT.HANDLE p0, final WinNT.HANDLE p1, final byte[] p2, final int p3);
    
    int GetModuleFileNameExW(final WinNT.HANDLE p0, final WinNT.HANDLE p1, final char[] p2, final int p3);
    
    int GetModuleFileNameEx(final WinNT.HANDLE p0, final WinNT.HANDLE p1, final Pointer p2, final int p3);
}
