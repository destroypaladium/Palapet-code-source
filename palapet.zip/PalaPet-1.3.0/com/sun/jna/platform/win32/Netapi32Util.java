//Decompiled by Procyon!

package com.sun.jna.platform.win32;

import com.sun.jna.ptr.*;
import java.util.*;
import com.sun.jna.*;

public abstract class Netapi32Util
{
    public static String getDCName() {
        return getDCName(null, null);
    }
    
    public static String getDCName(final String serverName, final String domainName) {
        final PointerByReference bufptr = new PointerByReference();
        try {
            final int rc = Netapi32.INSTANCE.NetGetDCName(domainName, serverName, bufptr);
            if (0 != rc) {
                throw new Win32Exception(rc);
            }
            return bufptr.getValue().getWideString(0L);
        }
        finally {
            if (0 != Netapi32.INSTANCE.NetApiBufferFree(bufptr.getValue())) {
                throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
            }
        }
    }
    
    public static int getJoinStatus() {
        return getJoinStatus(null);
    }
    
    public static int getJoinStatus(final String computerName) {
        final PointerByReference lpNameBuffer = new PointerByReference();
        final IntByReference bufferType = new IntByReference();
        try {
            final int rc = Netapi32.INSTANCE.NetGetJoinInformation(computerName, lpNameBuffer, bufferType);
            if (0 != rc) {
                throw new Win32Exception(rc);
            }
            return bufferType.getValue();
        }
        finally {
            if (lpNameBuffer.getPointer() != null) {
                final int rc2 = Netapi32.INSTANCE.NetApiBufferFree(lpNameBuffer.getValue());
                if (0 != rc2) {
                    throw new Win32Exception(rc2);
                }
            }
        }
    }
    
    public static String getDomainName(final String computerName) {
        final PointerByReference lpNameBuffer = new PointerByReference();
        final IntByReference bufferType = new IntByReference();
        try {
            final int rc = Netapi32.INSTANCE.NetGetJoinInformation(computerName, lpNameBuffer, bufferType);
            if (0 != rc) {
                throw new Win32Exception(rc);
            }
            return lpNameBuffer.getValue().getWideString(0L);
        }
        finally {
            if (lpNameBuffer.getPointer() != null) {
                final int rc2 = Netapi32.INSTANCE.NetApiBufferFree(lpNameBuffer.getValue());
                if (0 != rc2) {
                    throw new Win32Exception(rc2);
                }
            }
        }
    }
    
    public static LocalGroup[] getLocalGroups() {
        return getLocalGroups(null);
    }
    
    public static LocalGroup[] getLocalGroups(final String serverName) {
        final PointerByReference bufptr = new PointerByReference();
        final IntByReference entriesRead = new IntByReference();
        final IntByReference totalEntries = new IntByReference();
        try {
            final int rc = Netapi32.INSTANCE.NetLocalGroupEnum(serverName, 1, bufptr, -1, entriesRead, totalEntries, (IntByReference)null);
            if (0 != rc || bufptr.getValue() == Pointer.NULL) {
                throw new Win32Exception(rc);
            }
            final LMAccess.LOCALGROUP_INFO_1 group = new LMAccess.LOCALGROUP_INFO_1(bufptr.getValue());
            final LMAccess.LOCALGROUP_INFO_1[] groups = (LMAccess.LOCALGROUP_INFO_1[])group.toArray(entriesRead.getValue());
            final ArrayList<LocalGroup> result = new ArrayList<LocalGroup>();
            for (final LMAccess.LOCALGROUP_INFO_1 lgpi : groups) {
                final LocalGroup lgp = new LocalGroup();
                if (lgpi.lgrui1_name != null) {
                    lgp.name = lgpi.lgrui1_name.toString();
                }
                if (lgpi.lgrui1_comment != null) {
                    lgp.comment = lgpi.lgrui1_comment.toString();
                }
                result.add(lgp);
            }
            return result.toArray(new LocalGroup[0]);
        }
        finally {
            if (bufptr.getValue() != Pointer.NULL) {
                final int rc2 = Netapi32.INSTANCE.NetApiBufferFree(bufptr.getValue());
                if (0 != rc2) {
                    throw new Win32Exception(rc2);
                }
            }
        }
    }
    
    public static Group[] getGlobalGroups() {
        return getGlobalGroups(null);
    }
    
    public static Group[] getGlobalGroups(final String serverName) {
        final PointerByReference bufptr = new PointerByReference();
        final IntByReference entriesRead = new IntByReference();
        final IntByReference totalEntries = new IntByReference();
        try {
            final int rc = Netapi32.INSTANCE.NetGroupEnum(serverName, 1, bufptr, -1, entriesRead, totalEntries, (IntByReference)null);
            if (0 != rc || bufptr.getValue() == Pointer.NULL) {
                throw new Win32Exception(rc);
            }
            final LMAccess.GROUP_INFO_1 group = new LMAccess.GROUP_INFO_1(bufptr.getValue());
            final LMAccess.GROUP_INFO_1[] groups = (LMAccess.GROUP_INFO_1[])group.toArray(entriesRead.getValue());
            final ArrayList<LocalGroup> result = new ArrayList<LocalGroup>();
            for (final LMAccess.GROUP_INFO_1 lgpi : groups) {
                final LocalGroup lgp = new LocalGroup();
                if (lgpi.grpi1_name != null) {
                    lgp.name = lgpi.grpi1_name.toString();
                }
                if (lgpi.grpi1_comment != null) {
                    lgp.comment = lgpi.grpi1_comment.toString();
                }
                result.add(lgp);
            }
            return result.toArray(new LocalGroup[0]);
        }
        finally {
            if (bufptr.getValue() != Pointer.NULL) {
                final int rc2 = Netapi32.INSTANCE.NetApiBufferFree(bufptr.getValue());
                if (0 != rc2) {
                    throw new Win32Exception(rc2);
                }
            }
        }
    }
    
    public static User[] getUsers() {
        return getUsers(null);
    }
    
    public static User[] getUsers(final String serverName) {
        final PointerByReference bufptr = new PointerByReference();
        final IntByReference entriesRead = new IntByReference();
        final IntByReference totalEntries = new IntByReference();
        try {
            final int rc = Netapi32.INSTANCE.NetUserEnum(serverName, 1, 0, bufptr, -1, entriesRead, totalEntries, (IntByReference)null);
            if (0 != rc || bufptr.getValue() == Pointer.NULL) {
                throw new Win32Exception(rc);
            }
            final LMAccess.USER_INFO_1 user = new LMAccess.USER_INFO_1(bufptr.getValue());
            final LMAccess.USER_INFO_1[] users = (LMAccess.USER_INFO_1[])user.toArray(entriesRead.getValue());
            final ArrayList<User> result = new ArrayList<User>();
            for (final LMAccess.USER_INFO_1 lu : users) {
                final User auser = new User();
                if (lu.usri1_name != null) {
                    auser.name = lu.usri1_name.toString();
                }
                result.add(auser);
            }
            return result.toArray(new User[0]);
        }
        finally {
            if (bufptr.getValue() != Pointer.NULL) {
                final int rc2 = Netapi32.INSTANCE.NetApiBufferFree(bufptr.getValue());
                if (0 != rc2) {
                    throw new Win32Exception(rc2);
                }
            }
        }
    }
    
    public static Group[] getCurrentUserLocalGroups() {
        return getUserLocalGroups(Secur32Util.getUserNameEx(2));
    }
    
    public static Group[] getUserLocalGroups(final String userName) {
        return getUserLocalGroups(userName, null);
    }
    
    public static Group[] getUserLocalGroups(final String userName, final String serverName) {
        final PointerByReference bufptr = new PointerByReference();
        final IntByReference entriesread = new IntByReference();
        final IntByReference totalentries = new IntByReference();
        try {
            final int rc = Netapi32.INSTANCE.NetUserGetLocalGroups(serverName, userName, 0, 0, bufptr, -1, entriesread, totalentries);
            if (rc != 0) {
                throw new Win32Exception(rc);
            }
            final LMAccess.LOCALGROUP_USERS_INFO_0 lgroup = new LMAccess.LOCALGROUP_USERS_INFO_0(bufptr.getValue());
            final LMAccess.LOCALGROUP_USERS_INFO_0[] lgroups = (LMAccess.LOCALGROUP_USERS_INFO_0[])lgroup.toArray(entriesread.getValue());
            final ArrayList<Group> result = new ArrayList<Group>();
            for (final LMAccess.LOCALGROUP_USERS_INFO_0 lgpi : lgroups) {
                final LocalGroup lgp = new LocalGroup();
                if (lgpi.lgrui0_name != null) {
                    lgp.name = lgpi.lgrui0_name.toString();
                }
                result.add(lgp);
            }
            return result.toArray(new Group[0]);
        }
        finally {
            if (bufptr.getValue() != Pointer.NULL) {
                final int rc2 = Netapi32.INSTANCE.NetApiBufferFree(bufptr.getValue());
                if (0 != rc2) {
                    throw new Win32Exception(rc2);
                }
            }
        }
    }
    
    public static Group[] getUserGroups(final String userName) {
        return getUserGroups(userName, null);
    }
    
    public static Group[] getUserGroups(final String userName, final String serverName) {
        final PointerByReference bufptr = new PointerByReference();
        final IntByReference entriesread = new IntByReference();
        final IntByReference totalentries = new IntByReference();
        try {
            final int rc = Netapi32.INSTANCE.NetUserGetGroups(serverName, userName, 0, bufptr, -1, entriesread, totalentries);
            if (rc != 0) {
                throw new Win32Exception(rc);
            }
            final LMAccess.GROUP_USERS_INFO_0 lgroup = new LMAccess.GROUP_USERS_INFO_0(bufptr.getValue());
            final LMAccess.GROUP_USERS_INFO_0[] lgroups = (LMAccess.GROUP_USERS_INFO_0[])lgroup.toArray(entriesread.getValue());
            final ArrayList<Group> result = new ArrayList<Group>();
            for (final LMAccess.GROUP_USERS_INFO_0 lgpi : lgroups) {
                final Group lgp = new Group();
                if (lgpi.grui0_name != null) {
                    lgp.name = lgpi.grui0_name.toString();
                }
                result.add(lgp);
            }
            return result.toArray(new Group[0]);
        }
        finally {
            if (bufptr.getValue() != Pointer.NULL) {
                final int rc2 = Netapi32.INSTANCE.NetApiBufferFree(bufptr.getValue());
                if (0 != rc2) {
                    throw new Win32Exception(rc2);
                }
            }
        }
    }
    
    public static DomainController getDC() {
        final DsGetDC.PDOMAIN_CONTROLLER_INFO pdci = new DsGetDC.PDOMAIN_CONTROLLER_INFO();
        int rc = Netapi32.INSTANCE.DsGetDcName((String)null, (String)null, (Guid.GUID)null, (String)null, 0, pdci);
        if (0 != rc) {
            throw new Win32Exception(rc);
        }
        final DomainController dc = new DomainController();
        if (pdci.dci.DomainControllerAddress != null) {
            dc.address = pdci.dci.DomainControllerAddress.toString();
        }
        dc.addressType = pdci.dci.DomainControllerAddressType;
        if (pdci.dci.ClientSiteName != null) {
            dc.clientSiteName = pdci.dci.ClientSiteName.toString();
        }
        if (pdci.dci.DnsForestName != null) {
            dc.dnsForestName = pdci.dci.DnsForestName.toString();
        }
        dc.domainGuid = pdci.dci.DomainGuid;
        if (pdci.dci.DomainName != null) {
            dc.domainName = pdci.dci.DomainName.toString();
        }
        dc.flags = pdci.dci.Flags;
        if (pdci.dci.DomainControllerName != null) {
            dc.name = pdci.dci.DomainControllerName.toString();
        }
        rc = Netapi32.INSTANCE.NetApiBufferFree(pdci.dci.getPointer());
        if (0 != rc) {
            throw new Win32Exception(rc);
        }
        return dc;
    }
    
    public static DomainTrust[] getDomainTrusts() {
        return getDomainTrusts(null);
    }
    
    public static DomainTrust[] getDomainTrusts(final String serverName) {
        final IntByReference domainTrustCount = new IntByReference();
        final PointerByReference domainsPointerRef = new PointerByReference();
        int rc = Netapi32.INSTANCE.DsEnumerateDomainTrusts(serverName, 63, domainsPointerRef, domainTrustCount);
        if (0 != rc) {
            throw new Win32Exception(rc);
        }
        try {
            final DsGetDC.DS_DOMAIN_TRUSTS domainTrustRefs = new DsGetDC.DS_DOMAIN_TRUSTS(domainsPointerRef.getValue());
            final DsGetDC.DS_DOMAIN_TRUSTS[] domainTrusts = (DsGetDC.DS_DOMAIN_TRUSTS[])domainTrustRefs.toArray((Structure[])new DsGetDC.DS_DOMAIN_TRUSTS[domainTrustCount.getValue()]);
            final ArrayList<DomainTrust> trusts = new ArrayList<DomainTrust>(domainTrustCount.getValue());
            for (final DsGetDC.DS_DOMAIN_TRUSTS domainTrust : domainTrusts) {
                final DomainTrust t = new DomainTrust();
                if (domainTrust.DnsDomainName != null) {
                    t.DnsDomainName = domainTrust.DnsDomainName.toString();
                }
                if (domainTrust.NetbiosDomainName != null) {
                    t.NetbiosDomainName = domainTrust.NetbiosDomainName.toString();
                }
                t.DomainSid = domainTrust.DomainSid;
                if (domainTrust.DomainSid != null) {
                    t.DomainSidString = Advapi32Util.convertSidToStringSid((WinNT.PSID)domainTrust.DomainSid);
                }
                t.DomainGuid = domainTrust.DomainGuid;
                if (domainTrust.DomainGuid != null) {
                    t.DomainGuidString = Ole32Util.getStringFromGUID(domainTrust.DomainGuid);
                }
                t.flags = domainTrust.Flags;
                trusts.add(t);
            }
            return trusts.toArray(new DomainTrust[0]);
        }
        finally {
            rc = Netapi32.INSTANCE.NetApiBufferFree(domainsPointerRef.getValue());
            if (0 != rc) {
                throw new Win32Exception(rc);
            }
        }
    }
    
    public static UserInfo getUserInfo(final String accountName) {
        return getUserInfo(accountName, getDCName());
    }
    
    public static UserInfo getUserInfo(final String accountName, final String domainName) {
        final PointerByReference bufptr = new PointerByReference();
        int rc = -1;
        try {
            rc = Netapi32.INSTANCE.NetUserGetInfo(domainName, accountName, 23, bufptr);
            if (rc == 0) {
                final LMAccess.USER_INFO_23 info_23 = new LMAccess.USER_INFO_23(bufptr.getValue());
                final UserInfo userInfo = new UserInfo();
                if (info_23.usri23_comment != null) {
                    userInfo.comment = info_23.usri23_comment.toString();
                }
                userInfo.flags = info_23.usri23_flags;
                if (info_23.usri23_full_name != null) {
                    userInfo.fullName = info_23.usri23_full_name.toString();
                }
                if (info_23.usri23_name != null) {
                    userInfo.name = info_23.usri23_name.toString();
                }
                if (info_23.usri23_user_sid != null) {
                    userInfo.sidString = Advapi32Util.convertSidToStringSid((WinNT.PSID)info_23.usri23_user_sid);
                }
                userInfo.sid = info_23.usri23_user_sid;
                return userInfo;
            }
            throw new Win32Exception(rc);
        }
        finally {
            if (bufptr.getValue() != Pointer.NULL) {
                Netapi32.INSTANCE.NetApiBufferFree(bufptr.getValue());
            }
        }
    }
    
    public static class Group
    {
        public String name;
    }
    
    public static class User
    {
        public String name;
        public String comment;
    }
    
    public static class UserInfo extends User
    {
        public String fullName;
        public String sidString;
        public WinNT.PSID sid;
        public int flags;
    }
    
    public static class LocalGroup extends Group
    {
        public String comment;
    }
    
    public static class DomainController
    {
        public String name;
        public String address;
        public int addressType;
        public Guid.GUID domainGuid;
        public String domainName;
        public String dnsForestName;
        public int flags;
        public String clientSiteName;
    }
    
    public static class DomainTrust
    {
        public String NetbiosDomainName;
        public String DnsDomainName;
        public WinNT.PSID DomainSid;
        public String DomainSidString;
        public Guid.GUID DomainGuid;
        public String DomainGuidString;
        private int flags;
        
        public boolean isInForest() {
            return (this.flags & 0x1) != 0x0;
        }
        
        public boolean isOutbound() {
            return (this.flags & 0x2) != 0x0;
        }
        
        public boolean isRoot() {
            return (this.flags & 0x4) != 0x0;
        }
        
        public boolean isPrimary() {
            return (this.flags & 0x8) != 0x0;
        }
        
        public boolean isNativeMode() {
            return (this.flags & 0x10) != 0x0;
        }
        
        public boolean isInbound() {
            return (this.flags & 0x20) != 0x0;
        }
    }
}
