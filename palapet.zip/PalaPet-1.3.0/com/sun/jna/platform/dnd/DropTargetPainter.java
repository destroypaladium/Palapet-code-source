//Decompiled by Procyon!

package com.sun.jna.platform.dnd;

import java.awt.dnd.*;
import java.awt.*;

public interface DropTargetPainter
{
    void paintDropTarget(final DropTargetEvent p0, final int p1, final Point p2);
}
