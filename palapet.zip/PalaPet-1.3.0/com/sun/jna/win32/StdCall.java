//Decompiled by Procyon!

package com.sun.jna.win32;

import com.sun.jna.*;

public interface StdCall extends AltCallingConvention
{
}
