//Decompiled by Procyon!

package com.sun.jna;

import java.lang.reflect.*;

public interface FunctionMapper
{
    String getFunctionName(final NativeLibrary p0, final Method p1);
}
