//Decompiled by Procyon!

package com.sun.jna;

public class ToNativeContext
{
    ToNativeContext() {
    }
}
