//Decompiled by Procyon!

package dev;

public class Vec2i8
{
    public static final int SIZE = 2;
}
