//Decompiled by Procyon!

package dev;

public class FloatArray
{
    public static final int M00 = 0;
    public static final int M10 = 4;
    public static final int M20 = 8;
    public static final int M30 = 12;
    public static final int M01 = 1;
    public static final int M11 = 5;
    public static final int M21 = 9;
    public static final int M31 = 13;
    public static final int M02 = 2;
    public static final int M12 = 6;
    public static final int M22 = 10;
    public static final int M32 = 14;
    public static final int M03 = 3;
    public static final int M13 = 7;
    public static final int M23 = 11;
    public static final int M33 = 15;
    public static final int COUNT = 16;
    
    public static float[] perspective_(final float fovy, final float aspect, final float zNear, final float zFar) {
        return perspective(fovy, aspect, zNear, zFar, new float[16]);
    }
    
    public static float[] perspective(final float fovy, final float aspect, final float zNear, final float zFar, final float[] res) {
        final float h = (float)Math.tan(fovy * 0.5f) * zNear;
        final float w = h * aspect;
        res[0] = zNear / w;
        res[2] = (res[1] = 0.0f);
        res[4] = (res[3] = 0.0f);
        res[5] = zNear / h;
        res[7] = (res[6] = 0.0f);
        res[9] = (res[8] = 0.0f);
        res[10] = -(zFar + zNear) / (zFar - zNear);
        res[11] = -1.0f;
        res[13] = (res[12] = 0.0f);
        res[14] = -2.0f * zFar * zNear / (zFar - zNear);
        res[15] = 0.0f;
        return res;
    }
}
