//Decompiled by Procyon!

package dev;

import glm.vec._4.*;

public class Vec4u8
{
    public static final int SIZE = 4;
    public byte x;
    public byte y;
    public byte z;
    public byte w;
    
    public Vec4u8() {
        this.x = 0;
        this.y = 0;
        this.z = 0;
        this.w = 0;
    }
    
    public Vec4u8(final Vec4 v) {
        this.x = (byte)v.x;
        this.y = (byte)v.y;
        this.z = (byte)v.z;
        this.w = (byte)v.w;
    }
    
    public Vec4u8(final byte x, final byte y, final byte z, final byte w) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.w = w;
    }
    
    public Vec4u8(final float x, final float y, final float z, final float w) {
        this.x = (byte)x;
        this.y = (byte)y;
        this.z = (byte)z;
        this.w = (byte)w;
    }
    
    public byte[] toBa_() {
        return this.toBa(new byte[4]);
    }
    
    public byte[] toBa(final byte[] byteArray) {
        byteArray[0] = this.x;
        byteArray[1] = this.y;
        byteArray[2] = this.z;
        byteArray[3] = this.w;
        return byteArray;
    }
}
