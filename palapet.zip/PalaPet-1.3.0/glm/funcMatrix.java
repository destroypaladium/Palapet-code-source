//Decompiled by Procyon!

package glm;

import glm.mat._4.*;

abstract class funcMatrix extends packing
{
    public static Mat4 transpose_(final Mat4 mat) {
        return glm.mat._4.funcMatrix.transpose(mat, new Mat4());
    }
    
    public static Mat4 transpose(final Mat4 mat, final Mat4 dest) {
        return glm.mat._4.funcMatrix.transpose(mat, dest);
    }
}
