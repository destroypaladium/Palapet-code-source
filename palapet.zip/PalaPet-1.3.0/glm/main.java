//Decompiled by Procyon!

package glm;

import glm.vec._2.*;
import glm.vec._2.i.*;
import glm.vec._4.*;
import glm.vec._3.*;
import glm.vec._3.i.*;

public class main
{
    public static void main(final String[] args) {
        final Vec2 vec2F_1 = new Vec2(5.0f, 2.0f);
        final Vec2 vec2F_2 = new Vec2(5.0f, 8.0f);
        final Vec2i vec2I_1 = new Vec2i(5, 8);
        final Vec2i vec2I_2 = new Vec2i(6, 8);
        final Vec4 vec4_1 = new Vec4(0.0f, 0.0f, 0.0f, 0.0f);
        final Vec3 vec3f_1 = new Vec3(3.0f, 5.0f, 7.0f);
        final Vec3 vec3f_2 = new Vec3(10.0f, 10.0f, 10.0f);
        final Vec3i vec3i_1 = new Vec3i(3, 5, 7);
        final Vec3i vec3i_2 = new Vec3i(10, 10, 10);
        final Vec2i x = vec2I_1.lessThan(vec2I_2);
        final Vec3 modVec = vec3f_2.mod_(vec3f_1);
        final Vec3i modVeci = vec3i_2.mod_(vec3i_1);
        modVec.print("modVec");
        modVeci.print("modVec");
    }
}
