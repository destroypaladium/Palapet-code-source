//Decompiled by Procyon!

package glm.mat._3;

import glm.vec._3.*;

abstract class matrixTransform extends funcMatrix
{
    public Mat3 rotation(final float ang, final Vec3 v) {
        return this.rotation(ang, v.x, v.y, v.z);
    }
    
    public Mat3 rotation(final float ang, final float x, final float y, final float z) {
        final float cos = (float)Math.cos(ang);
        final float sin = (float)Math.sin(ang);
        final float C = 1.0f - cos;
        final float xy = x * y;
        final float xz = x * z;
        final float yz = y * z;
        this.m00 = cos + x * x * C;
        this.m10 = xy * C - z * sin;
        this.m20 = xz * C + y * sin;
        this.m01 = xy * C + z * sin;
        this.m11 = cos + y * y * C;
        this.m21 = yz * C - x * sin;
        this.m02 = xz * C - y * sin;
        this.m12 = yz * C + x * sin;
        this.m22 = cos + z * z * C;
        return (Mat3)this;
    }
    
    public Mat3 rotate(final float angle, final Vec3 v) {
        return this.rotate(angle, v.x, v.y, v.z, (Mat3)this);
    }
    
    public Mat3 rotate(final float angle, final float x, final float y, final float z) {
        return this.rotate(angle, x, y, z, (Mat3)this);
    }
    
    public Mat3 rotate(final float ang, final float x, final float y, final float z, final Mat3 res) {
        final float sin = (float)Math.sin(ang);
        final float cos = (float)Math.cos(ang);
        final float invCos = 1.0f - cos;
        final float xx = x * x;
        final float xy = x * y;
        final float xz = x * z;
        final float yy = y * y;
        final float yz = y * z;
        final float zz = z * z;
        final float rm00 = xx * invCos + cos;
        final float rm2 = xy * invCos + z * sin;
        final float rm3 = xz * invCos - y * sin;
        final float rm4 = xy * invCos - z * sin;
        final float rm5 = yy * invCos + cos;
        final float rm6 = yz * invCos + x * sin;
        final float rm7 = xz * invCos + y * sin;
        final float rm8 = yz * invCos - x * sin;
        final float rm9 = zz * invCos + cos;
        final float nm00 = this.m00 * rm00 + this.m10 * rm2 + this.m20 * rm3;
        final float nm2 = this.m01 * rm00 + this.m11 * rm2 + this.m21 * rm3;
        final float nm3 = this.m02 * rm00 + this.m12 * rm2 + this.m22 * rm3;
        final float nm4 = this.m00 * rm4 + this.m10 * rm5 + this.m20 * rm6;
        final float nm5 = this.m01 * rm4 + this.m11 * rm5 + this.m21 * rm6;
        final float nm6 = this.m02 * rm4 + this.m12 * rm5 + this.m22 * rm6;
        res.m20 = this.m00 * rm7 + this.m10 * rm8 + this.m20 * rm9;
        res.m21 = this.m01 * rm7 + this.m11 * rm8 + this.m21 * rm9;
        res.m22 = this.m02 * rm7 + this.m12 * rm8 + this.m22 * rm9;
        res.m00 = nm00;
        res.m01 = nm2;
        res.m02 = nm3;
        res.m10 = nm4;
        res.m11 = nm5;
        res.m12 = nm6;
        return res;
    }
    
    public Mat3 rotateX(final double ang) {
        return this.rotateX((float)ang, (Mat3)this);
    }
    
    public Mat3 rotateX(final float ang) {
        return this.rotateX(ang, (Mat3)this);
    }
    
    public Mat3 rotateX(final float ang, final Mat3 res) {
        float cos;
        float sin;
        if (ang == 3.1415927f || ang == -3.1415927f) {
            cos = -1.0f;
            sin = 0.0f;
        }
        else if (ang == 1.5707964f || ang == -4.712389f) {
            cos = 0.0f;
            sin = 1.0f;
        }
        else if (ang == -1.5707964f || ang == 4.712389f) {
            cos = 0.0f;
            sin = -1.0f;
        }
        else {
            cos = (float)Math.cos(ang);
            sin = (float)Math.sin(ang);
        }
        final float rm11 = cos;
        final float rm12 = -sin;
        final float rm13 = sin;
        final float rm14 = cos;
        final float nm10 = this.m10 * rm11 + this.m20 * rm13;
        final float nm11 = this.m11 * rm11 + this.m21 * rm13;
        final float nm12 = this.m12 * rm11 + this.m22 * rm13;
        res.m20 = this.m10 * rm12 + this.m20 * rm14;
        res.m21 = this.m11 * rm12 + this.m21 * rm14;
        res.m22 = this.m12 * rm12 + this.m22 * rm14;
        res.m10 = nm10;
        res.m11 = nm11;
        res.m12 = nm12;
        res.m00 = this.m00;
        res.m01 = this.m01;
        res.m02 = this.m02;
        return res;
    }
    
    public Mat3 rotateY(final double ang) {
        return this.rotateY((float)ang, (Mat3)this);
    }
    
    public Mat3 rotateY(final float ang) {
        return this.rotateY(ang, (Mat3)this);
    }
    
    public Mat3 rotateY(final float ang, final Mat3 dest) {
        float cos;
        float sin;
        if (ang == 3.1415927f || ang == -3.1415927f) {
            cos = -1.0f;
            sin = 0.0f;
        }
        else if (ang == 1.5707964f || ang == -4.712389f) {
            cos = 0.0f;
            sin = 1.0f;
        }
        else if (ang == -1.5707964f || ang == 4.712389f) {
            cos = 0.0f;
            sin = -1.0f;
        }
        else {
            cos = (float)Math.cos(ang);
            sin = (float)Math.sin(ang);
        }
        final float rm00 = cos;
        final float rm2 = sin;
        final float rm3 = -sin;
        final float rm4 = cos;
        final float nm00 = this.m00 * rm00 + this.m20 * rm3;
        final float nm2 = this.m01 * rm00 + this.m21 * rm3;
        final float nm3 = this.m02 * rm00 + this.m22 * rm3;
        dest.m20 = this.m00 * rm2 + this.m20 * rm4;
        dest.m21 = this.m01 * rm2 + this.m21 * rm4;
        dest.m22 = this.m02 * rm2 + this.m22 * rm4;
        dest.m00 = nm00;
        dest.m01 = nm2;
        dest.m02 = nm3;
        dest.m10 = this.m10;
        dest.m11 = this.m11;
        dest.m12 = this.m12;
        return dest;
    }
    
    public Mat3 rotateZ(final double ang) {
        return this.rotateZ((float)ang, (Mat3)this);
    }
    
    public Mat3 rotateZ(final float ang) {
        return this.rotateZ(ang, (Mat3)this);
    }
    
    public Mat3 rotateZ(final float ang, final Mat3 dest) {
        float cos;
        float sin;
        if (ang == 3.1415927f || ang == -3.1415927f) {
            cos = -1.0f;
            sin = 0.0f;
        }
        else if (ang == 1.5707964f || ang == -4.712389f) {
            cos = 0.0f;
            sin = 1.0f;
        }
        else if (ang == -1.5707964f || ang == 4.712389f) {
            cos = 0.0f;
            sin = -1.0f;
        }
        else {
            cos = (float)Math.cos(ang);
            sin = (float)Math.sin(ang);
        }
        final float rm00 = cos;
        final float rm2 = -sin;
        final float rm3 = sin;
        final float rm4 = cos;
        final float nm00 = this.m00 * rm00 + this.m10 * rm3;
        final float nm2 = this.m01 * rm00 + this.m11 * rm3;
        final float nm3 = this.m02 * rm00 + this.m12 * rm3;
        dest.m10 = this.m00 * rm2 + this.m10 * rm4;
        dest.m11 = this.m01 * rm2 + this.m11 * rm4;
        dest.m12 = this.m02 * rm2 + this.m12 * rm4;
        dest.m00 = nm00;
        dest.m01 = nm2;
        dest.m02 = nm3;
        dest.m20 = this.m20;
        dest.m21 = this.m21;
        dest.m22 = this.m22;
        return dest;
    }
    
    public Mat3 rotationX(final float ang) {
        float cos;
        float sin;
        if (ang == 3.1415927f || ang == -3.1415927f) {
            cos = -1.0f;
            sin = 0.0f;
        }
        else if (ang == 1.5707964f || ang == -4.712389f) {
            cos = 0.0f;
            sin = 1.0f;
        }
        else if (ang == -1.5707964f || ang == 4.712389f) {
            cos = 0.0f;
            sin = -1.0f;
        }
        else {
            cos = (float)Math.cos(ang);
            sin = (float)Math.sin(ang);
        }
        this.m00 = 1.0f;
        this.m01 = 0.0f;
        this.m02 = 0.0f;
        this.m10 = 0.0f;
        this.m11 = cos;
        this.m12 = sin;
        this.m20 = 0.0f;
        this.m21 = -sin;
        this.m22 = cos;
        return (Mat3)this;
    }
    
    public Mat3 rotationY(final float ang) {
        float cos;
        float sin;
        if (ang == 3.1415927f || ang == -3.1415927f) {
            cos = -1.0f;
            sin = 0.0f;
        }
        else if (ang == 1.5707964f || ang == -4.712389f) {
            cos = 0.0f;
            sin = 1.0f;
        }
        else if (ang == -1.5707964f || ang == 4.712389f) {
            cos = 0.0f;
            sin = -1.0f;
        }
        else {
            cos = (float)Math.cos(ang);
            sin = (float)Math.sin(ang);
        }
        this.m00 = cos;
        this.m01 = 0.0f;
        this.m02 = -sin;
        this.m10 = 0.0f;
        this.m11 = 1.0f;
        this.m12 = 0.0f;
        this.m20 = sin;
        this.m21 = 0.0f;
        this.m22 = cos;
        return (Mat3)this;
    }
    
    public Mat3 rotationZ(final float ang) {
        float cos;
        float sin;
        if (ang == 3.1415927f || ang == -3.1415927f) {
            cos = -1.0f;
            sin = 0.0f;
        }
        else if (ang == 1.5707964f || ang == -4.712389f) {
            cos = 0.0f;
            sin = 1.0f;
        }
        else if (ang == -1.5707964f || ang == 4.712389f) {
            cos = 0.0f;
            sin = -1.0f;
        }
        else {
            cos = (float)Math.cos(ang);
            sin = (float)Math.sin(ang);
        }
        this.m00 = cos;
        this.m01 = sin;
        this.m02 = 0.0f;
        this.m10 = -sin;
        this.m11 = cos;
        this.m12 = 0.0f;
        this.m20 = 0.0f;
        this.m21 = 0.0f;
        this.m22 = 1.0f;
        return (Mat3)this;
    }
}
