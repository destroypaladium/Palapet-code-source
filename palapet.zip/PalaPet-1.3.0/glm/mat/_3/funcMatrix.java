//Decompiled by Procyon!

package glm.mat._3;

abstract class funcMatrix
{
    public float m00;
    public float m10;
    public float m20;
    public float m01;
    public float m11;
    public float m21;
    public float m02;
    public float m12;
    public float m22;
    public static final int SIZE = 36;
    
    public float det() {
        return (this.m00 * this.m11 - this.m01 * this.m10) * this.m22 + (this.m02 * this.m10 - this.m00 * this.m12) * this.m21 + (this.m01 * this.m12 - this.m02 * this.m11) * this.m20;
    }
    
    public Mat3 inverse() {
        return this.inverse((Mat3)this);
    }
    
    public Mat3 inverse_() {
        return this.inverse(new Mat3());
    }
    
    public Mat3 inverse(final Mat3 res) {
        final float s = 1.0f / this.det();
        res.set((this.m11 * this.m22 - this.m21 * this.m12) * s, (this.m21 * this.m02 - this.m01 * this.m22) * s, (this.m01 * this.m12 - this.m11 * this.m02) * s, (this.m20 * this.m12 - this.m10 * this.m22) * s, (this.m00 * this.m22 - this.m20 * this.m02) * s, (this.m10 * this.m02 - this.m00 * this.m12) * s, (this.m10 * this.m21 - this.m20 * this.m11) * s, (this.m20 * this.m01 - this.m00 * this.m21) * s, (this.m00 * this.m11 - this.m10 * this.m01) * s);
        return res;
    }
    
    public Mat3 invTransp() {
        return this.invTransp((Mat3)this);
    }
    
    public Mat3 invTransp_() {
        return this.invTransp(new Mat3());
    }
    
    public Mat3 invTransp(final Mat3 res) {
        final float s = 1.0f / this.det();
        res.set((this.m11 * this.m22 - this.m21 * this.m12) * s, (this.m20 * this.m12 - this.m10 * this.m22) * s, (this.m10 * this.m21 - this.m20 * this.m11) * s, (this.m21 * this.m02 - this.m01 * this.m22) * s, (this.m00 * this.m22 - this.m20 * this.m02) * s, (this.m20 * this.m01 - this.m00 * this.m21) * s, (this.m01 * this.m12 - this.m11 * this.m02) * s, (this.m10 * this.m02 - this.m00 * this.m12) * s, (this.m00 * this.m11 - this.m10 * this.m01) * s);
        return res;
    }
    
    public Mat3 transpose_() {
        return this.transpose(new Mat3());
    }
    
    public Mat3 transpose() {
        return this.transpose((Mat3)this);
    }
    
    public Mat3 transpose(final Mat3 dest) {
        return transpose((Mat3)this, dest);
    }
    
    public static Mat3 transpose(final Mat3 mat, final Mat3 dest) {
        dest.set(mat.m00, mat.m10, mat.m20, mat.m01, mat.m11, mat.m21, mat.m02, mat.m12, mat.m22);
        return dest;
    }
}
