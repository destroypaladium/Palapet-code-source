//Decompiled by Procyon!

package glm.mat._3;

abstract class matrixQuery extends matrixTransform
{
    public boolean isIdentity() {
        return this.isIdentity(0.0f);
    }
    
    public boolean isIdentity(final float epsilon) {
        return Math.abs(this.m00 - 1.0f) <= epsilon && Math.abs(this.m01) <= epsilon && Math.abs(this.m02) <= epsilon && Math.abs(this.m10) <= epsilon && Math.abs(this.m11 - 1.0f) <= epsilon && Math.abs(this.m12) <= epsilon && Math.abs(this.m20) <= epsilon && Math.abs(this.m21) <= epsilon && Math.abs(this.m22 - 1.0f) <= epsilon;
    }
}
