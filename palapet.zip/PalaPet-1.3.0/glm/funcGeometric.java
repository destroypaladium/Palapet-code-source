//Decompiled by Procyon!

package glm;

import glm.vec._3.*;
import glm.quat.*;
import glm.vec._4.*;

abstract class funcGeometric extends funcExponential
{
    public static Quat angleAxis_(final float degAngle, final Vec3 v) {
        return glm.quat.funcGeometric.angleAxis_(degAngle, v);
    }
    
    public static Quat angleAxis(final float degAngle, final Vec3 v, final Quat res) {
        return glm.quat.funcGeometric.angleAxis(degAngle, v, res);
    }
    
    public static float length(final float x) {
        return Math.abs(x);
    }
    
    public static float dot(final Vec4 v0, final Vec4 v1) {
        return glm.vec._4.funcGeometric.dot(v0, v1);
    }
    
    public static float dot(final Quat v0, final Quat v1) {
        return glm.quat.funcGeometric.dot(v0, v1);
    }
    
    public static Vec3 cross(final Vec3 v0, final Vec3 v1) {
        return v0.cross(v1);
    }
    
    public static Vec3 cross_(final Vec3 v0, final Vec3 v1) {
        return v0.cross_(v1);
    }
}
